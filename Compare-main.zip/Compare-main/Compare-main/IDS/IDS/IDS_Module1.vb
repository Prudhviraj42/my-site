﻿Imports System.IO
Imports System.Xml
Imports System.Collections.Specialized
Imports System.Collections.Generic
Imports System.Xml.Linq
Imports System.Xml.Linq.XNode
Imports System.Text.RegularExpressions
Imports System.Reflection.Assembly

Module Module1

    Public ExtractedXMLfile As String = "", PathInfoFile As String = "", Outpudirectory As String = ""
    Public IApplication As New InDesignServer.Application
    Public IDocument As InDesignServer.Document
    Public ArgIDSName As String = ""
    Public ThreadStartTime As System.DateTime
    Public ThreadEndTime As System.DateTime

    Private Function GetInDesignServerInstance(configName As String) As InDesignServer.Application
        Dim myApp As InDesignServer.Application = Nothing
        Try
            myApp = (System.Runtime.InteropServices.Marshal.BindToMoniker(configName))
        Catch e As System.Runtime.InteropServices.COMException
            Console.WriteLine("Could not connect to InDesign Server configuration:  " + configName)
            Console.WriteLine("Exception:  " + e.ErrorCode.ToString() + "   " + e.ToString())
            myApp = Nothing
        End Try

        Return myApp
    End Function

    Sub Main(ByVal Args() As String)
        Try

            ''Args = {"E:\Sasikala\LIVE\6509\CS6_SPinDesignGenericXMLAutoFlow[E]\bin\x86\Debug\\FilePath\ElsevierPathInfo.XML", "D:\Program Files\AUTOPAGESYSTEM\WorkingFolder\0004471170.xml"}
            ''Args = {"E:\Sasikala\LIVE\6509\CS6 Elsevier Production\InDesignProduction\bin\x86\Debug\\FilePath\ElsevierPathInfo.XML", "c:\womat-temp\30.xml"}

            PathInfoFile = Args(0).ToString
            ExtractedXMLfile = Args(1).ToString
            ArgIDSName = Args(2).ToString()
            ThreadStartTime = DateAndTime.Now

            'IApplication = CreateObject("InDesign.Application")
            IApplication = GetInDesignServerInstance(ArgIDSName)
            IDocument = IApplication.Documents.FirstItem

            Dim CurrVersion As Version = System.Reflection.Assembly.GetEntryAssembly().GetName().Version
            Console.Title = "CC - InDesign Server XML POST PROCESS - ELSEVIER - " + ArgIDSName
            Console.Clear()
            Console.WriteLine("*************************************************************************************************")
            Console.WriteLine("                           ELSEVIER POST-PROCESSOR (2020 - 2021)")
            Console.WriteLine("                           ~~~~~~~~ ~~~~ ~~~~~~~~~ ~~~~~~~~~~~~~")
            Console.WriteLine("                           CC - InDesign Server (IDS) - Version: " & CurrVersion.Major & "." & CurrVersion.Minor & "." & CurrVersion.Build & "." & CurrVersion.Revision)
            Console.WriteLine("                InDesign Application Development Team, SPi Global, Puducherry, India.")
            Console.WriteLine("*************************************************************************************************")
            Console.WriteLine("Active Document: " & IDocument.Name)
            Console.WriteLine("Instance ID    : " & ArgIDSName)
            Console.WriteLine("Start Time     : " & ThreadStartTime)
            'Console.WriteLine("Called From    : " & ArgAutoflowOrCAP)
            Console.WriteLine("Called From    : " & "Autoflow")
            Console.WriteLine(" - ------------------------------------------------------------------------------------------------")
            Console.WriteLine("")
            Console.WriteLine("UTF-Entity Conversion...")
            If Not File.Exists(ExtractedXMLfile) Then
                If Regex.IsMatch(ExtractedXMLfile, "ERROR") Then
                    Throw New Exception("ERROR: Extracted XML not found." & vbCrLf & ExtractedXMLfile)
                End If
            End If
            Dim EntireFileContents As String = File.ReadAllText(ExtractedXMLfile, System.Text.Encoding.UTF8)
            If Not Directory.Exists("D:\ConversionChecker\") Then
                Directory.CreateDirectory("D:\ConversionChecker\")
            End If
            Dim DestFilePath = "D:\ConversionChecker\" & Path.GetFileName(ExtractedXMLfile)
            If File.Exists(DestFilePath) = True Then
                File.Delete(DestFilePath)
            End If

            Dim tempstr As String = File.ReadAllText(ExtractedXMLfile, System.Text.Encoding.UTF8)
            tempstr = Regex.Replace(tempstr, "<!ENTITY % mathml(.*?)<(chapter|ehs-book|fb-non-chapter|glossary|index|introduction|examination|simple-chapter|bibliography|book)", "]><$2", RegexOptions.Singleline)
            tempstr = Regex.Replace(tempstr, "<ce:glyph name=""([^<>]*?)""([^<>]*?)?>([^<>]*?)?</ce:glyph>", "<ce:glyph name=""$1""/>")
            'Sasikala.K commented for STAMS-4152 on 05-11-19;
            'tempstr = Regex.Replace(tempstr, "\u2009", "&thinsp;")
            'tempstr = Regex.Replace(tempstr, "\u200A", "&hairsp;")
            'tempstr = Regex.Replace(tempstr, "\u2028", "&forcedlb;")
            'tempstr = Regex.Replace(tempstr, "\u202F", "&nonbreaksp;")
            'tempstr = Regex.Replace(tempstr, "\u2002", "&ensp;")
            'tempstr = Regex.Replace(tempstr, "\u2003", "&emsp;")
            'tempstr = Regex.Replace(tempstr, "\u2006", " ")
            'Sasikala.K updated for STAMS-4152 on 06-11-19;
            '--
            Dim tempstr1 = Regex.Match(tempstr, "(<([^<>?]*?)?( version=""(.*?)"")( [^<>]*?)?>)",
RegexOptions.IgnoreCase Or RegexOptions.Compiled Or RegexOptions.Multiline).Groups(4).Value.ToString()
            If Not Regex.IsMatch(tempstr1.ToString, "^(5\.6)$", RegexOptions.IgnoreCase Or RegexOptions.Compiled Or RegexOptions.Multiline Or RegexOptions.Singleline) Then
                tempstr = Regex.Replace(tempstr, "\u2009", "&thinsp;")
                tempstr = Regex.Replace(tempstr, "\u200A", "&hairsp;")
                'tempstr = Regex.Replace(tempstr, "\u2028", "&forcedlb;")
                tempstr = Regex.Replace(tempstr, "\u202F", "&nonbreaksp;")
                tempstr = Regex.Replace(tempstr, "\u2002", "&ensp;")
                tempstr = Regex.Replace(tempstr, "\u2003", "&emsp;")
                tempstr = Regex.Replace(tempstr, "\u2006", " ")
            End If
            '--
            tempstr = Regex.Replace(tempstr, "\u2028", "&forcedlb;")
            tempstr = Regex.Replace(tempstr, "\u2029", "&para;")
            tempstr = Regex.Replace(tempstr, "&apos;", "'")
            tempstr = Regex.Replace(tempstr, "&quot;", """")
            tempstr = Regex.Replace(tempstr, "&reg;", "®")
            tempstr = Regex.Replace(tempstr, "<ce:label>n</ce:label>", "<ce:label>■</ce:label>")
            tempstr = Regex.Replace(tempstr, "(Chapter|Section|Sections|Chapters|Part|Fig.|Figure|Figs.|Figures|Table|Box)\u00A0(\d+)", "$1 $2", RegexOptions.IgnoreCase)
            tempstr = Regex.Replace(tempstr, "\b(et)\u00A0(al)", "$1 $2", RegexOptions.IgnoreCase)
            tempstr = Regex.Replace(tempstr, "(in)(\u00A0)(site|vivo|vitro)", "$1 $3", RegexOptions.IgnoreCase)
            ''STAMS:7674;Balamurugan.K modified on 03-July-2020;
            '' tempstr = Regex.Replace(tempstr, "ex(\u00A0)vivo", "ex vivo", RegexOptions.IgnoreCase)
            tempstr = Regex.Replace(tempstr, "(ex)(\u00A0)vivo", "$1 vivo", RegexOptions.IgnoreCase)
            ''---
            tempstr = Regex.Replace(tempstr, "(\u00A0)(day|days|month|months|week|weeks|year|years)", " $2", RegexOptions.IgnoreCase)
            tempstr = Regex.Replace(tempstr, "(\u00A0)(jour|jours|mois|semaine|semaines|ann\&eacute\;e|ann\&eacute\;es)", " $2", RegexOptions.IgnoreCase)
            tempstr = Regex.Replace(tempstr, "<SPiDummy( ([^<>]*?))?>(.*?)</SPiDummy>", "", RegexOptions.Singleline Or RegexOptions.Multiline)

            'E.Raja commented and modified on 09-Mar-2017;
            ''If Regex.IsMatch(tempstr, "<ce:acknowledgment( ([^<>]*?))?>(.*?)</ce:acknowledgment>") AndAlso Regex.IsMatch(tempstr, "<SPIInsertAcknowledgement></SPIInsertAcknowledgement>") Then
            ''    Dim ack As String = Regex.Match(tempstr, "<ce:acknowledgment( ([^<>]*?))?>(.*?)</ce:acknowledgment>").Groups(0).Value
            ''    tempstr = Regex.Replace(tempstr, "<ce:acknowledgment( ([^<>]*?))?>(.*?)</ce:acknowledgment>", "")
            ''    tempstr = Regex.Replace(tempstr, "<SPIInsertAcknowledgement></SPIInsertAcknowledgement>", ack)
            ''End If

            'E.Raja modified and added on 09-Mar-2017;
            If Regex.IsMatch(tempstr, "<ce:acknowledgment( ([^<>]*?))?>(.*?)</ce:acknowledgment>") AndAlso Regex.IsMatch(tempstr, "<SPIInsertAcknowledgement></SPIInsertAcknowledgement>") Then
                For Each Eqmat As Match In Regex.Matches(tempstr, "<ce:acknowledgment(.[^<>]*?)?>(.*?)</ce:acknowledgment>", RegexOptions.Singleline Or RegexOptions.IgnoreCase)
                    If Eqmat.Success Then
                        Dim ack As String = Eqmat.Value
                        tempstr = Replace(tempstr, Eqmat.Value, "", , 1)
                        tempstr = Replace(tempstr, "<SPIInsertAcknowledgement></SPIInsertAcknowledgement>", ack, , 1)
                    End If
                Next
            End If
            '''''''''''''''''''''''''''''
            'added by k.hemachandiran for ELS_PC; Bug id:8226; 16/09/2016;
            '-------------------------
            tempstr = Regex.Replace(tempstr, "<(/)?inserted>", "", RegexOptions.Singleline Or RegexOptions.Multiline)
            tempstr = Regex.Replace(tempstr, "<(/)?deleted>", "", RegexOptions.Singleline Or RegexOptions.Multiline)
            tempstr = Regex.Replace(tempstr, "<commented>(.*?)</commented>", "", RegexOptions.Singleline Or RegexOptions.Multiline)
            '-------------------------
            ''STAMS:8718;Balamurugan.K Added on 01-Jan-2021;
            tempstr = Regex.Replace(tempstr, "<ce:SPibold>", "", RegexOptions.Compiled Or RegexOptions.Singleline Or RegexOptions.Multiline Or RegexOptions.IgnoreCase)
            tempstr = Regex.Replace(tempstr, "</ce:SPibold>", "", RegexOptions.Compiled Or RegexOptions.Singleline Or RegexOptions.Multiline Or RegexOptions.IgnoreCase)
            tempstr = Regex.Replace(tempstr, "<ce:SPiitalic>", "", RegexOptions.Compiled Or RegexOptions.Singleline Or RegexOptions.Multiline Or RegexOptions.IgnoreCase)
            tempstr = Regex.Replace(tempstr, "</ce:SPiitalic>", "", RegexOptions.Compiled Or RegexOptions.Singleline Or RegexOptions.Multiline Or RegexOptions.IgnoreCase)
            tempstr = Regex.Replace(tempstr, "<ce:SPibold-italic>", "", RegexOptions.Compiled Or RegexOptions.Singleline Or RegexOptions.Multiline Or RegexOptions.IgnoreCase)
            tempstr = Regex.Replace(tempstr, "</ce:SPibold-italic>", "", RegexOptions.Compiled Or RegexOptions.Singleline Or RegexOptions.Multiline Or RegexOptions.IgnoreCase)
            ''---
            File.WriteAllText(ExtractedXMLfile, tempstr, System.Text.Encoding.UTF8)

            Console.WriteLine("XML PostProcess: Started...")
            PostProcess.InDesignPostProcess()
            Console.WriteLine("XML PostProcess: Completed...")

            Dim FileContents As String = File.ReadAllText(ExtractedXMLfile, System.Text.Encoding.UTF8)
            'P.Parthiban Added for New DTD 5.4.0 Updations on 23rd JULY 2015; Bug:5688;
            FileContents = Replace(FileContents, "<!--<ce:keywords", "<ce:keywords")
            FileContents = Replace(FileContents, "</ce:keywords>-->", "</ce:keywords>")
            FileContents = Replace(FileContents, "<!--<sa:affiliation", "<sa:affiliation")
            FileContents = Replace(FileContents, "</sa:affiliation>-->", "</sa:affiliation>")
            FileContents = Regex.Replace(FileContents, "(-->)+", "-->")
            FileContents = Regex.Replace(FileContents, "(<!--)+", "<!--")
            FileContents = Regex.Replace(FileContents, "<sb:ellipsis>([^<>]*?)?</sb:ellipsis>", "<sb:ellipsis />")

            'B.Sujatha Added for Bug:9336 on 17-Mar-2017;
            '-----
            FileContents = Regex.Replace(FileContents, "(\s+)class=""keyword""", "", RegexOptions.IgnoreCase Or RegexOptions.Singleline)
            FileContents = Regex.Replace(FileContents, "(\s+)class=""author""", "", RegexOptions.IgnoreCase Or RegexOptions.Singleline)
            '------

            '---
            'R.Sugavaneshwaran added on 22nd march 2018:STAMS-1869
            FileContents = Regex.Replace(FileContents, "<!--<ce:indexed-name>", "<ce:indexed-name>", RegexOptions.Multiline Or RegexOptions.Singleline)
            FileContents = Regex.Replace(FileContents, "</ce:indexed-name>-->", "</ce:indexed-name>", RegexOptions.Multiline Or RegexOptions.Singleline)
            '---

            'E.Raja added on 25-Apr-2017;bug id 9546;
            FileContents = Regex.Replace(FileContents, "<SPIMATHBLOCK/><mml:math", "<mml:math display=""block""", RegexOptions.IgnoreCase Or RegexOptions.Singleline)
            ''''''''''
            '---
            'R.Sugavaneshwaran added on 30th june 2017:Bug id;10016
            FileContents = Replace(FileContents, "<mml:mo>&</mml:mo>", "<mml:mo>&amp;</mml:mo>")
            '---

            'K.Shanmuga Sundaram added for BugNo:STAMS-4152 on 29th Apr 2019;
            '-----
            FileContents = Regex.Replace(FileContents, "(<ce:note-para( [^<>]*?)?>)( )(<ce:cross-ref( [^<>]*?)?>)", "$1$4", RegexOptions.IgnoreCase Or RegexOptions.Singleline Or RegexOptions.Multiline)
            '-----
            ''STAMS:7799;Balamurugan.K added on 25-July-2020;
            FileContents = Regex.Replace(FileContents, "</ce:section-title>(<!--CodeB>-->)<ce:para([^<]*?)>", "</ce:section-title><ce:para$2>", RegexOptions.IgnoreCase Or RegexOptions.Singleline Or RegexOptions.Multiline)
            ''---
            'Sasikala.K added for STAMS-7795 on 24-07-2020;
            '-----
            FileContents = Regex.Replace(FileContents, "<\?format(.[^<>]*?)\?>", "", RegexOptions.Compiled Or RegexOptions.Singleline Or RegexOptions.Multiline Or RegexOptions.IgnoreCase)
            '-----
            ''STAMS:8564;Balamurugan.K Added on 10-Feb-2021;
            FileContents = Regex.Replace(FileContents, "<!--<ce:anchor (.[^<>]*?)>--><ce:sections><ce:para(.[^<]*?)?>", "<ce:sections><ce:para$2><!--<ce:anchor $1>-->", RegexOptions.Compiled Or RegexOptions.Singleline Or RegexOptions.Multiline Or RegexOptions.IgnoreCase)
            ''--
            ''STAMS:9126;10224;Balamurugan.K Added on 18-Nov-2021;
            FileContents = Regex.Replace(FileContents, "<!--<PCTEXTBOX>(<([A-Za-z0-9]+)>)+</PCTEXTBOX>-->", "", RegexOptions.Compiled Or RegexOptions.Singleline Or RegexOptions.Multiline Or RegexOptions.IgnoreCase)
            ''---
            'K.Shanmuga Sundaram added for BugNo:STAMS-4152 on 29th Apr 2019;
            '-----
            Dim DTDVersion = Regex.Match(FileContents, "(<([^<>?]*?)?( version=""(.*?)"")( [^<>]*?)?>)", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline).Groups(4).Value.ToString()
            If Not String.IsNullOrEmpty(DTDVersion) AndAlso Regex.IsMatch(DTDVersion, "^(5\.6)$", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline) Then
                Dim mathsvgColl As MatchCollection = Regex.Matches(FileContents, "(<mml:math( [^<>]*?)?( altimg=""(.*?)"")( [^<>]*?)?>)", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                For idmath As Integer = 0 To mathsvgColl.Count - 1
                    Dim tempMath As String = mathsvgColl.Item(idmath).Groups(1).Value.ToString()
                    Dim svgMath As String = mathsvgColl.Item(idmath).Groups(4).Value.ToString()
                    If Not String.IsNullOrEmpty(svgMath) AndAlso Regex.IsMatch(svgMath, "(\.gif)", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline) Then
                        svgMath = Regex.Replace(svgMath, "(\.gif)", ".svg", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                        FileContents = Replace(FileContents, mathsvgColl.Item(idmath).Groups(4).Value.ToString(), svgMath, , 1)
                    End If
                Next

                '-----------------------
                ''STAMS:10788; S.Chithra updated on 22-03-2022;
                Dim Figcoll As MatchCollection = Regex.Matches(FileContents, "<ce:link ([^<>]*?)?>", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                Dim Entitycoll As New ArrayList
                For Each figval In Figcoll
                    Dim EachFigval As String = figval.value
                    Dim LocatorFind = Regex.Match(EachFigval, "<ce:link([^<>]*?)? (locator=""(.*?)"") ([^<>]*?)?/>", RegexOptions.IgnoreCase Or RegexOptions.Singleline).Groups(3).Value

                    If Not Entitycoll.Contains(LocatorFind) Then
                        Entitycoll.Add(LocatorFind)
                    End If
                Next
                Entitycoll.Sort()
                Dim Entitytext As String
                Entitytext = "["
                Dim cnt As Integer
                For cnt = 0 To Entitycoll.Count - 1
                    Dim elem As String = Entitycoll.Item(cnt).ToString
                    If elem.StartsWith("m") Then
                        Entitytext &= "<!ENTITY " + elem + " SYSTEM """ + elem + """ NDATA VIDEO>"
                    Else
                        Entitytext &= "<!ENTITY " + elem + " SYSTEM """ + elem + """ NDATA IMAGE>"
                    End If
                Next
                Entitytext &= "]>"

                ''STAMS:10224; R.Venkadesh updated on 07-07-2022;
                'FileContents = Regex.Replace(FileContents, "<\!DOCTYPE chapter PUBLIC(.*?)\[(.*?)\]>", "<!DOCTYPE chapter PUBLIC$1" + Entitytext + " ")
                FileContents = Regex.Replace(FileContents, "<\!DOCTYPE chapter PUBLIC(.*?)\[(.*?)\]>", "<!DOCTYPE chapter PUBLIC$1" + Entitytext)
                '-----------------------

                'K.Sasikala added for BugNo:STAMS-5863 on 02nd Aug 2019;
                'Retain thin-space as entity only in source-text
                '-----
                Dim sourcetextColl As MatchCollection = Regex.Matches(FileContents, "(<ce:source-text( [^<>]*?)?>(.*?)</ce:source-text>)", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                For idsrctxt As Integer = 0 To sourcetextColl.Count - 1
                    Dim srctxtVal As String = sourcetextColl.Item(idsrctxt).Groups(3).Value.ToString()
                    If Not String.IsNullOrEmpty(srctxtVal) AndAlso Regex.IsMatch(srctxtVal, "(<ce:hsp sp=""0.25""/>|<ce:hsp sp=""0.25""></ce:hsp>)", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline) Then
                        srctxtVal = Regex.Replace(srctxtVal, "(<ce:hsp sp=""0.25""/>|<ce:hsp sp=""0.25""></ce:hsp>)", " ", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                        FileContents = Replace(FileContents, sourcetextColl.Item(idsrctxt).Groups(3).Value.ToString(), srctxtVal, , 1)
                    End If
                Next
                '-----

            End If
            FileContents = Replace(FileContents, "</ce:affiliation>, <ce:correspondence", "</ce:affiliation><ce:correspondence")
            '-----

            Dim Wholedata As String = ImageDeclaration(FileContents)
            Dim utf8WithoutBom As New System.Text.UTF8Encoding(False)

            Console.WriteLine("Saving XML...")
            File.WriteAllText(ExtractedXMLfile, Wholedata, utf8WithoutBom)

            Dim idEndTime As DateTime = DateAndTime.Now
            Console.WriteLine("")
            Console.WriteLine("-------------------------------------------------------------------------------------------------")
            Console.WriteLine("End Time       : " & idEndTime.ToString())
            Console.WriteLine("Total Time     : " & idEndTime.Subtract(ThreadStartTime).ToString())
            Console.WriteLine("*************************************************************************")
            Console.WriteLine("       Elsevier XML Post-Process Completed Successfully!")
            Console.WriteLine("*************************************************************************")
            System.Threading.Thread.Sleep(1500)

        Catch ex As Exception
            Throw New Exception("Suspecting error in CS6_Elsevier_PostProcess_Tool EXE: " & ex.Message & vbCrLf & ex.StackTrace)
        End Try
    End Sub

    Public Function GetSetting(ByVal XmlFileName As String, ByVal SettingName As String) As String
        Dim XmlDoc As New XmlDocument
        Dim PathNode As XmlNode
        Dim ArtWork As String = ""
        Try
            XmlDoc.Load(XmlFileName)
            PathNode = XmlDoc.SelectSingleNode("//PathInfo")

            For Each n As XmlNode In PathNode.ChildNodes
                Dim AttributeValue As String = n.Attributes("Type").Value
                If AttributeValue.ToLower() = SettingName.ToLower() Then
                    Return n.InnerText
                End If
            Next
            Return ""
        Catch ex As Exception
            Return ""
        End Try
    End Function

    Function ImageDeclaration(ByVal WholeData As String) As String
        Try
            Dim TempStr As String = ""
            ''E.Raja and R.sugavanesh commented on 13-May-2017; bug id 9700;
            ''Dim elts
            'Dim DirPath As String = GetSetting(PathInfoFile, "LocalScripts")
            'Try
            '    elts = IApplication.DoScript(DirPath & "\GetElements(Xpath).jsxbin", InDesign.idScriptLanguage.idJavascript, {"//link"})
            'Catch ex As Exception
            '    Throw ex
            'End Try

            '<!ENTITY alt1 SYSTEM "alt1" NDATA IMAGE>
            'For i As Integer = 0 To elts.length - 1
            '    Dim Ele As InDesign.XMLElement = elts(i)
            '    For Each att As InDesign.XMLAttribute In Ele.XMLAttributes
            '        If att.Name = "locator" AndAlso Not TempStr.Contains("<!ENTITY " & att.Value & " SYSTEM " & """" & att.Value & """" & " NDATA IMAGE>") Then
            '            TempStr &= "<!ENTITY " & att.Value & " SYSTEM " & """" & att.Value & """" & " NDATA IMAGE>"
            '            Exit For
            '        End If
            '    Next
            'Next

            ''E.Raja and R.sugavanesh added on 13-May-2017; bug id 9700;
            Dim LinkMatch As MatchCollection = Regex.Matches(WholeData, "<ce:link(.[^<>]*?)/>", RegexOptions.Multiline Or RegexOptions.Singleline)
            For Each mtch As Match In LinkMatch
                Dim LinkValue As String = mtch.Groups(1).ToString
                Dim LocatorMatch As Match = Regex.Match(LinkValue, "locator=""(.[^<>]*?)"" ", RegexOptions.Singleline)
                'Sasikala.K added if..else for STAMS-8604 on 30-11-2020;
                '--
                If LocatorMatch.Success AndAlso Regex.IsMatch(LocatorMatch.Groups(1).Value, "^mmc(\d+)", RegexOptions.Singleline) AndAlso Not TempStr.Contains("<!ENTITY " & LocatorMatch.Groups(1).Value & " SYSTEM " & """" & LocatorMatch.Groups(1).Value & """" & " NDATA AUDIO>") Then
                    TempStr &= "<!ENTITY " & LocatorMatch.Groups(1).Value & " SYSTEM " & """" & LocatorMatch.Groups(1).Value & """" & " NDATA AUDIO>"
                    '--
                ElseIf LocatorMatch.Success AndAlso Not TempStr.Contains("<!ENTITY " & LocatorMatch.Groups(1).Value & " SYSTEM " & """" & LocatorMatch.Groups(1).Value & """" & " NDATA IMAGE>") Then
                    TempStr &= "<!ENTITY " & LocatorMatch.Groups(1).Value & " SYSTEM " & """" & LocatorMatch.Groups(1).Value & """" & " NDATA IMAGE>"
                End If
            Next

            If Regex.IsMatch(WholeData, "\.dtd""\s\[\]><") Then
                Dim ImageEntityMatch1 As Match = Regex.Match(WholeData, "\.dtd""\s\[\]><")
                If ImageEntityMatch1.Success Then
                    WholeData = WholeData.Replace(ImageEntityMatch1.Groups(0).Value, ".dtd"" [" & TempStr & "]><")
                End If
            ElseIf Regex.IsMatch(WholeData, "\[<!ENTITY(.*?)IMAGE>\]") Then
                Dim ImageEntityMatch As Match = Regex.Match(WholeData, "\[<!ENTITY(.*?)IMAGE>\]")
                If ImageEntityMatch.Success And ImageEntityMatch.Groups(0).Value <> "" Then
                    WholeData = WholeData.Replace(ImageEntityMatch.Groups(0).Value, "[" & TempStr & "]")
                End If
                'Sasikala.K added for STAMS-8604 on 30-11-2020;
                '--
            ElseIf Regex.IsMatch(WholeData, "\[<!ENTITY(.*?)AUDIO>\]") Then
                Dim ImageEntityMatch As Match = Regex.Match(WholeData, "\[<!ENTITY(.*?)AUDIO>\]")
                If ImageEntityMatch.Success And ImageEntityMatch.Groups(0).Value <> "" Then
                    WholeData = WholeData.Replace(ImageEntityMatch.Groups(0).Value, "[" & TempStr & "]")
                End If
                '--
            End If
            Return WholeData
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Module
