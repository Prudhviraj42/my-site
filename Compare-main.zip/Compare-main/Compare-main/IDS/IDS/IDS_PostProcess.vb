﻿Imports System.IO
Imports System.Text.RegularExpressions
Imports System.Xml
Imports System.Collections.Specialized
Imports System.Xml.Linq


Public Class PostProcess

#Region "Local class variables"
    ''' <summary>
    ''' Reference Style Name
    ''' </summary>
    ''' <remarks>Post process done based on style</remarks>
    Shared ReferenceStyle As String = String.Empty
#End Region

#Region "Shared Sub ExpandLastPage(ByRef Ref As String)"
    ''' <summary>
    ''' Expand last page.
    ''' </summary>
    ''' <param name="Ref"></param>
    ''' <remarks></remarks>
    Shared Sub ExpandLastPage(ByRef Ref As String)

        Dim matches As MatchCollection = Regex.Matches(Ref, "<sb:pages>([^<]*)<sb:first-page>([^<]*)</sb:first-page>([^<]*)<sb:last-page>([^<]*)</sb:last-page>")
        For Each m As Match In matches
            Dim notconverted As String = m.Groups(0).Value
            Dim converted As String = m.Groups(0).Value

            Dim lastpage As String = m.Groups(4).Value
            Dim firstpage As String = m.Groups(2).Value

            If firstpage.Length > lastpage.Length Then
                lastpage = firstpage.Substring(0, firstpage.Length - lastpage.Length) & lastpage
            End If

            converted = Regex.Replace(converted, "<sb:pages>([^<]*)<sb:first-page>([^<]*)</sb:first-page>([^<]*)<sb:last-page>([^<]*)</sb:last-page>", "<sb:pages>$1<sb:first-page>$2</sb:first-page>$3<sb:last-page>" & lastpage & "</sb:last-page>")

            Ref = Regex.Replace(Ref, notconverted, converted)
        Next
    End Sub
#End Region

#Region "Shared Sub ExpandDate(ByRef Ref As String)"
    ''' <summary>
    ''' Expand Dates.
    ''' </summary>
    ''' <param name="Ref">Reference</param>
    ''' <remarks></remarks>
    Shared Sub ExpandDate(ByRef Ref As String)
        'note: we match only the numeric value for 2nd date, because 2nd date may have numeric value + punctuation
        Dim matches As MatchCollection = Regex.Matches(Ref, "<sb:date>([^<]*)</sb:date>([^<]*)<sb:date>([0-9]*)([^<]*)</sb:date>")
        For Each m As Match In matches
            Dim notconverted As String = m.Groups(0).Value
            Dim converted As String = m.Groups(0).Value

            Dim last As String = m.Groups(3).Value
            Dim first As String = m.Groups(1).Value

            If first.Length > last.Length Then
                last = first.Substring(0, first.Length - last.Length) & last
            End If

            converted = Regex.Replace(converted, "<sb:date>([^<]*)</sb:date>([^<]*)<sb:date>([0-9]*)([^<]*)</sb:date>", "<sb:date>$1</sb:date>$2<sb:date>" & last & "$4</sb:date>")

            Ref = Regex.Replace(Ref, notconverted, converted)
        Next
    End Sub
#End Region

#Region "Shared Function MyReplFunc(ByVal InputStr As String, ByVal FndPattern As String, ByVal ReplaceStr As String, Optional ByVal Cnt As Integer = 1) As String"
    ''' <summary>
    ''' Find and replace with given values.
    ''' </summary>
    ''' <param name="InputStr">Input string</param>
    ''' <param name="FndPattern">Find pattern</param>
    ''' <param name="ReplaceStr">Replace string</param>
    ''' <param name="Cnt">Count</param>
    ''' <returns>string</returns>
    ''' <remarks></remarks>
    Shared Function MyReplFunc(ByVal InputStr As String, ByVal FndPattern As String, ByVal ReplaceStr As String, Optional ByVal Cnt As Integer = 1) As String
        Dim MyMatchCol As Match
        Dim Temp As Integer
        MyMatchCol = Regex.Match(InputStr, FndPattern)
        If MyMatchCol.Success Then
            Temp = 1
            For Temp = 1 To MyMatchCol.Groups.Count
                ReplaceStr = Replace(ReplaceStr, "$" & Temp.ToString, MyMatchCol.Groups(Temp).ToString)
            Next
            Return (Replace(InputStr, MyMatchCol.Groups(0).ToString, ReplaceStr, , Cnt))
        Else
            Return InputStr
        End If
    End Function
#End Region

#Region "Shared Sub GreekEntityConversion()"
    ''' <summary>
    ''' Greek Entity Conversion Handler
    ''' </summary>
    ''' <remarks></remarks>
    ''' <History>
    ''' 2008-7-31; Converting Symbol tag to respective entities; k.hemachandiran;
    ''' </History>
    Shared Sub GreekEntityConversion()

        Try
            Dim Contents As String = File.ReadAllText(ExtractedXMLfile, System.Text.Encoding.UTF8)
            Dim GreekMatches As MatchCollection
            Dim GreekMatch As Match
            Dim INode As XmlNode
            Dim GreekEntityList As Hashtable = New Hashtable()
            Dim IDoc As Xml.XmlDocument = New XmlDocument()

            Dim DirPath As String = GetSetting(PathInfoFile, "SymbolToEntityConversion")
            If Not File.Exists(DirPath & "\SymbolToEntityConversion.xml") Then
                MsgBox("""SymbolToEntityConversion.xml"" file is not found. Please check.", MsgBoxStyle.SystemModal)
                End
            End If

            IDoc.Load(DirPath & "\SymbolToEntityConversion.xml")
            Dim SymbolNode As XmlNode = IDoc.SelectSingleNode("//SymbolToGreekConversion")

            For Each INode In SymbolNode.ChildNodes
                GreekEntityList.Add(INode.Attributes.Item(0).Value, INode.Attributes.Item(1).Value)
            Next

            GreekMatches = Regex.Matches(Contents, "<SPiGreekSymbol>(.*?)</SPiGreekSymbol>")
            For Each GreekMatch In GreekMatches
                Dim GreekMatchValue As String = GreekMatch.Value
                Dim ValuesForGreekConversion As String = GreekMatch.Groups(1).ToString()

                'if tagged value contains a single entity we assume that there are no symbols to convert - TODO: verify this assumption.
                If Not ValuesForGreekConversion.Contains("&") Then
                    Dim GreekConvertedValue As String = ""
                    For Each s As String In ValuesForGreekConversion
                        GreekConvertedValue &= "&" & GreekEntityList(s)
                    Next
                    'replace only when symbol is found in the list of symbols with mapped entities
                    If GreekConvertedValue = "" Then
                        GreekMatchValue = Replace(GreekMatchValue, GreekMatch.Value, ValuesForGreekConversion)
                    Else
                        GreekMatchValue = Replace(GreekMatchValue, GreekMatch.Value, GreekConvertedValue)
                    End If
                Else
                    GreekMatchValue = Replace(GreekMatchValue, GreekMatch.Value, ValuesForGreekConversion)
                End If
                Contents = Replace(Contents, GreekMatch.Value, GreekMatchValue)
            Next
            File.WriteAllText(ExtractedXMLfile, Contents, System.Text.Encoding.UTF8)

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
#End Region

#Region "Shared Sub InDesignPostProcess()"
    ''' <summary>
    ''' InDesign Post Process
    ''' </summary>
    ''' <remarks></remarks>
    ''' <History>
    ''' 
    ''' </History>
    Shared Sub InDesignPostProcess()
        Try
            Dim CurrData As String = String.Empty
            Dim WholeData As String = String.Empty
            ''STAMS:6463;Balamurugan.K added on 26-May-2020;
            Dim IsNewSPICERefConv As Boolean = False
            ''---
            GreekEntityConversion()
            GetReferenceStyleName()
            '---
            'R.Sugavanesh added on 14th march 2018:STAMS-1730
            Dim CurrData1 As String = File.ReadAllText(ExtractedXMLfile, System.Text.Encoding.UTF8)
            If Regex.IsMatch(CurrData1, "(<LOFTITLE(.[^<>]*?)?>(.*?)</LOFTITLE>)|(<LOTTITLE(.[^<>]*?)?>(.*?)</LOTTITLE>)", RegexOptions.Singleline) Then
                PostprocessLOFConversion(CurrData1)
            End If
            '---
            ''STAMS:6463;Balamurugan.K added on 26-May-2020;
            If Regex.IsMatch(CurrData1, "<!--SPi-New-SPICERef-Conv-->", RegexOptions.Singleline) Then
                IsNewSPICERefConv = True
            End If
            ''----
            PostProcessGeneralBeforeReference(CurrData)
            PostProcessTOC(CurrData)
            WholeData &= CurrData
            'b.Sujatha added for bug:9073 on 07-Feb-2017; E.Raja need to Revisit;
            '-----
            PostProcessDisplayRemovePageBreaks(WholeData)
            '------
            PostProcessReplaceMathEquations(WholeData)
            'E.Raja added on 18-May-2015; bug id 5178;
            ' PostProcessCleanupMathEquations(WholeData)
            ''''''''''''''''''''''''''
            PostProcessFootNote(WholeData)
            PostProcessAuthorGroup(WholeData)
            PostProcessTableConversion(WholeData)

            ''STAMS:6463; Balamurugan.K commented and updated on 09-11-2019;Added for Reference Update using EXE in preprocess;
            '''PostProcessReferences(WholeData)
            If IsNewSPICERefConv = True Then
                ''STAMS:7645;Balamurugan.K added on 29-June-2020;
                RefStylePageBreakAnchorReposition(WholeData)
                ''---
                ''STAMS:7946;Balamurugan.K added on 19-Aug-2020;
                Dim Refcoll As MatchCollection = Regex.Matches(WholeData, "<Ref_Style(.[^<>]*?)?>(.*?)</Ref_Style>", RegexOptions.Multiline Or RegexOptions.Singleline)
                For Each mtch As Match In Refcoll
                    Dim RefStyledata As String = mtch.Groups(0).ToString
                    ''Junk Removing;
                    If Regex.IsMatch(RefStyledata, " ") = True Then
                        RefStyledata = Regex.Replace(RefStyledata, " ", "")
                        WholeData = Replace(WholeData, mtch.Groups(0).Value, RefStyledata, , 1)
                    End If
                Next
                ''----
                'Sasikala.K added for STAMS-9341 on 27-04-2021;
                '---------
                WholeData = Regex.Replace(WholeData, "SPI_Double_Hyphen", "--", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                '---------
                WholeData = Regex.Replace(WholeData, "<!--<ce:note>(.*?)</ce:note>-->", "<ce:note>$1</ce:note>", RegexOptions.Compiled Or RegexOptions.Multiline Or RegexOptions.Singleline Or RegexOptions.IgnoreCase)
                WholeData = Regex.Replace(WholeData, "<Ref_Style(.[^<>]*?)?>(.*?)</Ref_Style>", "<!--<Ref_Style$1>$2</Ref_Style>-->")
                WholeData = Regex.Replace(WholeData, "<!--<sb:reference(.[^<>]*?)?>(.*?)</sb:reference>-->", "<sb:reference$1>$2</sb:reference>")
                WholeData = Regex.Replace(WholeData, "<!--<ce:other-ref(.[^<>]*?)?>(.*?)</ce:other-ref>-->", "<ce:other-ref$1>$2</ce:other-ref>")
                WholeData = Regex.Replace(WholeData, "</ce:label>.<ce:other-ref(.[^<>]*?)>", "</ce:label><ce:other-ref$1>", RegexOptions.IgnoreCase Or RegexOptions.Singleline Or RegexOptions.Multiline Or RegexOptions.Compiled)
                WholeData = Regex.Replace(WholeData, "</ce:label>.<sb:reference(.[^<>]*?)?>", "</ce:label><sb:reference$1>", RegexOptions.IgnoreCase Or RegexOptions.Singleline Or RegexOptions.Multiline Or RegexOptions.Compiled)
                WholeData = Regex.Replace(WholeData, "<S_P_i_sb:comment>", "<sb:comment>", RegexOptions.Singleline Or RegexOptions.Multiline Or RegexOptions.Compiled)
                WholeData = Regex.Replace(WholeData, "</S_P_i_sb:comment>", "</sb:comment>", RegexOptions.Singleline Or RegexOptions.Multiline Or RegexOptions.Compiled)
                WholeData = Regex.Replace(WholeData, "<!--SPi-New-SPICERef-Conv-->", "", RegexOptions.Singleline Or RegexOptions.Multiline Or RegexOptions.Compiled)
            Else
                PostProcessReferences(WholeData)
            End If
            ''---
            PostProcessGeneralAfterReference(WholeData)
            PostProcessNewIndexConversion(WholeData)
            PostProcessIndexConversion(WholeData)
            'BUG:7318; R.Venkadesh added on 18-04-2016; //ELS: LOC Component;
            PostProcessFBNonChapter(WholeData)
            CommentIndex(WholeData)
            'P.Parthiban commented for Bug:7214;on 29th MAR 2016;
            'DeleteDuplicateIndex(WholeData)
            'E.Raja added 06-nov-2014. Req.by Bhupathi 
            ReplaceTextboxattibutes(WholeData)
            'E.Raja added 02-Dec-2014. Req.by Bhupathi 
            RepositionEmailid(WholeData)
            System.IO.File.Delete(ExtractedXMLfile)
            'Redmine ID:206847;S.Chithra added on 12/04/2024;
            Dim txtboxmtch As MatchCollection
            txtboxmtch = Regex.Matches(WholeData, "<ce:textbox(.[^<]*?)>(.*?)</ce:textbox>")
            If txtboxmtch.Count > 0 Then
                For Cont As Integer = 0 To txtboxmtch.Count - 1
                    Dim rplBoxDta As String = "", BoxDta As String = ""
                    BoxDta = txtboxmtch.Item(Cont).Groups(2).ToString
                    rplBoxDta = txtboxmtch.Item(Cont).Groups(2).ToString
                    '  rplBoxDta = Regex.Replace(rplBoxDta, "</ce:inline-figure>", "</ce:inline-figure> "
                    'Redmine :263347;Aradadi updated on 15/10/2024;
                    rplBoxDta = Regex.Replace(rplBoxDta, "</ce:inline-figure>(\w+)", "</ce:inline-figure> $1")
                    WholeData = Regex.Replace(WholeData, Regex.Escape(BoxDta), rplBoxDta)
                    '---

                Next
            End If
            ''STAMS:6463; Balamurugan.K Added on 26-May-2020;
            WholeData = Regex.Replace(WholeData, "<!--SPi-New-SPICERef-Conv-->", "", RegexOptions.Singleline Or RegexOptions.Multiline Or RegexOptions.Compiled)
            ''---
            'E.Raja added 26-FEB-2015. Req.by Bhupathi 
            WholeData = Regex.Replace(WholeData, "\&mu;", "μ")
            'P.Parthiban validation added for Bug:5955; on 4th SEP 2015;
            WholeData = Regex.Replace(WholeData, "\&alpha;", "α")
            WholeData = Regex.Replace(WholeData, "\&beta;", "β")
            'E.Raja added on 12-May-2015.Req.by Bhupathi. Bug id 5158;
            WholeData = Regex.Replace(WholeData, "<ce:affiliation id=(.[^<>]*?)?><ce:textfn id=(.[^<>]*?)?>(.[^<>]*?)</ce:textfn><ce:label>(.[^<>]*?)</ce:label></ce:affiliation>", "<ce:affiliation id=$1><ce:label>$4</ce:label><ce:textfn id=$2>$3</ce:textfn></ce:affiliation>", RegexOptions.Singleline Or RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "<\?PI (.[^<>]*?)\?>", "", RegexOptions.IgnoreCase Or RegexOptions.Singleline)
            'E.Raja added on 25-Nov-2016; Remove space in <?DND ?>. Req.by Raja G.
            WholeData = Regex.Replace(WholeData, "<\?DND(\s*)\?>", "<?DND?>", RegexOptions.IgnoreCase Or RegexOptions.Singleline)
            'E.Raja; Bug id 8674;
            WholeData = Regex.Replace(WholeData, "</ce:def-term><ce:hsp sp=(.[^<>]*?)?/><ce:def-description", "</ce:def-term><ce:def-description", RegexOptions.IgnoreCase Or RegexOptions.Singleline)

            'E.Raja added on 14-Dec-2016; bug id 8799;
            '<ce:collaboration id="coll5" collaboration-id="B9780000001665000010-0dd706da517418b9dc4831801d2bf040"><ce:text id="tx0010">Collaboration text</ce:text>
            WholeData = Regex.Replace(WholeData, "<ce:collaboration (.[^<>]*?)?><\!\-\-<ce:text id=(.[^<>]*?)?>(.[^<>]*?)?</ce:text>\-\->", "<ce:collaboration $1><ce:text id=$2>$3</ce:text>", RegexOptions.Singleline Or RegexOptions.IgnoreCase)

            'E.Raja added on 25-Feb-2017; bug id 9220;
            '<QUERY xml:id="Q1">
            WholeData = Regex.Replace(WholeData, "<QUERY xml:id=""Q", "<query xml:id=""q", RegexOptions.Singleline Or RegexOptions.IgnoreCase)

            'E.Raja added on 12-May-2017; bug id 9691;
            WholeData = Regex.Replace(WholeData, "<\!\-\-<spiquery_opt_COMMENT(.[^<>]*?)?>(.*?)</spiquery_opt_COMMENT>\-\->", "", RegexOptions.Singleline Or RegexOptions.IgnoreCase)

            'E.Raja added on 13-Mar-2017; 5.5 DTD Demo; bug id 9306;
            WholeData = Replace(WholeData, "<!--<ce:alt-e-component", "<ce:alt-e-component")
            WholeData = Replace(WholeData, "</ce:alt-e-component>-->", "</ce:alt-e-component>")
            '<sb:date-accessed day="15" month="11" year="2006">Accessed 15 November 
            '---
            'R.Sugavaneshwaran added on 10th may 2018:STAMS-2175
            WholeData = Regex.Replace(WholeData, "<sb:date-accessed(.[^<>]*?)?>(.*?)</sb:date-accessed>", "<sb:date-accessed$1/>", RegexOptions.Singleline Or RegexOptions.IgnoreCase)
            ' WholeData = Regex.Replace(WholeData, "<sb:date-accessed(.[^<>]*?)?>(.*?)</sb:date-accessed>", "<sb:date-accessed $1/>", RegexOptions.Singleline Or RegexOptions.IgnoreCase)
            '---
            'P.Gopiram added line for STAMS:326 on 23rd August 2017
            '---
            'R.Sugavaneshwaran added on 10th may 2018:STAMS-2175
            WholeData = Regex.Replace(WholeData, "<sb:date-accessed(.[^<>]*?)/><sb:date>(.[^<>]*?)</sb:date>", "<sb:date>$2</sb:date><sb:date-accessed$1/>")
            ' WholeData = Regex.Replace(WholeData, "<sb:date-accessed(.[^<>]*?)/><sb:date>(.[^<>]*?)</sb:date>", "<sb:date>$2</sb:date><sb:date-accessed $1/>")
            '---
            'P.Gopiram added line for STAMS:390 on 4th sept 2017
            WholeData = Regex.Replace(WholeData, "</ce:inter-ref><ce:hsp (.[^<>]*?)/>(\: |\; |\, )(.*?)<sb:date>", "</ce:inter-ref>$3<sb:date>")
            WholeData = Regex.Replace(WholeData, "</info><SPiassociated-resource>(.*?)</SPiassociated-resource>", "$1</info>", RegexOptions.Singleline Or RegexOptions.IgnoreCase)
            'R.Sugavaneshwaran added on 22nd november 2018:STAMS-2887
            WholeData = Regex.Replace(WholeData, "<ce:source>(.*?)<ce:copyright(.[^<>]*?)?>(.*?)</ce:copyright></ce:source>", "<ce:source>$1</ce:source><ce:copyright$2>$3</ce:copyright>", RegexOptions.IgnoreCase)
            ''''''''''''''''''''

            'K.Shanmuga Sundaram Updated for BugNo:STAMS-5549 on 27th June 2019;
            '-----
            WholeData = Regex.Replace(WholeData, "<sb:e-host><sb:date>(.*?)</sb:date><sb:publisher>(.*?)</sb:publisher></sb:e-host>", "<sb:e-host><sb:publisher>$2</sb:publisher><sb:date>$1</sb:date></sb:e-host>", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
            '-----

            '<ce:source-text
            WholeData = Regex.Replace(WholeData, "<!--(<ce:source-text)", "$1", RegexOptions.Singleline Or RegexOptions.IgnoreCase Or RegexOptions.Multiline)
            WholeData = Regex.Replace(WholeData, "(ce:source-text>)-->", "$1", RegexOptions.Singleline Or RegexOptions.IgnoreCase Or RegexOptions.Multiline)

            ''STAMS:7010;Balamurugan.K added on 03-Mar-2020;Junk Removing;
            WholeData = Regex.Replace(WholeData, "﻿", "", RegexOptions.Singleline Or RegexOptions.IgnoreCase Or RegexOptions.Multiline)
            WholeData = Regex.Replace(WholeData, "﻿", "﻿", RegexOptions.Singleline Or RegexOptions.IgnoreCase Or RegexOptions.Multiline)
            ''---
            'K.Shanmuga Sundaram added for BugNo:STAMS-4152 on 28th Apr 2019;
            '-----
            If Regex.IsMatch(WholeData, "<Spiconflictofinterest></Spiconflictofinterest>", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline) Then
                'ce:conflict-of-interest
                Dim confl As String = Regex.Match(WholeData, "(<ce:conflict-of-interest( [^<>]*?)?>(.*?)</ce:conflict-of-interest>)", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline).Groups(1).Value.ToString()
                If Not String.IsNullOrEmpty(confl) Then
                    WholeData = Replace(WholeData, confl, "", , 1)
                    WholeData = Replace(WholeData, "<Spiconflictofinterest></Spiconflictofinterest>", confl, , 1)
                End If
            End If
            If Regex.IsMatch(WholeData, "<Spidataavailability></Spidataavailability>", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline) Then
                'ce:data-availability
                Dim data As String = Regex.Match(WholeData, "(<ce:data-availability( [^<>]*?)?>(.*?)</ce:data-availability>)", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline).Groups(1).Value.ToString()
                If Not String.IsNullOrEmpty(data) Then
                    WholeData = Replace(WholeData, data, "", , 1)
                    WholeData = Replace(WholeData, "<Spidataavailability></Spidataavailability>", data, , 1)
                End If
            End If
            If Regex.IsMatch(WholeData, "<Spilegend></Spilegend>", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline) Then
                Dim tboxColl As MatchCollection = Regex.Matches(WholeData, "(<ce:textbox( [^<>]*?)?>(.*?)</ce:textbox>)", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                For idtbox As Integer = 0 To tboxColl.Count - 1
                    Dim org As String = tboxColl.Item(idtbox).Groups(1).Value.ToString()
                    If Regex.IsMatch(org, "<ce:legend( [^<>]*?)?>(.*?)</ce:legend>", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline) AndAlso Regex.IsMatch(org, "<Spilegend></Spilegend>", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline) Then
                        Dim templegend As String = Regex.Match(org, "(<ce:legend( [^<>]*?)?>(.*?)</ce:legend>)", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline).Groups(1).Value.ToString()
                        If Not String.IsNullOrEmpty(templegend) Then
                            org = Replace(org, templegend, "", , 1)
                            org = Replace(org, "<Spilegend></Spilegend>", templegend, , 1)
                            WholeData = Replace(WholeData, tboxColl.Item(idtbox).Groups(1).Value.ToString(), org, , 1)
                        End If
                    End If
                Next
                'Sasikala.K commented for STAMS-5370 on 20-9-19;
                '---
                'Else
                '    Dim tboxColl As MatchCollection = Regex.Matches(WholeData, "(<ce:textbox( [^<>]*?)?>(.*?)</ce:textbox>)", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                '    For idtbox As Integer = 0 To tboxColl.Count - 1
                '        Dim org As String = tboxColl.Item(idtbox).Groups(1).Value.ToString()
                '        Dim temptbox As String = tboxColl.Item(idtbox).Groups(3).Value.ToString()
                '        If Regex.IsMatch(temptbox, "<ce:legend( [^<>]*?)?>(.*?)</ce:legend>", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline) AndAlso Regex.IsMatch(temptbox, "<ce:textbox-body( [^<>]*?)?>(.*?)</ce:textbox-body>", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline) Then
                '            Dim templegend As String = Regex.Match(temptbox, "(<ce:legend( [^<>]*?)?>(.*?)</ce:legend>)", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline).Groups(1).Value.ToString()
                '            org = Replace(org, templegend, "", , 1)
                '            org = Replace(org, "<ce:textbox-body", templegend & "<ce:textbox-body", , 1)
                '            WholeData = Replace(WholeData, tboxColl.Item(idtbox).Groups(1).Value.ToString(), org, , 1)
                '        End If
                '    Next
                '---
            End If

            'K.Shanmuga Sundaram added for BugNo:STAMS-4152 on 22nd May 2019;
            '-----
            Dim DTDVersion = Regex.Match(WholeData, "(<([^<>?]*?)?( version=""(.*?)"")( [^<>]*?)?>)", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline).Groups(4).Value.ToString()
            If Not String.IsNullOrEmpty(DTDVersion) AndAlso Regex.IsMatch(DTDVersion, "^(5\.6)$", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline) Then
                Dim mathsvgColl As MatchCollection = Regex.Matches(WholeData, "(<mml:math( [^<>]*?)?( altimg=""(.*?)"")( [^<>]*?)?>)", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                For idmath As Integer = 0 To mathsvgColl.Count - 1
                    Dim tempMath As String = mathsvgColl.Item(idmath).Groups(1).Value.ToString()
                    Dim svgMath As String = mathsvgColl.Item(idmath).Groups(4).Value.ToString()
                    If Not String.IsNullOrEmpty(svgMath) AndAlso Regex.IsMatch(svgMath, "(\.gif)", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline) Then
                        svgMath = Regex.Replace(svgMath, "(\.gif)", ".svg", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                        WholeData = Replace(WholeData, mathsvgColl.Item(idmath).Groups(4).Value.ToString(), svgMath, , 1)
                    End If
                Next
            End If
            WholeData = Replace(WholeData, "</ce:affiliation>, <ce:correspondence", "</ce:affiliation><ce:correspondence")
            '-----

            System.IO.File.WriteAllText(ExtractedXMLfile, WholeData, System.Text.Encoding.UTF8)
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
#End Region

#Region "RepositionEmailid(WholeData)"
    Shared Sub RepositionEmailid(ByRef WholeData As String)
        If Regex.IsMatch(WholeData, "<SPieaddress id=""(.[^<>]*?)"">", RegexOptions.Singleline Or RegexOptions.IgnoreCase) Then
            Dim Emailidsort As New SortedList
            ''E.Raja/K.Sasikala added for STAMS-5133 on 19-9-19;
            '---
            'Dim coll As MatchCollection = Regex.Matches(WholeData, "<ce:e-address id=""(.[^<>]*?)""( .[^<>]*?)?>(.*?)</ce:e-address>", RegexOptions.Multiline Or RegexOptions.Singleline)
            Dim coll As MatchCollection = Regex.Matches(WholeData, "<ce:e-address (.[^<>]*?)>(.*?)</ce:e-address>", RegexOptions.Multiline Or RegexOptions.Singleline)
            For Each mtch As Match In coll
                'Dim Eid As String = mtch.Groups(1).ToString
                Dim EidValue As String = Regex.Match(mtch.Groups(1).ToString, "id=""(.[^<>]*?)""", RegexOptions.IgnoreCase Or RegexOptions.Singleline).Groups(1).Value
                Dim Eid As String = EidValue
                '---
                Dim Eaddress As String = mtch.Groups(0).ToString
                Emailidsort.Add(Eid, Eaddress)
                WholeData = Replace(WholeData, mtch.ToString, "", , 1)
            Next
            Dim collection As MatchCollection = Regex.Matches(WholeData, "<SPieaddress id=""(.[^<>]*?)""></SPieaddress>", RegexOptions.Multiline Or RegexOptions.Singleline)
            For Each mtch As Match In collection
                For Each key1 In Emailidsort
                    Dim Eid As String = mtch.Groups(1).ToString
                    If key1.key = Eid.ToString.Trim Then
                        WholeData = Replace(WholeData, mtch.ToString, key1.value, , 1)
                    End If
                Next
            Next
            ''E.Raja/K.Sasikala added for STAMS-5133 on 19-9-19;
            '---
            Dim EIDcollection As MatchCollection = Regex.Matches(WholeData, "<SPieaddress (.[^<>]*?)/>", RegexOptions.Multiline Or RegexOptions.Singleline)
            For Each mtch As Match In EIDcollection
                For Each key1 In Emailidsort
                    Dim Eid As String = mtch.Groups(1).ToString
                    Dim EidValue As String = Regex.Match(mtch.Groups(1).ToString, "id=""(.[^<>]*?)""", RegexOptions.IgnoreCase Or RegexOptions.Singleline).Groups(1).Value
                    If key1.key = EidValue.ToString.Trim Then
                        WholeData = Replace(WholeData, mtch.ToString, key1.value, , 1)
                    End If
                Next
            Next
            '---
            'bug id 8799; E.Raja ;
            'WholeData = Regex.Replace(WholeData, "<ce:e-address id=""(.[^<>]*?)"">", "<ce:e-address>", RegexOptions.IgnoreCase)
            'bug id 8674; E.Raja;
            WholeData = Regex.Replace(WholeData, "<SPieaddress id=""(.[^<>]*?)""></SPieaddress>", "", RegexOptions.IgnoreCase)
            ''E.Raja/K.Sasikala added for STAMS-5133 on 19-9-19;
            '---
            WholeData = Regex.Replace(WholeData, "<SPieaddress id=""(.[^<>]*?)""/>", "", RegexOptions.IgnoreCase)
            '--
        End If
    End Sub
#End Region

#Region "TableAnchorReposition(WholeData)"
    Shared Function TableAnchorReposition(ByRef CurrData As String) As String
        Dim coll As MatchCollection = Regex.Matches(CurrData, "<ce:table (.[^<>]*?)>(.*?)</ce:table>", RegexOptions.Multiline Or RegexOptions.Singleline)
        For Each mtch As Match In coll
            Dim tabledata As String = mtch.Groups(0).ToString
            '<ce:anchor id="pp:402 np:403" role="page-break"></ce:anchor>
            ''STAMS:7509;Balamurugan.K added on 03-June-2020;
            Dim EntryAnchormatch As MatchCollection = Regex.Matches(tabledata, "<entry(.[^<>]*?)?>(.[^<>]*?)?<ce:anchor(.[^<>]*?)?>", RegexOptions.Singleline Or RegexOptions.IgnoreCase)
            If EntryAnchormatch.Count > 0 Then
                Continue For
            End If
            ''---
            If Regex.IsMatch(tabledata, "<ce:anchor(.[^<>]*?)?>") = True Then
                Dim Anchormatch As MatchCollection = Regex.Matches(tabledata, "<ce:anchor (.[^<>]*?)>(.*?)</ce:anchor>", RegexOptions.Singleline Or RegexOptions.IgnoreCase)
                If Anchormatch.Count > 0 Then
                    For Each anchor As Match In Anchormatch
                        Dim anchordata As String = anchor.Value
                        tabledata = Replace(tabledata, anchordata, "", , 1)
                        tabledata = tabledata & anchordata
                        ''STAMS:8660;Balamurugan.K Commented on 09-Dec-2020;
                        ''CurrData = Replace(CurrData, mtch.Groups(0).Value, tabledata, , 1)
                    Next
                    ''STAMS:8660;Balamurugan.K Added on 09-Dec-2020;
                    CurrData = Replace(CurrData, mtch.Groups(0).Value, tabledata, , 1)
                    ''---
                End If
            End If
        Next
        Return CurrData
    End Function
#End Region

#Region "ReplaceTextboxattibutes(WholeData)"
    Shared Sub ReplaceTextboxattibutes(ByRef WholeData As String)
        Dim coll As MatchCollection = Regex.Matches(WholeData, "<ce:textbox (.[^<>]*?)>(.*?)</ce:textbox>", RegexOptions.Multiline Or RegexOptions.Singleline)
        '<ce:textbox id="b0010" role="alt1" semantic_role="medical_topic">
        For Each mtch As Match In coll
            Dim temp As String = mtch.Groups(1).ToString
            If Regex.IsMatch(temp, "semantic_role") = True Then
                temp = Regex.Replace(temp, "(\s)role=""(.[^<>]*?)""", "")
                temp = Regex.Replace(temp, "semantic_", "")
                WholeData = Replace(WholeData, mtch.Groups(1).Value, temp, , 1)
            End If
        Next

        'E.Raja added to remove the leading space of <SPICompact> on 08-Nov-2014. Req. by Bhupathi.
        Dim coll1 As MatchCollection = Regex.Matches(WholeData, "<ce:figure(.[^<>]*?)>(.*?)</ce:figure>", RegexOptions.Multiline Or RegexOptions.Singleline)
        For Each compactmtch As Match In coll1
            Dim temp As String = compactmtch.Groups(2).ToString
            If temp.Trim <> "" And Regex.IsMatch(temp, "<SPICompact>") = True Then
                temp = Regex.Replace(temp, "(\s+)<SPICompact>", "<SPICompact>", RegexOptions.IgnoreCase Or RegexOptions.Singleline)
                temp = Regex.Replace(temp, "<SPICompact>(.*?)</SPICompact>", "")
                WholeData = Replace(WholeData, compactmtch.Groups(2).Value, temp, , 1)
            End If
        Next

        Dim compcoll As MatchCollection = Regex.Matches(WholeData, "<ce:simple-para(.[^<>]*?)?>(.*?)</ce:simple-para>", RegexOptions.Multiline Or RegexOptions.Singleline)
        For Each spicompactmtch As Match In compcoll
            Dim temp As String = spicompactmtch.Groups(2).ToString
            If temp.Trim <> "" And Regex.IsMatch(temp, "<SPICompact>") = True Then
                temp = Regex.Replace(temp, "(\s+)<SPICompact>", "<SPICompact>", RegexOptions.IgnoreCase Or RegexOptions.Singleline)
                temp = Regex.Replace(temp, "<SPICompact>(.*?)</SPICompact>", "")
                WholeData = Replace(WholeData, spicompactmtch.Groups(2).Value, temp, , 1)
            End If
        Next

    End Sub
#End Region

#Region "Shared Sub PostProcessIndexConversion()"
    ''' <summary>
    ''' InDesign Post Process
    ''' </summary>
    ''' <remarks></remarks>
    ''' <History>
    ''' '2009.09.17; R.Thinagaran; Bug:1076; Elsevier XML coding to be replaced from the Marked Index entries
    ''' </History>
    Shared Sub PostProcessIndexConversion(ByRef wholedata As String)

        wholedata = Regex.Replace(wholedata, "<ce:italic>", "(ce:italic)")
        wholedata = Regex.Replace(wholedata, "</ce:italic>", "(/ce:italic)")
        wholedata = Regex.Replace(wholedata, "<ce:bold>", "(ce:bold)")
        wholedata = Regex.Replace(wholedata, "</ce:bold>", "(/ce:bold)")
        wholedata = Regex.Replace(wholedata, "<ce:italic-bold>", "(ce:italic-bold)")
        wholedata = Regex.Replace(wholedata, "</ce:italic-bold>", "(/ce:italic-bold)")
        wholedata = Regex.Replace(wholedata, "<ce:bold-italic>", "(ce:bold-italic)")
        wholedata = Regex.Replace(wholedata, "</ce:bold-italic>", "(/ce:bold-italic)")
        wholedata = Regex.Replace(wholedata, "<ce:inf>", "(ce:inf)")
        wholedata = Regex.Replace(wholedata, "</ce:inf>", "(/ce:inf)")
        wholedata = Regex.Replace(wholedata, "<ce:sup>", "(ce:sup)")
        wholedata = Regex.Replace(wholedata, "</ce:sup>", "(/ce:sup)")
        wholedata = Regex.Replace(wholedata, "<ce:underline>", "(ce:underline)")
        wholedata = Regex.Replace(wholedata, "</ce:underline>", "(/ce:underline)")
        wholedata = Regex.Replace(wholedata, "<ce:small-caps>", "(ce:small-caps)")
        'Sasikala.K added for STAMS-9449 21-05-2021;
        For Each IMatch As Match In Regex.Matches(wholedata, "\{i\}", RegexOptions.IgnoreCase Or RegexOptions.Compiled Or RegexOptions.Multiline)
            Dim replacevalue As String = IMatch.ToString
            replacevalue = Regex.Replace(replacevalue, "{i}", "S_P_I_itag")
            wholedata = Replace(wholedata, IMatch.Value, replacevalue, , 1)
        Next
        ''--
        wholedata = Regex.Replace(wholedata, "<i>", "{i}")
        wholedata = Regex.Replace(wholedata, "</i>", "{/i}")
        wholedata = Regex.Replace(wholedata, "<b>", "{b}")
        wholedata = Regex.Replace(wholedata, "</b>", "{/b}")
        wholedata = Regex.Replace(wholedata, "<sup>", "{sup}")
        wholedata = Regex.Replace(wholedata, "</sup>", "{/sup}")
        wholedata = Regex.Replace(wholedata, "<sub>", "{sub}")
        wholedata = Regex.Replace(wholedata, "</sub>", "{/sub}")

        Dim MainCount As Integer = 9000
        Dim SubCount As Integer = 9000
        Dim SubSubCount As Integer = 9000
        Dim SubSubSubCount As Integer = 9000
        Dim MainIdMatch As Match = Regex.Match(wholedata, "<MAIN>")
        While MainIdMatch.Success
            Dim replacevalue As String = MainIdMatch.ToString
            replacevalue = Regex.Replace(replacevalue, "<MAIN>", "<MAIN id=""m" & MainCount & """>")
            wholedata = Replace(wholedata, MainIdMatch.Value, replacevalue, , 1)
            MainIdMatch = Regex.Match(wholedata, "<MAIN>")
            MainCount += 1
        End While

        Dim SubIdMatch As Match = Regex.Match(wholedata, "<SUB>")
        While SubIdMatch.Success
            Dim replacevalue As String = SubIdMatch.ToString
            replacevalue = Regex.Replace(replacevalue, "<SUB>", "<SUB id=""s" & SubCount & """>")
            wholedata = Replace(wholedata, SubIdMatch.Value, replacevalue, , 1)
            SubIdMatch = Regex.Match(wholedata, "<SUB>")
            SubCount += 1
        End While

        Dim SubSubIdMatch As Match = Regex.Match(wholedata, "<SUBSUB>")
        While SubSubIdMatch.Success
            Dim replacevalue As String = SubSubIdMatch.ToString
            replacevalue = Regex.Replace(replacevalue, "<SUBSUB>", "<SUBSUB id=""ss" & SubSubCount & """>")
            wholedata = Replace(wholedata, SubSubIdMatch.Value, replacevalue, , 1)
            SubSubIdMatch = Regex.Match(wholedata, "<SUBSUB>")
            SubSubCount += 1
        End While

        Dim SubSubsubIdMatch As Match = Regex.Match(wholedata, "<SUBSUBSUB>")
        While SubSubsubIdMatch.Success
            Dim replacevalue As String = SubSubsubIdMatch.ToString
            replacevalue = Regex.Replace(replacevalue, "<SUBSUBSUB>", "<SUBSUBSUB id=""sss" & SubSubSubCount & """>")
            wholedata = Replace(wholedata, SubSubsubIdMatch.Value, replacevalue, , 1)
            SubSubsubIdMatch = Regex.Match(wholedata, "<SUBSUBSUB>")
            SubSubSubCount += 1
        End While

        Dim SubSubSubMainSub As Match = Regex.Match(wholedata, "<SUBSUBSUB([^<]*?)><\?MAIN(\s)?([^<]*?)\?><\?SUB(\s)?([^<]*?)\?><\?SUBSUB(\s)?([^<]*?)\?><\?SUBSUBSUB(\s)?([^<]*?)\?></SUBSUBSUB>")
        While SubSubSubMainSub.Success
            Dim Replacevalue As String = SubSubSubMainSub.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUBSUBSUB([^<]*?)><\?MAIN(\s)?([^<]*?)\?><\?SUB(\s)?([^<]*?)\?><\?SUBSUB(\s)?([^<]*?)\?><\?SUBSUBSUB(\s)?([^<]*?)\?></SUBSUBSUB>", "<ce:index-flag id=""""><ce:index-flag-term>$3</ce:index-flag-term><ce:index-flag id=""""><ce:index-flag-term>$5</ce:index-flag-term><ce:index-flag id=""""><ce:index-flag-term>$7</ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$9</ce:index-flag-term></ce:index-flag></ce:index-flag></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, SubSubSubMainSub.Value, Replacevalue, , 1)
            SubSubSubMainSub = Regex.Match(wholedata, "<SUBSUBSUB([^<]*?)><\?MAIN(\s)?([^<]*?)\?><\?SUB(\s)?([^<]*?)\?><\?SUBSUB(\s)?([^<]*?)\?><\?SUBSUBSUB(\s)?([^<]*?)\?></SUBSUBSUB>")
        End While

        Dim SubSubSubProcess_match As Match = Regex.Match(wholedata, "<SUBSUBSUB([^<]*?)><\?MAIN([^<]*?)\?><\?SUB([^<]*?)\?><\?SUBSUB([^<]*?)\?>([^<]*?)</SUBSUBSUB>")
        While SubSubSubProcess_match.Success
            Dim Replacevalue As String = SubSubSubProcess_match.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUBSUBSUB([^<]*?)><\?MAIN(\s)?(.*?)\?><\?SUB(\s)?(.*?)\?><\?SUBSUB(\s)?(.*?)\?>(.*?)</SUBSUBSUB>", "$8<ce:index-flag id=""""><ce:index-flag-term>$3</ce:index-flag-term><ce:index-flag id=""""><ce:index-flag-term>$5</ce:index-flag-term><ce:index-flag id=""""><ce:index-flag-term>$7</ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$8</ce:index-flag-term></ce:index-flag></ce:index-flag></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, SubSubSubProcess_match.Value, Replacevalue, , 1)
            SubSubSubProcess_match = Regex.Match(wholedata, "<SUBSUBSUB([^<]*?)><\?MAIN([^<]*?)\?><\?SUB([^<]*?)\?><\?SUBSUB([^<]*?)\?>([^<]*?)</SUBSUBSUB>")
        End While

        Dim SubSubSubProcess_match1 As Match = Regex.Match(wholedata, "<SUBSUBSUB([^<]*?)>([^<]*?)<\?MAIN([^<]*?)\?><\?SUB([^<]*?)\?><\?SUBSUB([^<]*?)\?></SUBSUBSUB>")
        While SubSubSubProcess_match1.Success
            Dim Replacevalue As String = SubSubSubProcess_match1.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUBSUBSUB([^<]*?)>(.*?)<\?MAIN(\s)?(.*?)\?><\?SUB(\s)?(.*?)\?><\?SUBSUB(\s)?(.*?)\?></SUBSUBSUB>", "$2<ce:index-flag id=""""><ce:index-flag-term>$4</ce:index-flag-term><ce:index-flag id=""""><ce:index-flag-term>$6</ce:index-flag-term><ce:index-flag id=""""><ce:index-flag-term>$8</ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$2</ce:index-flag-term></ce:index-flag></ce:index-flag></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, SubSubSubProcess_match1.Value, Replacevalue, , 1)
            SubSubSubProcess_match1 = Regex.Match(wholedata, """<SUBSUBSUB([^<]*?)>([^<]*?)<\?MAIN([^<]*?)\?><\?SUB([^<]*?)\?><\?SUBSUB([^<]*?)\?></SUBSUBSUB>")
        End While
        Dim SubSubMainSub As Match = Regex.Match(wholedata, "<SUBSUB([^<]*?)><\?MAIN(\s)?([^<]*?)\?><\?SUB(\s)?([^<]*?)\?><\?SUBSUB(\s)?([^<]*?)\?></SUBSUB>")
        While SubSubMainSub.Success
            Dim Replacevalue As String = SubSubMainSub.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUBSUB([^<]*?)><\?MAIN(\s)?(.*?)\?><\?SUB(\s)?(.*?)\?><\?SUBSUB(\s)?(.*?)\?></SUBSUB>", "<ce:index-flag id=""""><ce:index-flag-term>$3</ce:index-flag-term><ce:index-flag id=""""><ce:index-flag-term>$5</ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$7</ce:index-flag-term></ce:index-flag></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, SubSubMainSub.Value, Replacevalue, , 1)
            SubSubMainSub = Regex.Match(wholedata, "<SUBSUB([^<]*?)><\?MAIN(\s)?([^<]*?)\?><\?SUB(\s)?([^<]*?)\?><\?SUBSUB(\s)?([^<]*?)\?></SUBSUB>")
        End While

        Dim SubSubProcess_match As Match = Regex.Match(wholedata, "<SUBSUB([^<]*?)><\?MAIN([^<]*?)\?><\?SUB([^<]*?)\?>([^<]*?)</SUBSUB>")
        While SubSubProcess_match.Success
            Dim Replacevalue As String = SubSubProcess_match.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUBSUB([^<]*?)><\?MAIN(\s)?(.*?)\?><\?SUB(\s)?(.*?)\?>(.*?)</SUBSUB>", "$6<ce:index-flag id=""""><ce:index-flag-term>$3</ce:index-flag-term><ce:index-flag id=""""><ce:index-flag-term>$5</ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$6</ce:index-flag-term></ce:index-flag></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, SubSubProcess_match.Value, Replacevalue, , 1)
            SubSubProcess_match = Regex.Match(wholedata, "<SUBSUB([^<]*?)><\?MAIN([^<]*?)\?><\?SUB([^<]*?)\?>([^<]*?)</SUBSUB>")
        End While

        Dim SubSubProcess_match1 As Match = Regex.Match(wholedata, "<SUBSUB([^<]*?)>([^<]*?)<\?MAIN([^<]*?)\?><\?SUB([^<]*?)\?></SUBSUB>")
        While SubSubProcess_match1.Success
            Dim Replacevalue As String = SubSubProcess_match1.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUBSUB([^<]*?)>(.*?)<\?MAIN(\s)?(.*?)\?><\?SUB(\s)?(.*?)\?></SUBSUB>", "$2<ce:index-flag id=""""><ce:index-flag-term>$4</ce:index-flag-term><ce:index-flag id=""""><ce:index-flag-term>$6</ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$2</ce:index-flag-term></ce:index-flag></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, SubSubProcess_match1.Value, Replacevalue, , 1)
            SubSubProcess_match1 = Regex.Match(wholedata, "<SUBSUB([^<]*?)>([^<]*?)<\?MAIN([^<]*?)\?><\?SUB([^<]*?)\?></SUBSUB>")
        End While

        Dim MainSubMain As Match = Regex.Match(wholedata, "<SUB([^<]*?)><\?MAIN([^<]*?)\?><\?SUB([^<]*?)\?></SUB>")
        While MainSubMain.Success
            Dim Replacevalue As String = MainSubMain.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUB([^<]*?)><\?MAIN(\s)(.*?)\?><\?SUB(\s)(.*?)\?></SUB>", "<ce:index-flag id=""""><ce:index-flag-term>$3</ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$5</ce:index-flag-term></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, MainSubMain.Value, Replacevalue, , 1)
            MainSubMain = Regex.Match(wholedata, "<SUB([^<]*?)><\?MAIN([^<]*?)\?><\?SUB([^<]*?)\?></SUB>")
        End While

        Dim MainSub_match As Match = Regex.Match(wholedata, "<SUB([^<]*?)><\?MAIN([^<]*?)\?>([^<]*?)</SUB>")
        While MainSub_match.Success
            Dim Replacevalue As String = MainSub_match.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUB([^<]*?)><\?MAIN(\s)?(.*?)\?>([^<]*?)</SUB>", "$4<ce:index-flag id=""""><ce:index-flag-term>$3</ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$4</ce:index-flag-term></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, MainSub_match.Value, Replacevalue, , 1)
            MainSub_match = Regex.Match(wholedata, "<SUB([^<]*?)><\?MAIN([^<]*?)\?>([^<]*?)</SUB>")
        End While

        Dim MainSub_match1 As Match = Regex.Match(wholedata, "<SUB([^<]*?)>([^<]*?)<\?MAIN([^<]*?)\?></SUB>")
        While MainSub_match1.Success
            Dim Replacevalue As String = MainSub_match1.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUB([^<]*?)>([^<]*?)<\?MAIN(\s)?(.*?)\?></SUB>", "$2<ce:index-flag id=""""><ce:index-flag-term>$4</ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$2</ce:index-flag-term></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, MainSub_match1.Value, Replacevalue, , 1)
            MainSub_match1 = Regex.Match(wholedata, "<SUB([^<]*?)>([^<]*?)<\?MAIN([^<]*?)\?></SUB>")
        End While

        Dim MainMain_match As Match = Regex.Match(wholedata, "<MAIN([^<]*?)><\?MAIN([^<]*?)\?></MAIN>")
        While MainMain_match.Success
            Dim Replacevalue As String = MainMain_match.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<MAIN([^<]*?)><\?MAIN(\s)?(.*?)\?></MAIN>", "<ce:index-flag$1><ce:index-flag-term>$3</ce:index-flag-term></ce:index-flag>")
            wholedata = Replace(wholedata, MainMain_match.Value, Replacevalue, , 1)
            MainMain_match = Regex.Match(wholedata, "<MAIN([^<]*?)><\?MAIN([^<]*?)\?></MAIN>")
        End While

        Dim MainMainContent_match As Match = Regex.Match(wholedata, "<MAIN([^<]*?)><\?MAIN([^<]*?)\?>(.*?)</MAIN>")
        While MainMainContent_match.Success
            Dim Replacevalue As String = MainMainContent_match.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<MAIN([^<]*?)><\?MAIN(\s)?(.*?)\?>(.*?)</MAIN>", "<MAIN$1>$4</MAIN>")
            wholedata = Replace(wholedata, MainMainContent_match.Value, Replacevalue, , 1)
            MainMainContent_match = Regex.Match(wholedata, "<MAIN([^<]*?)><\?MAIN([^<]*?)\?>(.*?)</MAIN>")
        End While

        Dim MainContentMain_match As Match = Regex.Match(wholedata, "<MAIN([^<]*?)>([^<]*?)<\?MAIN([^<]*?)\?></MAIN>")
        While MainContentMain_match.Success
            Dim Replacevalue As String = MainContentMain_match.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<MAIN([^<]*?)>(.*?)<\?MAIN(\s)?(.*?)\?></MAIN>", "<MAIN$1>$2</MAIN>")

            wholedata = Replace(wholedata, MainContentMain_match.Value, Replacevalue, , 1)
            MainContentMain_match = Regex.Match(wholedata, "<MAIN([^<]*?)>([^<]*?)<\?MAIN([^<]*?)\?></MAIN>")
        End While

        Dim Main_match As Match = Regex.Match(wholedata, "<MAIN([^<]*?)>([^<]*?)</MAIN>")
        While Main_match.Success
            Dim Replacevalue As String = Main_match.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<MAIN([^<]*?)>(.*?)</MAIN>", "$2<ce:index-flag$1><ce:index-flag-term>$2</ce:index-flag-term></ce:index-flag>")
            wholedata = Replace(wholedata, Main_match.Value, Replacevalue, , 1)
            Main_match = Regex.Match(wholedata, "<MAIN([^<]*?)>([^<]*?)</MAIN>")
        End While

        Dim SubContent_match As Match = Regex.Match(wholedata, "<SUB([^<]*?)>([^<]*?)</SUB>")
        While SubContent_match.Success
            Dim Replacevalue As String = SubContent_match.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUB([^<]*?)>(.*?)</SUB>", "<ce:index-flag id=""""><ce:index-flag-term><MAIN-ERROR/></ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$2</ce:index-flag-term></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, SubContent_match.Value, Replacevalue, , 1)
            SubContent_match = Regex.Match(wholedata, "<SUB([^<]*?)>([^<]*?)</SUB>")
        End While

        Dim MainProcess_match As Match = Regex.Match(wholedata, "<\?MAIN([^<]*?)\?>")
        While MainProcess_match.Success
            Dim Replacevalue As String = MainProcess_match.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<\?MAIN(\s)?(.*?)\?>", "<ce:index-flag id=""""><ce:index-flag-term><MAIN-ERROR>$2</MAIN-ERROR></ce:index-flag-term></ce:index-flag>")
            wholedata = Replace(wholedata, MainProcess_match.Value, Replacevalue, , 1)
            MainProcess_match = Regex.Match(wholedata, "<\?MAIN([^<]*?)\?>")
        End While

        Dim Dummyid As Integer = 1
        Dim Dummyquote As Match = Regex.Match(wholedata, "<ce:index-flag id="""">")
        While Dummyquote.Success
            Dim Replacevalue As String = Dummyquote.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<ce:index-flag id="""">", "<ce:index-flag id=""if" & ids(Dummyid) & """>")
            wholedata = Replace(wholedata, Dummyquote.Value, Replacevalue, , 1)
            Dummyquote = Regex.Match(wholedata, "<ce:index-flag id="""">")
            Dummyid += 1
        End While

        wholedata = Regex.Replace(wholedata, "</ce:index-flag>(\s)<ce:index-flag", "</ce:index-flag><ce:index-flag")
        wholedata = Regex.Replace(wholedata, "\(ce:italic\)", "<ce:italic>")
        wholedata = Regex.Replace(wholedata, "\(/ce:italic\)", "</ce:italic>")
        wholedata = Regex.Replace(wholedata, "\(ce:bold\)", "<ce:bold>")
        wholedata = Regex.Replace(wholedata, "\(/ce:bold\)", "</ce:bold>")
        wholedata = Regex.Replace(wholedata, "\(ce:italic\-bold\)", "<ce:italic-bold>")
        wholedata = Regex.Replace(wholedata, "\(/ce:italic\-bold\)", "</ce:italic-bold>")
        wholedata = Regex.Replace(wholedata, "\(ce:bold\-italic\)", "<ce:bold-italic>")
        wholedata = Regex.Replace(wholedata, "\(/ce:bold\-italic\)", "</ce:bold-italic>")
        wholedata = Regex.Replace(wholedata, "\(ce:inf\)", "<ce:inf>")
        wholedata = Regex.Replace(wholedata, "\(/ce:inf\)", "</ce:inf>")
        wholedata = Regex.Replace(wholedata, "\(ce:sup\)", "<ce:sup>")
        wholedata = Regex.Replace(wholedata, "\(/ce:sup\)", "</ce:sup>")
        wholedata = Regex.Replace(wholedata, "\(ce:underline\)", "<ce:underline>")
        wholedata = Regex.Replace(wholedata, "\(/ce:underline\)", "</ce:underline>")
        wholedata = Regex.Replace(wholedata, "\(ce:small-caps\)", "<ce:small-caps>")
        wholedata = Regex.Replace(wholedata, "\(/ce:small-caps\)", "</ce:small-caps>")

        'Added for Bug:2552&3315; By P.Parthiban on 20th June 2012 & 7th Jan 2013;
        wholedata = Regex.Replace(wholedata, "</ce:bold>(\s)?<ce:bold>", "$1")
        wholedata = Regex.Replace(wholedata, "</ce:italic>(\s)?<ce:italic>", "$1")
        wholedata = Regex.Replace(wholedata, "  ", " ")

        wholedata = Regex.Replace(wholedata, "\{i\}", "<ce:italic>")
        wholedata = Regex.Replace(wholedata, "\{/i\}", "</ce:italic>")
        'Sasikala.K added for STAMS-9449 21-05-2021;
        wholedata = Regex.Replace(wholedata, "S_P_I_itag", "{i}")
        ''---
        wholedata = Regex.Replace(wholedata, "\{b\}", "<ce:bold>")
        wholedata = Regex.Replace(wholedata, "\{/b\}", "</ce:bold>")
        wholedata = Regex.Replace(wholedata, "\{sup\}", "<ce:sup>")
        wholedata = Regex.Replace(wholedata, "\{/sup\}", "</ce:sup>")
        wholedata = Regex.Replace(wholedata, "\{sub\}", "<ce:sub>")
        wholedata = Regex.Replace(wholedata, "\{/sub\}", "</ce:sub>")
    End Sub

    'BUG:7318; R.Venkadesh added on 18-04-2016; //ELS: LOC Component;
    Shared Sub PostProcessFBNonChapter(ByRef wholedata As String)
        Dim idAGroupCollectionString As String = ""
        Dim EAddress As New ArrayList
        Dim idFBNonChapter As MatchCollection = Regex.Matches(wholedata, "<fb-non-chapter (.*?)>(.*?)</fb-non-chapter>", RegexOptions.Singleline Or RegexOptions.IgnoreCase)
        If Not idFBNonChapter.Count = 0 Then
            Dim idAuthorGroup As MatchCollection = Regex.Matches(wholedata, "<ce:author-group (.*?)>(.*?)</ce:author-group>", RegexOptions.Singleline Or RegexOptions.IgnoreCase)
            If Not idAuthorGroup.Count = 0 Then
                For Each idAGroupCollection As Match In idAuthorGroup
                    idAGroupCollectionString = idAGroupCollection.Value
                    Dim ceAddressCollection As MatchCollection = Regex.Matches(idAGroupCollection.Value, "<ce:e-address (.*?)>(.*?)</ce:e-address>", RegexOptions.Singleline Or RegexOptions.IgnoreCase)
                    For Each EachAddress As Match In ceAddressCollection
                        EAddress.Add(EachAddress.Value)
                    Next
                    For TempCount As Integer = 0 To EAddress.Count - 1
                        Dim EAddressID As String = EAddress(TempCount)
                        EAddressID = Regex.Match(EAddressID, "<ce:e-address (.*?)>(.*?)</ce:e-address>", RegexOptions.Singleline Or RegexOptions.IgnoreCase).Groups(1).Value
                        EAddressID = Regex.Match(EAddressID, "id=""(.*?)""", RegexOptions.Singleline Or RegexOptions.IgnoreCase).Groups(1).Value

                        'added for bug:8345; k.hemachandiran; 27/09/2016;
                        idAGroupCollectionString = Replace(idAGroupCollectionString, EAddress(TempCount), "", , 1)
                        '----
                        idAGroupCollectionString = Regex.Replace(idAGroupCollectionString, "<!--<e-address ID=""" & EAddressID & """>-->", EAddress(TempCount), RegexOptions.Singleline Or RegexOptions.IgnoreCase)
                        'idAGroupCollectionString = Regex.Replace(idAGroupCollectionString, "; " & EAddress(TempCount), "", RegexOptions.Singleline Or RegexOptions.IgnoreCase)

                        'added for bug:8345; k.hemachandiran; 27/09/2016;
                        idAGroupCollectionString = Regex.Replace(idAGroupCollectionString, "</ce:affiliation>(.[^<>]*?)</ce:author-group>", "</ce:affiliation></ce:author-group>", RegexOptions.Singleline Or RegexOptions.IgnoreCase)
                    Next

                    wholedata = Replace(wholedata, idAGroupCollection.Value, idAGroupCollectionString, , 1)
                    EAddress.Clear()
                Next
                'added for bug:8345; k.hemachandiran; 27/09/2016;
                wholedata = Regex.Replace(wholedata, "</ce:author-group>(.[^<>]*?)<ce:author-group id=""(.*?)"">", "</ce:author-group><ce:author-group id=""$2"">")
            End If
        End If
    End Sub

    'P.Parthiban added for new index entry like MAIN1, SUB1...on 20th Aug 2013;
    Shared Sub PostProcessNewIndexConversion(ByRef wholedata As String)
        wholedata = Regex.Replace(wholedata, "<ce:italic>", "(ce:italic)")
        wholedata = Regex.Replace(wholedata, "</ce:italic>", "(/ce:italic)")
        wholedata = Regex.Replace(wholedata, "<ce:bold>", "(ce:bold)")
        wholedata = Regex.Replace(wholedata, "</ce:bold>", "(/ce:bold)")
        wholedata = Regex.Replace(wholedata, "<ce:italic-bold>", "(ce:italic-bold)")
        wholedata = Regex.Replace(wholedata, "</ce:italic-bold>", "(/ce:italic-bold)")
        wholedata = Regex.Replace(wholedata, "<ce:bold-italic>", "(ce:bold-italic)")
        wholedata = Regex.Replace(wholedata, "</ce:bold-italic>", "(/ce:bold-italic)")
        wholedata = Regex.Replace(wholedata, "<ce:inf>", "(ce:inf)")
        wholedata = Regex.Replace(wholedata, "</ce:inf>", "(/ce:inf)")
        wholedata = Regex.Replace(wholedata, "<ce:sup>", "(ce:sup)")
        wholedata = Regex.Replace(wholedata, "</ce:sup>", "(/ce:sup)")
        wholedata = Regex.Replace(wholedata, "<ce:underline>", "(ce:underline)")
        wholedata = Regex.Replace(wholedata, "</ce:underline>", "(/ce:underline)")
        wholedata = Regex.Replace(wholedata, "<ce:small-caps>", "(ce:small-caps)")

        'Sasikala.K added for STAMS-9449 21-05-2021;
        For Each IMatch As Match In Regex.Matches(wholedata, "\{i\}", RegexOptions.IgnoreCase Or RegexOptions.Compiled Or RegexOptions.Multiline)
            Dim replacevalue As String = IMatch.ToString
            replacevalue = Regex.Replace(replacevalue, "{i}", "S_P_I_itag")
            wholedata = Replace(wholedata, IMatch.Value, replacevalue, , 1)
        Next
        ''---
        wholedata = Regex.Replace(wholedata, "<i>", "{i}")
        wholedata = Regex.Replace(wholedata, "</i>", "{/i}")
        wholedata = Regex.Replace(wholedata, "<b>", "{b}")
        wholedata = Regex.Replace(wholedata, "</b>", "{/b}")
        wholedata = Regex.Replace(wholedata, "<sup>", "{sup}")
        wholedata = Regex.Replace(wholedata, "</sup>", "{/sup}")
        wholedata = Regex.Replace(wholedata, "<sub>", "{sub}")
        wholedata = Regex.Replace(wholedata, "</sub>", "{/sub}")

        Dim MainCount As Integer = 9000
        Dim SubCount As Integer = 9000
        Dim SubSubCount As Integer = 9000
        Dim SubSubSubCount As Integer = 9000
        Dim MainIdMatch As Match = Regex.Match(wholedata, "<MAIN1>")
        While MainIdMatch.Success
            Dim replacevalue As String = MainIdMatch.ToString
            replacevalue = Regex.Replace(replacevalue, "<MAIN1>", "<MAIN1 id=""m1" & MainCount & """>")
            wholedata = Replace(wholedata, MainIdMatch.Value, replacevalue, , 1)
            MainIdMatch = Regex.Match(wholedata, "<MAIN1>")
            MainCount += 1
        End While

        Dim SubIdMatch As Match = Regex.Match(wholedata, "<SUB1>")
        While SubIdMatch.Success
            Dim replacevalue As String = SubIdMatch.ToString
            replacevalue = Regex.Replace(replacevalue, "<SUB1>", "<SUB1 id=""s1" & SubCount & """>")
            wholedata = Replace(wholedata, SubIdMatch.Value, replacevalue, , 1)
            SubIdMatch = Regex.Match(wholedata, "<SUB1>")
            SubCount += 1
        End While

        Dim SubSubIdMatch As Match = Regex.Match(wholedata, "<SUBSUB1>")
        While SubSubIdMatch.Success
            Dim replacevalue As String = SubSubIdMatch.ToString
            replacevalue = Regex.Replace(replacevalue, "<SUBSUB1>", "<SUBSUB1 id=""ss1" & SubSubCount & """>")
            wholedata = Replace(wholedata, SubSubIdMatch.Value, replacevalue, , 1)
            SubSubIdMatch = Regex.Match(wholedata, "<SUBSUB1>")
            SubSubCount += 1
        End While

        Dim SubSubsubIdMatch As Match = Regex.Match(wholedata, "<SUBSUBSUB1>")
        While SubSubsubIdMatch.Success
            Dim replacevalue As String = SubSubsubIdMatch.ToString
            replacevalue = Regex.Replace(replacevalue, "<SUBSUBSUB1>", "<SUBSUBSUB1 id=""sss1" & SubSubSubCount & """>")
            wholedata = Replace(wholedata, SubSubsubIdMatch.Value, replacevalue, , 1)
            SubSubsubIdMatch = Regex.Match(wholedata, "<SUBSUBSUB1>")
            SubSubSubCount += 1
        End While

        Dim SubSubSubMainSub As Match = Regex.Match(wholedata, "<SUBSUBSUB1([^<]*?)><\?MAIN1(\s)?([^<]*?)\?><\?SUB1(\s)?([^<]*?)\?><\?SUBSUB1(\s)?([^<]*?)\?><\?SUBSUBSUB1(\s)?([^<]*?)\?></SUBSUBSUB1>")
        While SubSubSubMainSub.Success
            Dim Replacevalue As String = SubSubSubMainSub.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUBSUBSUB1([^<]*?)><\?MAIN1(\s)?([^<]*?)\?><\?SUB1(\s)?([^<]*?)\?><\?SUBSUB1(\s)?([^<]*?)\?><\?SUBSUBSUB1(\s)?([^<]*?)\?></SUBSUBSUB1>", "<ce:index-flag id=""""><ce:index-flag-term>$3</ce:index-flag-term><ce:index-flag id=""""><ce:index-flag-term>$5</ce:index-flag-term><ce:index-flag id=""""><ce:index-flag-term>$7</ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$9</ce:index-flag-term></ce:index-flag></ce:index-flag></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, SubSubSubMainSub.Value, Replacevalue, , 1)
            SubSubSubMainSub = Regex.Match(wholedata, "<SUBSUBSUB1([^<]*?)><\?MAIN1(\s)?([^<]*?)\?><\?SUB1(\s)?([^<]*?)\?><\?SUBSUB1(\s)?([^<]*?)\?><\?SUBSUBSUB1(\s)?([^<]*?)\?></SUBSUBSUB1>")
        End While

        Dim SubSubSubProcess_match As Match = Regex.Match(wholedata, "<SUBSUBSUB1([^<]*?)><\?MAIN1([^<]*?)\?><\?SUB1([^<]*?)\?><\?SUBSUB1([^<]*?)\?>([^<]*?)</SUBSUBSUB1>")
        While SubSubSubProcess_match.Success
            Dim Replacevalue As String = SubSubSubProcess_match.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUBSUBSUB1([^<]*?)><\?MAIN1(\s)?(.*?)\?><\?SUB1(\s)?(.*?)\?><\?SUBSUB1(\s)?(.*?)\?>(.*?)</SUBSUBSUB1>", "$8<ce:index-flag id=""""><ce:index-flag-term>$3</ce:index-flag-term><ce:index-flag id=""""><ce:index-flag-term>$5</ce:index-flag-term><ce:index-flag id=""""><ce:index-flag-term>$7</ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$8</ce:index-flag-term></ce:index-flag></ce:index-flag></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, SubSubSubProcess_match.Value, Replacevalue, , 1)
            SubSubSubProcess_match = Regex.Match(wholedata, "<SUBSUBSUB1([^<]*?)><\?MAIN1([^<]*?)\?><\?SUB1([^<]*?)\?><\?SUBSUB1([^<]*?)\?>([^<]*?)</SUBSUBSUB1>")
        End While

        Dim SubSubSubProcess_match1 As Match = Regex.Match(wholedata, "<SUBSUBSUB1([^<]*?)>([^<]*?)<\?MAIN1([^<]*?)\?><\?SUB1([^<]*?)\?><\?SUBSUB1([^<]*?)\?></SUBSUBSUB1>")
        While SubSubSubProcess_match1.Success
            Dim Replacevalue As String = SubSubSubProcess_match1.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUBSUBSUB1([^<]*?)>(.*?)<\?MAIN1(\s)?(.*?)\?><\?SUB1(\s)?(.*?)\?><\?SUBSUB1(\s)?(.*?)\?></SUBSUBSUB1>", "$2<ce:index-flag id=""""><ce:index-flag-term>$4</ce:index-flag-term><ce:index-flag id=""""><ce:index-flag-term>$6</ce:index-flag-term><ce:index-flag id=""""><ce:index-flag-term>$8</ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$2</ce:index-flag-term></ce:index-flag></ce:index-flag></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, SubSubSubProcess_match1.Value, Replacevalue, , 1)
            SubSubSubProcess_match1 = Regex.Match(wholedata, """<SUBSUBSUB1([^<]*?)>([^<]*?)<\?MAIN1([^<]*?)\?><\?SUB1([^<]*?)\?><\?SUBSUB1([^<]*?)\?></SUBSUBSUB1>")
        End While
        Dim SubSubMainSub As Match = Regex.Match(wholedata, "<SUBSUB1([^<]*?)><\?MAIN1(\s)?([^<]*?)\?><\?SUB1(\s)?([^<]*?)\?><\?SUBSUB1(\s)?([^<]*?)\?></SUBSUB1>")
        While SubSubMainSub.Success
            Dim Replacevalue As String = SubSubMainSub.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUBSUB1([^<]*?)><\?MAIN1(\s)?(.*?)\?><\?SUB1(\s)?(.*?)\?><\?SUBSUB1(\s)?(.*?)\?></SUBSUB1>", "<ce:index-flag id=""""><ce:index-flag-term>$3</ce:index-flag-term><ce:index-flag id=""""><ce:index-flag-term>$5</ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$7</ce:index-flag-term></ce:index-flag></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, SubSubMainSub.Value, Replacevalue, , 1)
            SubSubMainSub = Regex.Match(wholedata, "<SUBSUB1([^<]*?)><\?MAIN1(\s)?([^<]*?)\?><\?SUB1(\s)?([^<]*?)\?><\?SUBSUB1(\s)?([^<]*?)\?></SUBSUB1>")
        End While

        Dim SubSubProcess_match As Match = Regex.Match(wholedata, "<SUBSUB1([^<]*?)><\?MAIN1([^<]*?)\?><\?SUB1([^<]*?)\?>([^<]*?)</SUBSUB1>")
        While SubSubProcess_match.Success
            Dim Replacevalue As String = SubSubProcess_match.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUBSUB1([^<]*?)><\?MAIN1(\s)?(.*?)\?><\?SUB1(\s)?(.*?)\?>(.*?)</SUBSUB1>", "$6<ce:index-flag id=""""><ce:index-flag-term>$3</ce:index-flag-term><ce:index-flag id=""""><ce:index-flag-term>$5</ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$6</ce:index-flag-term></ce:index-flag></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, SubSubProcess_match.Value, Replacevalue, , 1)
            SubSubProcess_match = Regex.Match(wholedata, "<SUBSUB1([^<]*?)><\?MAIN1([^<]*?)\?><\?SUB1([^<]*?)\?>([^<]*?)</SUBSUB1>")
        End While

        Dim SubSubProcess_match1 As Match = Regex.Match(wholedata, "<SUBSUB1([^<]*?)>([^<]*?)<\?MAIN1([^<]*?)\?><\?SUB1([^<]*?)\?></SUBSUB1>")
        While SubSubProcess_match1.Success
            Dim Replacevalue As String = SubSubProcess_match1.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUBSUB1([^<]*?)>(.*?)<\?MAIN1(\s)?(.*?)\?><\?SUB1(\s)?(.*?)\?></SUBSUB1>", "$2<ce:index-flag id=""""><ce:index-flag-term>$4</ce:index-flag-term><ce:index-flag id=""""><ce:index-flag-term>$6</ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$2</ce:index-flag-term></ce:index-flag></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, SubSubProcess_match1.Value, Replacevalue, , 1)
            SubSubProcess_match1 = Regex.Match(wholedata, "<SUBSUB1([^<]*?)>([^<]*?)<\?MAIN1([^<]*?)\?><\?SUB1([^<]*?)\?></SUBSUB1>")
        End While

        Dim MainSubMain As Match = Regex.Match(wholedata, "<SUB1([^<]*?)><\?MAIN1([^<]*?)\?><\?SUB1([^<]*?)\?></SUB1>")
        While MainSubMain.Success
            Dim Replacevalue As String = MainSubMain.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUB1([^<]*?)><\?MAIN1(\s)(.*?)\?><\?SUB1(\s)(.*?)\?></SUB1>", "<ce:index-flag id=""""><ce:index-flag-term>$3</ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$5</ce:index-flag-term></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, MainSubMain.Value, Replacevalue, , 1)
            MainSubMain = Regex.Match(wholedata, "<SUB1([^<]*?)><\?MAIN1([^<]*?)\?><\?SUB1([^<]*?)\?></SUB1>")
        End While

        Dim MainSub_match As Match = Regex.Match(wholedata, "<SUB1([^<]*?)><\?MAIN1([^<]*?)\?>([^<]*?)</SUB1>")
        While MainSub_match.Success
            Dim Replacevalue As String = MainSub_match.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUB1([^<]*?)><\?MAIN1(\s)?(.*?)\?>([^<]*?)</SUB1>", "$4<ce:index-flag id=""""><ce:index-flag-term>$3</ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$4</ce:index-flag-term></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, MainSub_match.Value, Replacevalue, , 1)
            MainSub_match = Regex.Match(wholedata, "<SUB1([^<]*?)><\?MAIN1([^<]*?)\?>([^<]*?)</SUB1>")
        End While

        Dim MainSub_match1 As Match = Regex.Match(wholedata, "<SUB1([^<]*?)>([^<]*?)<\?MAIN1([^<]*?)\?></SUB1>")
        While MainSub_match1.Success
            Dim Replacevalue As String = MainSub_match1.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUB1([^<]*?)>([^<]*?)<\?MAIN1(\s)?(.*?)\?></SUB1>", "$2<ce:index-flag id=""""><ce:index-flag-term>$4</ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$2</ce:index-flag-term></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, MainSub_match1.Value, Replacevalue, , 1)
            MainSub_match1 = Regex.Match(wholedata, "<SUB1([^<]*?)>([^<]*?)<\?MAIN1([^<]*?)\?></SUB1>")
        End While

        Dim MainMain_match As Match = Regex.Match(wholedata, "<MAIN1([^<]*?)><\?MAIN1([^<]*?)\?></MAIN1>")
        While MainMain_match.Success
            Dim Replacevalue As String = MainMain_match.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<MAIN1([^<]*?)><\?MAIN1(\s)?(.*?)\?></MAIN1>", "<ce:index-flag$1><ce:index-flag-term>$3</ce:index-flag-term></ce:index-flag>")
            wholedata = Replace(wholedata, MainMain_match.Value, Replacevalue, , 1)
            MainMain_match = Regex.Match(wholedata, "<MAIN1([^<]*?)><\?MAIN1([^<]*?)\?></MAIN1>")
        End While

        Dim MainMainContent_match As Match = Regex.Match(wholedata, "<MAIN1([^<]*?)><\?MAIN1([^<]*?)\?>(.*?)</MAIN1>")
        While MainMainContent_match.Success
            Dim Replacevalue As String = MainMainContent_match.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<MAIN1([^<]*?)><\?MAIN1(\s)?(.*?)\?>(.*?)</MAIN1>", "<MAIN1$1>$4</MAIN1>")
            wholedata = Replace(wholedata, MainMainContent_match.Value, Replacevalue, , 1)
            MainMainContent_match = Regex.Match(wholedata, "<MAIN1([^<]*?)><\?MAIN1([^<]*?)\?>(.*?)</MAIN1>")
        End While

        Dim MainContentMain_match As Match = Regex.Match(wholedata, "<MAIN1([^<]*?)>([^<]*?)<\?MAIN1([^<]*?)\?></MAIN1>")
        While MainContentMain_match.Success
            Dim Replacevalue As String = MainContentMain_match.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<MAIN1([^<]*?)>(.*?)<\?MAIN1(\s)?(.*?)\?></MAIN1>", "<MAIN1$1>$2</MAIN1>")

            wholedata = Replace(wholedata, MainContentMain_match.Value, Replacevalue, , 1)
            MainContentMain_match = Regex.Match(wholedata, "<MAIN1([^<]*?)>([^<]*?)<\?MAIN1([^<]*?)\?></MAIN1>")
        End While

        Dim Main_match As Match = Regex.Match(wholedata, "<MAIN1([^<]*?)>([^<]*?)</MAIN1>")
        While Main_match.Success
            Dim Replacevalue As String = Main_match.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<MAIN1([^<]*?)>(.*?)</MAIN1>", "$2<ce:index-flag$1><ce:index-flag-term>$2</ce:index-flag-term></ce:index-flag>")
            wholedata = Replace(wholedata, Main_match.Value, Replacevalue, , 1)
            Main_match = Regex.Match(wholedata, "<MAIN1([^<]*?)>([^<]*?)</MAIN1>")
        End While

        Dim SubContent_match As Match = Regex.Match(wholedata, "<SUB1([^<]*?)>([^<]*?)</SUB1>")
        While SubContent_match.Success
            Dim Replacevalue As String = SubContent_match.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<SUB1([^<]*?)>(.*?)</SUB1>", "<ce:index-flag id=""""><ce:index-flag-term><MAIN1-ERROR/></ce:index-flag-term><ce:index-flag$1><ce:index-flag-term>$2</ce:index-flag-term></ce:index-flag></ce:index-flag>")
            wholedata = Replace(wholedata, SubContent_match.Value, Replacevalue, , 1)
            SubContent_match = Regex.Match(wholedata, "<SUB1([^<]*?)>([^<]*?)</SUB1>")
        End While

        Dim MainProcess_match As Match = Regex.Match(wholedata, "<\?MAIN1([^<]*?)\?>")
        While MainProcess_match.Success
            Dim Replacevalue As String = MainProcess_match.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<\?MAIN1(\s)?(.*?)\?>", "<ce:index-flag id=""""><ce:index-flag-term><MAIN1-ERROR>$2</MAIN1-ERROR></ce:index-flag-term></ce:index-flag>")
            wholedata = Replace(wholedata, MainProcess_match.Value, Replacevalue, , 1)
            MainProcess_match = Regex.Match(wholedata, "<\?MAIN1([^<]*?)\?>")
        End While

        Dim Dummyid As Integer = 1
        Dim Dummyquote As Match = Regex.Match(wholedata, "<ce:index-flag id="""">")
        While Dummyquote.Success
            Dim Replacevalue As String = Dummyquote.ToString
            Replacevalue = Regex.Replace(Replacevalue, "<ce:index-flag id="""">", "<ce:index-flag id=""if" & ids(Dummyid) & """>")
            wholedata = Replace(wholedata, Dummyquote.Value, Replacevalue, , 1)
            Dummyquote = Regex.Match(wholedata, "<ce:index-flag id="""">")
            Dummyid += 1
        End While

        wholedata = Regex.Replace(wholedata, "</ce:index-flag>(\s)<ce:index-flag", "</ce:index-flag><ce:index-flag")
        wholedata = Regex.Replace(wholedata, "\(ce:italic\)", "<ce:italic>")
        wholedata = Regex.Replace(wholedata, "\(/ce:italic\)", "</ce:italic>")
        wholedata = Regex.Replace(wholedata, "\(ce:bold\)", "<ce:bold>")
        wholedata = Regex.Replace(wholedata, "\(/ce:bold\)", "</ce:bold>")
        wholedata = Regex.Replace(wholedata, "\(ce:italic\-bold\)", "<ce:italic-bold>")
        wholedata = Regex.Replace(wholedata, "\(/ce:italic\-bold\)", "</ce:italic-bold>")
        wholedata = Regex.Replace(wholedata, "\(ce:bold\-italic\)", "<ce:bold-italic>")
        wholedata = Regex.Replace(wholedata, "\(/ce:bold\-italic\)", "</ce:bold-italic>")
        wholedata = Regex.Replace(wholedata, "\(ce:inf\)", "<ce:inf>")
        wholedata = Regex.Replace(wholedata, "\(/ce:inf\)", "</ce:inf>")
        wholedata = Regex.Replace(wholedata, "\(ce:sup\)", "<ce:sup>")
        wholedata = Regex.Replace(wholedata, "\(/ce:sup\)", "</ce:sup>")
        wholedata = Regex.Replace(wholedata, "\(ce:underline\)", "<ce:underline>")
        wholedata = Regex.Replace(wholedata, "\(/ce:underline\)", "</ce:underline>")
        wholedata = Regex.Replace(wholedata, "\(ce:small-caps\)", "<ce:small-caps>")
        wholedata = Regex.Replace(wholedata, "\(/ce:small-caps\)", "</ce:small-caps>")

        'Added for Bug:2552&3315; By P.Parthiban on 20th June 2012 & 7th Jan 2013;
        wholedata = Regex.Replace(wholedata, "</ce:bold>(\s)?<ce:bold>", "$1")
        wholedata = Regex.Replace(wholedata, "</ce:italic>(\s)?<ce:italic>", "$1")
        wholedata = Regex.Replace(wholedata, "  ", " ")

        wholedata = Regex.Replace(wholedata, "\{i\}", "<ce:italic>")
        wholedata = Regex.Replace(wholedata, "\{/i\}", "</ce:italic>")
        'Sasikala.K added for STAMS-9449 21-05-2021;
        wholedata = Regex.Replace(wholedata, "S_P_I_itag", "{i}")
        ''---
        wholedata = Regex.Replace(wholedata, "\{b\}", "<ce:bold>")
        wholedata = Regex.Replace(wholedata, "\{/b\}", "</ce:bold>")
        wholedata = Regex.Replace(wholedata, "\{sup\}", "<ce:sup>")
        wholedata = Regex.Replace(wholedata, "\{/sup\}", "</ce:sup>")
        wholedata = Regex.Replace(wholedata, "\{sub\}", "<ce:sub>")
        wholedata = Regex.Replace(wholedata, "\{/sub\}", "</ce:sub>")
    End Sub
#End Region

#Region "Shared Function ids(ByVal i As Integer) As String"
    ''' <summary>
    ''' InDesign Post Process
    ''' </summary>
    ''' <remarks></remarks>
    ''' <History>
    ''' '2009.09.17; R.Thinagaran; Bug:1076; Elsevier XML coding to be replaced from the Marked Index entries
    ''' </History>
    Shared Function ids(ByVal i As Integer) As String

        Dim tmp As String
        tmp = CStr(i)
        If Len(tmp) = 1 Then
            tmp = "000" & tmp
        ElseIf Len(tmp) = 2 Then
            tmp = "00" & tmp
        ElseIf Len(tmp) = 3 Then
            tmp = "0" & tmp
        End If
        Return tmp
    End Function
#End Region

    'P.Parthiban commented for Bug:7214;on 29th MAR 2016;
    '#Region "DeleteDuplicateIndex(WholeData)"
    '    Shared Sub DeleteDuplicateIndex(ByRef WholeData As String)
    '        'WholeData = Regex.Replace(WholeData, "<(/)?SecSPiIndexFlag>", "")
    '        'WholeData = Regex.Replace(WholeData, "(-->){2,}|(<!--){2,}", "$1$2")
    '        Dim coll As MatchCollection = Regex.Matches(WholeData, "<SecSPiIndexFlag>(.*?)</SecSPiIndexFlag>", RegexOptions.Multiline Or RegexOptions.Singleline)
    '        For Each mtch As Match In coll
    '            If Not Regex.IsMatch(mtch.Groups(1).Value, "<SecSPiIndexFlag>") Then
    '                Dim temp As String = Regex.Replace(mtch.Groups(0).Value, "(<!--)|(-->)", "")
    '                temp = Regex.Replace(temp, "<SecSPiIndexFlag>", "<!--")
    '                temp = Regex.Replace(temp, "</SecSPiIndexFlag>", "-->")
    '                WholeData = Replace(WholeData, mtch.Groups(0).Value, temp)
    '            End If
    '        Next
    '        'P.Parthiban added for bug:3263; on 26th Nov 2013;commented for comment#6 on 28th Dec 2013;
    '        'CurrData = Regex.Replace(CurrData, "<!--(<ce:para(.[^<>]*?)?view=""extended""(.[^<>]*?)?>(.[^<>]*?)</ce:para>)-->", "$1" & vbCrLf)
    '        'Dim i1 = 0
    '        'For Each Val As String In CommonClass.Replacecommentvalue
    '        '    WholeData = Replace(WholeData, "EXTENDEDATT" & i1, Val)
    '        '    i1 += 1
    '        'Next
    '        'CommonClass.Replacecommentvalue.Clear()
    '    End Sub
    '#End Region

#Region "CommentIndex(ByRef wholedata As String)"

    'below code (function) is added for bug:1570; r.thinagaran;
    Shared Sub CommentIndex(ByRef wholedata As String)

        'Comment the index-flag in section
        '---
        'R.Sugavaneshwaran commented on 9th october 2017:STAMS-302
        'Dim SectionMatchCollection As MatchCollection = Regex.Matches(wholedata, "<ce:section id=""([^<]*?)""><ce:section-title(.*?)</ce:section-title>")
        'Dim k As Integer = 0
        'For Each Section As Match In SectionMatchCollection
        '    Dim Temp As String = Section.Value
        '    Dim IndexElementMatchCollection As MatchCollection = Regex.Matches(Temp, "<ce:index-flag id=([^<]*?)>(.*?)(</ce:index-flag>)+")
        '    For Each Index As Match In IndexElementMatchCollection
        '        Dim Temp1 As String = Index.Value
        '        Temp1 = "<!--" & Temp1 & "-->"
        '        Dim IndexCountCollection As MatchCollection = Regex.Matches(Index.Value, "<ce:index-flag id=""([^<]*?)"">")

        '        For i As Integer = 1 To IndexCountCollection.Count
        '            If i = IndexCountCollection.Count Then
        '                Temp1 = Regex.Replace(Temp1, "<ce:index-flag id=""" & Regex.Escape(IndexCountCollection.Item(i - 1).Groups(1).Value) & """>", "<ce:index-flag id=""" & SectionMatchCollection.Item(k).Groups(1).Value & """>")
        '                Temp = Regex.Replace(Temp, Regex.Escape(Index.Value), Temp1)
        '            End If
        '        Next
        '    Next
        '    wholedata = Regex.Replace(wholedata, Regex.Escape(SectionMatchCollection.Item(k).Groups(0).Value), Temp)
        '    k = k + 1
        'Next
        '---
        Dim Chapter As MatchCollection = Regex.Matches(wholedata, "<(chapter|fb-non-chapter)([^<]*?)id=""([^<]*?)""([^<]*?)>")
        Dim IndexChapterTitle As Match = Regex.Match(wholedata, "<ce:title(.*?)</ce:title>")
        If IndexChapterTitle.Success Then
            Dim temp As String = IndexChapterTitle.Value
            Dim IndexElementMatchCollection As MatchCollection = Regex.Matches(temp, "<ce:index-flag id=([^<]*?)>(.*?)(</ce:index-flag>)+")
            For Each Index As Match In IndexElementMatchCollection
                Dim Temp1 As String = Index.Value
                Temp1 = "<!--" & Temp1 & "-->"
                Dim IndexCountCollection As MatchCollection = Regex.Matches(Index.Value, "<ce:index-flag id=""([^<]*?)"">")
                For i As Integer = 1 To IndexCountCollection.Count
                    If i = IndexCountCollection.Count Then
                        Temp1 = Regex.Replace(Temp1, "<ce:index-flag id=""" & Regex.Escape(IndexCountCollection.Item(i - 1).Groups(1).Value) & """>", "<ce:index-flag id=""" & Chapter.Item(0).Groups(3).Value & """>")
                        temp = Regex.Replace(temp, Index.Value, Temp1)
                    End If
                Next
                wholedata = Regex.Replace(wholedata, Regex.Escape(IndexChapterTitle.Value), temp)
            Next
        End If

    End Sub
#End Region

#Region "Shared Sub PostProcessReplaceMathEquations(ByRef wholedata As String)"
    ''' <summary>
    ''' InDesign Post Process
    ''' </summary>
    ''' <remarks></remarks>
    ''' <History>
    ''' '2009.11.18; K.Hemachandiran; Bug:919; Math Handling; 
    ''' Modified: K.Hemachandiran; Bug:2166; 28.10.11;
    ''' </History>
    Shared Sub PostProcessReplaceMathEquations(ByRef wholedata As String)
        Try
            Dim IsMathmlPresent As Boolean = False
            Dim Hash As New Hashtable

            If Directory.Exists("D:\Program Files\MathType\Translators") And Not File.Exists("D:\Program Files\MathType\Translators\MathML2 (mml).tdl") Then
                File.Copy("\\172.24.136.200\tsg_fs03\Tech_Database\INDESIGN\AutoUpdates\WileyBlackWell\XMLParser3G2.0\MathML3Translater\MathML2 (mml).tdl", "D:\Program Files\MathType\Translators\MathML2 (mml).tdl")
            End If

            If Directory.Exists("D:\Program Files\MathType\Translators") And Not File.Exists("D:\Program Files\MathType\Translators\SPi_MathML2_base.tdl") Then
                File.Copy("\\172.24.136.200\tsg_fs03\Tech_Database\INDESIGN\AutoUpdates\WileyBlackWell\XMLParser3G2.0\MathML3Translater\SPi_MathML2_base.tdl", "D:\Program Files\MathType\Translators\SPi_MathML2_base.tdl")
            End If

            'IDocument = IApplication.ActiveDocument
            IDocument = IApplication.Documents.FirstItem
            For i As Integer = 1 To IDocument.Links.Count
                Dim ILink As InDesignServer.Link = IDocument.Links.Item(i)
                If Regex.IsMatch(ILink.Name, "^si\d+") Then
                    Dim idMathSDK As New ConvertEquations.Program()
                    Dim idConvertEuqation As New ConvertEquations.ConvertEquation()
                    Dim id3GMathML As String = Path.GetTempPath() & "\" & Path.GetRandomFileName & ".txt"
                    System.Threading.Thread.Sleep(100)
                    idMathSDK.OUPMathML2(idMathSDK, idConvertEuqation, ILink.FilePath, id3GMathML)
                    System.Threading.Thread.Sleep(2500)

                    'If ILink.Name = "si4.eps" Then
                    '    MsgBox("")
                    'End If
                    If File.Exists(id3GMathML) Then
                        Dim MathContent As String = File.ReadAllText(id3GMathML)
                        'MathContent = Regex.Replace(MathContent, "<mml:mtext>&#x2009;</mml:mtext>", "")
                        'MathContent = Regex.Replace(MathContent, "<mml:mtext>(&#x0020;|&#x2009;|&#x2006;|&#x205F;|&#x2004;|&#x0009;|&#x200A;|&#x200B;)</mml:mtext>", "<mml:mspace width=""0.25em""/>")
                        MathContent = Regex.Replace(MathContent, ":", "_")
                        Dim xdoc As XDocument
                        Try
                            xdoc = XDocument.Parse("<root>" & MathContent & "</root>", LoadOptions.PreserveWhitespace)
                        Catch ex As Exception
                            Throw ex
                        End Try
                        MathContent = xdoc.ToString(SaveOptions.DisableFormatting)
                        MathContent = Regex.Replace(MathContent, "_", ":")
                        MathContent = Regex.Replace(MathContent, "<mml:mtext>(\s+)</mml:mtext>", "<mml:mspace width=""0.25em""/>")
                        MathContent = Regex.Replace(MathContent, "<(/)?root>", "")

                        'K.Shanmuga Sundaram Updated for BugNo:STAMS-3964 on 26th May 2019;
                        '-----
                        ''21-Ot-2016; E.Raja added ; bug id 8522;
                        ''MathContent = Regex.Replace(MathContent, "(.[^<>]*?)fontfamily=('|"")(.[^<>]*?)('|"")(.[^<>]*?)", "$1$5")
                        'MathContent = Regex.Replace(MathContent, " fontfamily=('|"")(.[^<>]*?)('|"")", "")
                        MathContent = Regex.Replace(MathContent, "( [^<>]*?)?( fontfamily=('|"")(.*?)('|""))( [^<>]*?)?", "$1$6", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                        '-----

                        'K.Shanmuga Sundaram Updated for BugNo:STAMS-3964 on 26th May 2019;
                        '-----
                        ''MathContent = Regex.Replace(MathContent, "(.[^<>]*?)mathsize='140%'(.[^<>]*?)", "$1$2")
                        'MathContent = Regex.Replace(MathContent, "(.[^<>]*?)mathsize=('|"")140%('|"")(.[^<>]*?)", "$1$4")
                        MathContent = Regex.Replace(MathContent, "( [^<>]*?)?( mathsize=('|"")140%('|""))( [^<>]*?)?", "$1$5", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                        '-----

                        MathContent = Regex.Replace(MathContent, " mathsize=""normal""", "")
                        MathContent = Regex.Replace(MathContent, "<mml:mi(\s*)>", "<mml:mi>")
                        MathContent = Regex.Replace(MathContent, "<mml:mspace width=""0.25em""(\s)*/>", "<mml:mspace width=""0.25em""/>")
                        MathContent = Regex.Replace(MathContent, "<mml:mi>(\s+)</mml:mi>", "<mml:mspace width=""0.25em""/>")
                        'MathContent = Regex.Replace(MathContent, "<(/)?mml:math(\s)*>", "")
                        MathContent = Regex.Replace(MathContent, "<mml:mover accent=(""|')true(""|')>([^<>]*?)<mml:mo>", "<mml:mover accent=""true""><mml:mi mathvariant=""normal"">$3</mml:mi><mml:mo>")
                        'added for bug:7049; k.hemachandiran; 21.03.2016;
                        MathContent = Regex.Replace(MathContent, "<mml:mtext><mml:mover(.[^<>]*?)>", "<mml:mover$1>")
                        MathContent = Regex.Replace(MathContent, "</mml:mover></mml:mtext>", "</mml:mover>")

                        '21-OCT-2016; E.Raja added ; bug id 8522; Bhupathi req.
                        '</mml:mover><mml:mtext >o</mml:mtext></mml:mtext>
                        MathContent = Regex.Replace(MathContent, "</mml:mover><mml:mtext>(.[^<>]*?)</mml:mtext></mml:mtext>", "</mml:mover><mml:mtext>$1</mml:mtext>")
                        'MathContent = Regex.Replace(MathContent, "</mml:mover>(.[^<>]*?)</mml:mtext>", "</mml:mover>$1")
                        MathContent = Regex.Replace(MathContent, "</mml:mover>(.[^<>]*?)</mml:mtext>", "</mml:mover><mml:mtext>$1</mml:mtext>")
                        '</mml:mover>/<mml:mover accent="true">
                        '<mml:mo stretchy="true">/</mml:mo><
                        MathContent = Replace(MathContent, "</mml:mover>/<mml:mover", "</mml:mover><mml:mo>/</mml:mo><mml:mover")
                        ''Redmine #164218; Jayasangari.R added on 22June2023;
                        MathContent = Replace(MathContent, "<mml:mtext><mml:mo>(.*?)</mml:mo></mml:mtext>", "<mml:mo>$1</mml:mo>")
                        '<mml:mtext>S<mml:mover
                        MathContent = Regex.Replace(MathContent, "<mml:mtext>(.[^<>]*?)<mml:mover", "<mml:mtext>$1</mml:mtext><mml:mover")
                        '''''''
                        'E.Raja added on 02-Feb-2017; bug id 9043; Bhupathi req.
                        MathContent = Regex.Replace(MathContent, "<mml:msup>([A-z0-9\s]+)", "<mml:msup><mml:mi mathvariant=""normal"">$1</mml:mi>", RegexOptions.IgnoreCase)
                        MathContent = Regex.Replace(MathContent, "<mml:mtext><mml:msup>(.*?)</mml:msup>", "<mml:msup>$1</mml:msup><mml:mtext>", RegexOptions.IgnoreCase)
                        '<mml:mtext><mml:msup><mml:mi mathvariant="normal">d</mml:mi><mml:mo>′</mml:mo></mml:msup>une</mml:mtext>

                        ''K.Shanmuga Sundaram added for BugNo:STAMS-5246 on 03rd June 2019;
                        ''&#x0009;
                        ''-----
                        'MathContent = Regex.Replace(MathContent, "<mml:mi mathvariant=""normal"">&#x0009;</mml:mi>", "<mml:mspace width=""0.25em""/>", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                        ''-----

                        If File.Exists(id3GMathML) Then
                            File.Delete(id3GMathML)
                        End If
                        If Not Hash.ContainsKey(Path.GetFileNameWithoutExtension(ILink.Name)) Then
                            Hash.Add(Path.GetFileNameWithoutExtension(ILink.Name), MathContent)
                            IsMathmlPresent = True
                        End If
                        System.Threading.Thread.Sleep(100)
                        Dim mtExist() As Process
                        Dim mtChk As Process
                        mtExist = Process.GetProcessesByName("MathType")
                        For Each mtChk In mtExist
                            If mtChk.ProcessName = "MathType" Then
                                mtChk.Kill()
                            End If
                        Next
                    Else
                        'M.Murugan added for Bugs:5114 on 27th Jan 2017;
                        '-----
                        System.Threading.Thread.Sleep(100)
                        Dim mtExist() As Process
                        Dim mtChk As Process
                        mtExist = Process.GetProcessesByName("MathType")
                        For Each mtChk In mtExist
                            If mtChk.ProcessName = "MathType" Then
                                mtChk.Kill()
                            End If
                        Next
                        Dim EquationreplaceStr As String = ""
                        Dim EquationFileStr As String = ""
                        EquationFileStr = File.ReadAllText(ILink.FilePath)
                        EquationFileStr = Regex.Replace(EquationFileStr, vbNewLine, "")
                        EquationFileStr = Regex.Replace(EquationFileStr, "%", "")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<m", "<mml:m")
                        EquationFileStr = Regex.Replace(EquationFileStr, "</m", "</mml:m")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mathdisplay='block'", "<mml:math ")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:math display='block' ", "<mml:math ")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mathxmlns", "<mml:math xmlns")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:moveraccent", "<mml:mover accent")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mostretchy", "<mml:mo stretchy")

                        'K.Shanmuga Sundaram Updated for BugNo:STAMS-4826 on 28th Mar 2019;
                        ''K.Shanmuga Sundaram Updated for BugNo:STAMS-4826 on 18th Mar 2019;
                        ''-----
                        ''EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mml:mover accent=('true'|""true"")>([^<>]*?)<mml:mo([^<>]*?)?>", "<mml:mover accent=$1><mml:mi mathvariant=""normal"">$2</mml:mi><mml:mo$3>")
                        'EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mml:mover accent=('true'|""true"")>([^<>]*?)<mml:mo([^<>]*?)?>", "<mml:mover accent=""true""><mml:mi mathvariant=""normal"">$2</mml:mi><mml:mo$3>")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:(mml:)?mover accent=('true'|""true"")>([^<>]*?)<mml:mo([^<>]*?)?>", "<mml:mover accent=""true""><mml:mi mathvariant=""normal"">$3</mml:mi><mml:mo$4>")
                        '-----

                        'P.Parthiban added on 28th MAY 2016;bug:7603;
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mtext>([A-z0-9]*?)<mml:msup>([A-z0-9]*?)<mml:mo>([^<>]*?)</mml:mo></mml:msup>(([A-z0-9]*?)</mml:mtext>)", "<mml:mtext>$1</mml:mtext><mml:msup><mml:mtext>$2</mml:mtext><mml:mo>$3</mml:mo></mml:msup><mml:mtext>$4")
                        'P.Parthiban added on 31st JULY 2015;bug:5734;
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mtext>([A-z0-9]*?)<mml:msup>([A-z0-9]*?)<mml:mo>([^<>]*?)</mml:mo></mml:msup></mml:mtext>", "<mml:mtext>$1</mml:mtext><mml:msup><mml:mtext>$2</mml:mtext><mml:mo>$3</mml:mo></mml:msup>")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mtext>([A-z0-9]*?)<mml:msup><mml:mo>([^<>]*?)</mml:mo></mml:msup></mml:mtext>", "<mml:mtext>$1</mml:mtext><mml:msup><mml:mo>$2</mml:mo></mml:msup>")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mtext><mml:msup>([A-z0-9]*?)<mml:mo>([^<>]*?)</mml:mo></mml:msup></mml:mtext>", "<mml:msup><mml:mtext>$1</mml:mtext><mml:mo>$2</mml:mo></mml:msup>")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mtext></mml:mtext>", "")
                        'P.Parthiban updated for Bug:6746; on 18th JAN 2015;
                        '****************
                        ''modifed by k.hemachandiran; dinesh mail:15/4/2014;12/4/2014;9/12/2015-bugid:6537;
                        ''------------
                        'Dim o As String = Regex.Match(EquationFileStr, "<mtext>([^<>]*?)<mover accent=('true'|""true"")>").Groups(1).Value
                        'If o = "" Then
                        '    EquationFileStr = Regex.Replace(EquationFileStr, "<mtext>([^<>]*?)<mover accent=('true'|""true"")>", "<mover accent=$2>")
                        'Else
                        '    EquationFileStr = Regex.Replace(EquationFileStr, "<mtext>([^<>]*?)<mover accent=('true'|""true"")>", "<mtext>$1</mtext><mover accent=$2>")
                        'End If
                        For Each m As Match In Regex.Matches(EquationFileStr, "<mml:mtext>([^<>]*?)<mml:mover accent=('true'|""true"")>")
                            Dim o As String = m.Groups(1).Value
                            If o = "" Then
                                EquationFileStr = Regex.Replace(EquationFileStr, m.Groups(0).Value, "<mml:mover accent=" & m.Groups(2).Value & ">")
                            Else
                                EquationFileStr = Regex.Replace(EquationFileStr, m.Groups(0).Value, "<mml:mtext>" & m.Groups(1).Value & "</mml:mtext><mml:mover accent=" & m.Groups(2).Value & ">")
                            End If
                        Next
                        'Dim c As String = Regex.Match(EquationFileStr, "</mover>([^<>]*?)</mtext>").Groups(1).Value
                        'If c <> "" Then
                        '    EquationFileStr = Regex.Replace(EquationFileStr, "</mover>([^<>]*?)</mtext>", "</mover><mtext>$1</mtext></mtext>")
                        'Else
                        '    EquationFileStr = Regex.Replace(EquationFileStr, "</mover></mtext>", "</mover>")
                        'End If
                        For Each m As Match In Regex.Matches(EquationFileStr, "</mml:mover>([^<>]*?)</mml:mtext>")
                            Dim c As String = m.Groups(1).Value
                            If c <> "" Then
                                EquationFileStr = Regex.Replace(EquationFileStr, m.Groups(0).Value, "</mml:mover><mml:mtext>" & m.Groups(1).Value & "</mml:mtext></mml:mtext>")
                            Else
                                EquationFileStr = Regex.Replace(EquationFileStr, m.Groups(0).Value, "</mml:mover>")
                            End If
                        Next
                        '****************
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mtext>", "<mml:mi mathvariant=""normal"">")
                        EquationFileStr = Regex.Replace(EquationFileStr, "</mml:mtext>", "</mml:mi>")
                        'EquationFileStr = Regex.Replace(EquationFileStr, "<mtext><mover accent=('true'|""true"")>", "<mover accent=$1>")
                        'Dim c As String = Regex.Match(EquationFileStr, "</mover>([^<>]*?)</mtext>").Groups(1).Value
                        'If c <> "" Then
                        '    EquationFileStr = Regex.Replace(EquationFileStr, "</mover>([^<>]*?)</mtext>", "</mover><mtext>$1</mtext></mtext>")
                        'End If
                        'EquationFileStr = Regex.Replace(EquationFileStr, "</mover></mtext>", "</mover>")
                        'EquationFileStr = Regex.Replace(EquationFileStr, "<mtext>", "<mi mathvariant=""normal"">")
                        'EquationFileStr = Regex.Replace(EquationFileStr, "</mtext>", "</mi>")
                        '------------

                        'EquationFileStr = Regex.Replace(EquationFileStr, "<(/)?mtext>", "")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mstyledisplaystyle", "<mml:mstyle displaystyle")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<annotationencoding", "<annotation encoding")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mtablecolumnalign", "<mml:mtable columnalign")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mfracbevelled", "<mml:mfrac bevelled")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mstylemathsize", "<mml:mstyle mathsize")
                        EquationFileStr = Regex.Replace(EquationFileStr, "displaystyle", " displaystyle")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mtrcolumnalign", "<mml:mtr columnalign")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mtdcolumnalign", "<mml:mtd columnalign")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mtableframe", "<mml:mtable frame")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mstylescriptlevel", "<mml:mstyle scriptlevel")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mstylemathvariant", "<mml:mstyle mathvariant")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mtablegroupalign", "<mml:mtable groupalign")
                        EquationFileStr = Regex.Replace(EquationFileStr, "'mathsize", "' mathsize")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mimathvariant", "<mml:mi mathvariant")
                        '13-07-13 mail from Dinesh
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:munderaccentunder", "<mml:munder accentunder")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:menclosenotation", "<mml:menclose notation")
                        '28.1.2015; Mail from Dinesh; k.hemachandiran;
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mi mathvariant=""normal""><mml:munder accentunder='true'>([^<>]*?)<mml:mo>([^<>]*?)</mml:mo></mml:munder></mml:mi>", "<mml:munder accentunder='true'><mml:mi mathvariant=""normal"">$1</mml:mi><mml:mo>$2</mml:mo></mml:munder>")
                        'Bugid 5448;
                        EquationFileStr = Regex.Replace(EquationFileStr, "</mml:mi></mml:mi>", "</mml:mi>")
                        'P.Parthiban added for Bug:6336;on 12th NOV 2015;
                        'updated by k.hemachandiran for bug:6355; since mover required mi and mo tags; 14.11.2015;
                        'EquationFileStr = Regex.Replace(EquationFileStr, "<mo>(&#x([A-Za-z0-9]{4});)</mo>", "")
                        If Regex.IsMatch(EquationFileStr, "<mml:mrow><mml:mtable frame='solid'><mml:mrow>") Then
                            EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mrow><mml:mtable frame='solid'><mrow>", "<mml:menclose notation=""box""><mml:mrow>")
                            EquationFileStr = Regex.Replace(EquationFileStr, "</mml:mrow></mml:mtable></mml:mrow>", "</mml:mrow></mml:menclose>")
                        End If
                        'P.Parthiban added for Bug:7989;on 29th JULY 2016;
                        If Regex.IsMatch(EquationFileStr, "<mml:mrow><mml:mtable frame='solid'><mml:mi mathvariant=""normal"">") Then
                            EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mrow><mml:mtable frame='solid'><mml:mi mathvariant=""normal"">", "<mml:mrow><mml:menclose notation=""box""><mml:mi mathvariant=""normal"">")
                            EquationFileStr = Regex.Replace(EquationFileStr, "</mml:mi></mml:mtable></mml:mrow>", "</mml:mi></mml:menclose></mml:mrow>")
                        End If
                        'P.Parthiban added on 4th FEB 2016;bug:6859;
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mi mathvariant=""normal"">&#x2009;</mml:mi>", "<mml:mspace width=""0.25em""/>")
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mi mathvariant=""normal"">&#x205F;</mml:mi>", "<mml:mspace width=""thickmathspace""/>")
                        'Sugavaneshwarn; bug id 9968;
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mi mathvariant=""normal"">&#x00A0;</mml:mi>", "<mml:mspace width=""0.25em""/>", RegexOptions.IgnoreCase Or RegexOptions.Singleline)
                        '

                        'K.Shanmuga Sundaram added for BugNo:STAMS-5575 on 02nd July 2019;
                        '-----
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mi mathvariant=""normal"">&#x2003;</mml:mi>", "<mml:mspace width=""1em""/>", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                        '-----

                        'P.Parthiban added on 11th OCT 2016;bug:8496;
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mi mathvariant=""normal""></mml:mi>", "")
                        'M.Murugan added for Bug:5114 on Jan 28th 2017;
                        EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mstyle([^<>]*?) mathsize='normal'>", "<mml:mstyle$1>")
                        EquationreplaceStr = Regex.Match(EquationFileStr, "<mml:math (.*?)</mml:math>").Value

                        ''K.Shanmuga Sundaram added for BugNo:STAMS-5246 on 03rd June 2019;
                        ''&#x0009;
                        ''-----
                        'EquationFileStr = Regex.Replace(EquationFileStr, "<mml:mi mathvariant=""normal"">&#x0009;</mml:mi>", "<mml:mspace width=""0.25em""/>", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                        ''-----

                        Dim Findstrreg As String = ""
                        Dim EqsrFormat As String = ""
                        If EqsrFormat.Length = 0 Then
                            Findstrreg = "<spi-math-img id=" & """" & Path.GetFileNameWithoutExtension(ILink.Name) & """" & "([^<]*?)></spi-math-img>"
                        End If
                        If EquationreplaceStr <> "" Then
                            If Not Hash.ContainsKey(Path.GetFileNameWithoutExtension(ILink.Name)) Then
                                Hash.Add(Path.GetFileNameWithoutExtension(ILink.Name), EquationreplaceStr)
                                IsMathmlPresent = True
                            End If
                        End If
                        '-----
                    End If
                End If
            Next

            If IsMathmlPresent Then
                'P.Parthiban changed for Bug:2619; on 6th July 2012;
                'Sasikala.K updated for STAMS-10031 on 27-09-2021;
                ''Dim DataMatch As MatchCollection = Regex.Matches(wholedata, "<spi-math-img id=(""(.[^<>]*?)\.(.[^<>]*?)"")>")
                Dim DataMatch As MatchCollection = Regex.Matches(wholedata, "<spi-math-img id=(""(.[^<>]*?)\.(.[^<>]*?)""(/)?)>")
                'Dim DataMatch As MatchCollection = Regex.Matches(wholedata, "<spi-math-img id=""(.[^<>]*?)>")
                If DataMatch.Count > 0 Then
                    For i As Integer = 0 To DataMatch.Count - 1
                        Dim Id As String = DataMatch.Item(i).Groups(2).Value
                        For Each j As String In Hash.Keys
                            If j.ToLower = Id.ToLower Then
                                Dim AddAttribute As String = Hash.Item(j)
                                'M.Murugan added for Bug:5114
                                'Dim Entity As New BPR.CADF.EntityConversion("spiiselite", "\\172.24.136.200\tsg_fs03\Tech_Database\INDESIGN\AutoUpdates\WileyBlackWell\BPR_EntityConversion\Entity.xml")
                                Dim Entity As New BPR.CADF.EntityConversion("spiiselite", "\\172.24.136.200\tsg_fs03\Tech_Database\INDESIGN\AutoUpdates\BPR_EntityConversion\Entity.xml")
                                AddAttribute = Entity.UnicodeToSymbol(AddAttribute)
                                AddAttribute = Replace(AddAttribute, "&VeryThinSpace;", "")
                                AddAttribute = Replace(AddAttribute, "&Dgr;", "&Delta;")
                                AddAttribute = Replace(AddAttribute, "&dgr;", "&delta;")
                                AddAttribute = Replace(AddAttribute, "<mml:math xmlns='http://www.w3.org/1998/Math/MathML'>", "<mml:math>")
                                ''''''''''''''''''''''''
                                'Sasikala.K updated for STAMS-10031 on 27-09-2021;
                                '-----
                                '' AddAttribute = Regex.Replace(AddAttribute, "<mml:math(\s*)>", "<mml:math altimg=" & DataMatch.Item(i).Groups(1).Value & ">")
                                If Regex.IsMatch(DataMatch.Item(i).Groups(1).Value, "(/)$") Then
                                    Dim AddAttribute1 As String = Regex.Replace(DataMatch.Item(i).Groups(1).Value, "(/)$", "")
                                    AddAttribute = Regex.Replace(AddAttribute, "<mml:math(\s*)>", "<mml:math altimg=" & AddAttribute1 & ">")
                                Else
                                    AddAttribute = Regex.Replace(AddAttribute, "<mml:math(\s*)>", "<mml:math altimg=" & DataMatch.Item(i).Groups(1).Value & ">")
                                End If
                                '-----
                                wholedata = Regex.Replace(wholedata, DataMatch.Item(i).Groups(0).Value, AddAttribute)
                                Exit For
                            End If
                        Next
                    Next
                End If
                wholedata = Regex.Replace(wholedata, "</spi-math-img>", "")
                wholedata = Regex.Replace(wholedata, "<!--<mml:math(.*?)</mml:math>-->", "")
                wholedata = Regex.Replace(wholedata, "<spi-math-img id=""(.[^<>]*?)"">", "<spi-math-img id=""$1""/>")
                'b.Sujatha added for bug:9238 on 02-Mar-2017
                '-----
                wholedata = Replace(wholedata, "<mml:mtext></mml:mtext>", "")
                wholedata = Regex.Replace(wholedata, "<mml:mstyle mathsize=(.[^<>]*?) ", "<mml:mstyle ")
                '----
                'E.Raja added on 28-Apr-2017;
                For Each MnMatch As Match In Regex.Matches(wholedata, "<mml:mn>(.[^<>]*?)</mml:mn><mml:mn>(.[^<>]*?)</mml:mn><mml:mn>(.[^<>]*?)</mml:mn>", RegexOptions.IgnoreCase Or RegexOptions.IgnoreCase)
                    Dim MNvalue As String = MnMatch.Value
                    MNvalue = "<mml:mn>" & MnMatch.Groups(1).Value & MnMatch.Groups(2).Value & MnMatch.Groups(3).Value & "</mml:mn>"
                    wholedata = Replace(wholedata, MnMatch.Value, MNvalue, , 1)
                Next
                'bug id 9621;
                ''For Each MnMatch As Match In Regex.Matches(wholedata, "<mml:mn>(.[^<>]*?)</mml:mn><mml:mn>(.[^<>]*?)</mml:mn>", RegexOptions.IgnoreCase Or RegexOptions.IgnoreCase)
                ''    Dim MNvalue As String = MnMatch.Value
                ''    MNvalue = "<mml:mn>" & MnMatch.Groups(1).Value & MnMatch.Groups(2).Value & "</mml:mn>"
                ''    wholedata = Replace(wholedata, MnMatch.Value, MNvalue, , 1)
                ''Next

                'P.Gopiram added for STAMS:3899 on 19th Nov 2018
                '-----------------------------------
                wholedata = Regex.Replace(wholedata, "<mml:mn><mml:mn>(.*?)</mml:mn></mml:mn>", "<mml:mn>$1</mml:mn>", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                wholedata = Regex.Replace(wholedata, "<mml:mtext><mml:mtext>(.*?)</mml:mtext></mml:mtext>", "<mml:mtext>$1</mml:mtext>", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                For Each MMatch In Regex.Matches(wholedata, "<mml:math(.[^<>]*?)>(.*?)</mml:math>", RegexOptions.IgnoreCase Or RegexOptions.IgnoreCase)
                    Dim AftChange As String
                    AftChange = MMatch.Groups(2).Value.ToString
                    AftChange = Regex.Replace(AftChange, "><<", ">&lt;<", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                    AftChange = Regex.Replace(AftChange, ">><", ">&gt;<", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)

                    'K.Shanmuga Sundaram added for BugNo:STAMS-5246 on 03rd June 2019;
                    '&#x0009;
                    '-----
                    AftChange = Regex.Replace(AftChange, "<mml:mi mathvariant=""normal"">	</mml:mi>", "<mml:mspace width=""0.25em""/>", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                    '-----

                    'K.Shanmuga Sundaram added for BugNo:STAMS-5575 on 02nd July 2019;
                    '-----
                    AftChange = Regex.Replace(AftChange, "<mml:mi mathvariant=""normal"">&#x2003;</mml:mi>", "<mml:mspace width=""1em""/>", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
                    '-----

                    wholedata = Replace(wholedata, MMatch.Groups(2).Value.ToString, AftChange, , 1)
                Next
            End If
            '---------------------------------------

        Catch ex As Exception
            Throw ex
        End Try
    End Sub
#End Region

#Region "Shared Sub PostProcessCleanupMathEquations(ByRef wholedata As String)"
    ''' <summary>
    ''' Math cleanup 
    ''' </summary>
    ''' <remarks></remarks>
    ''' <History>
    ''' E.Raja added bug id 5178;
    ''' 
    ''' </History>
    ''' ''E.Raja added math cleanup dll provided by Bhupathi on 18-May-2015
    ' ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
    Shared Sub PostProcessCleanupMathEquations(ByRef wholedata As String)
        Try
            Dim AppName As String = "CS6-Elsevier-Production-Tool"
            If Directory.Exists("D:\Program Files\MathType\Translators\") Then
                SpiceMath.MathType.CopyMathTypeTranslators(New DirectoryInfo("D:\Program Files\MathType\Translators\"), AppName)
                Dim mml As New SpiceMath.MathML(AppName)
                Dim EQstr As String = String.Empty
                For Each Eqmat As Match In Regex.Matches(wholedata, "<mml:math(.[^<>]*?)?>(.*?)</mml:math>", RegexOptions.Singleline Or RegexOptions.IgnoreCase)
                    If Eqmat.Success Then
                        EQstr = Eqmat.Value
                        EQstr = mml.CleanMathML(EQstr, True, True, True)
                        wholedata = Replace(wholedata, Eqmat.Groups(0).ToString, EQstr, , 1)
                    End If
                Next
            End If
        Catch ex As Exception
            'Exception commented - Req. By Raja G
            ''MsgBox(ex.Message.ToString & vbCr & ex.StackTrace.ToString)
        End Try
    End Sub
#End Region

#Region "Shared Sub GetReferenceStyleName()"
    ''' <summary>
    ''' Get Reference Style Name.
    ''' </summary>
    ''' <remarks></remarks>
    Shared Sub GetReferenceStyleName()
        Dim XmlCon As String = File.ReadAllText(ExtractedXMLfile, System.Text.Encoding.UTF8)
        ReferenceStyle = Regex.Match(XmlCon, "<!--(Numbered|Harvard|Vancouver|VancouverNameDate|Emb Vancouver|AMA|APA|Saunders|SaundersNumbered|Mosby|ACSNumbered|NIH)-->", RegexOptions.IgnoreCase).Groups(1).Value
        XmlCon = Regex.Replace(XmlCon, "<!--Numbered-->", "", RegexOptions.IgnoreCase)
        XmlCon = Regex.Replace(XmlCon, "<!--Harvard-->", "", RegexOptions.IgnoreCase)
        XmlCon = Regex.Replace(XmlCon, "<!--Vancouver-->", "", RegexOptions.IgnoreCase)
        XmlCon = Regex.Replace(XmlCon, "<!--VancouverNameDate-->", "", RegexOptions.IgnoreCase)
        XmlCon = Regex.Replace(XmlCon, "<!--Emb Vancouver-->", "", RegexOptions.IgnoreCase)
        XmlCon = Regex.Replace(XmlCon, "<!--AMA-->", "", RegexOptions.IgnoreCase)
        XmlCon = Regex.Replace(XmlCon, "<!--APA-->", "", RegexOptions.IgnoreCase)
        XmlCon = Regex.Replace(XmlCon, "<!--Saunders-->", "", RegexOptions.IgnoreCase)
        XmlCon = Regex.Replace(XmlCon, "<!--SaundersNumbered-->", "", RegexOptions.IgnoreCase)
        XmlCon = Regex.Replace(XmlCon, "<!--Mosby-->", "", RegexOptions.IgnoreCase)
        XmlCon = Regex.Replace(XmlCon, "<!--ACSNumbered-->", "", RegexOptions.IgnoreCase)
        XmlCon = Regex.Replace(XmlCon, "<!--NIH-->", "", RegexOptions.IgnoreCase)
        File.WriteAllText(ExtractedXMLfile, XmlCon, System.Text.Encoding.UTF8)
    End Sub
#End Region

#Region "Shared Sub PostProcessTOC(ByRef CurrData As String)"
    Shared Sub PostProcessTOC(ByRef CurrData As String)
        For Each SectionMatch As Match In Regex.Matches(CurrData, "<section aid:pstyle=""TOC chap title"" id=([^<>]*?)>(.*?)</section>")
            Dim Tempstr As String = SectionMatch.Groups(0).Value
            Tempstr = Regex.Replace(Tempstr, "<section([^<>]*?)><ce:label>([^<>]*?)</ce:label><ce:title>([^<>]*?)</ce:title><ce:pages><ce:first-page>([^<>]*?)</ce:first-page></ce:pages>(.*?)</ce:include-item></section>", "<section$1><ce:label>$2</ce:label><ce:title>$3</ce:title>$5<ce:pages><ce:first-page>$4</ce:first-page></ce:pages></ce:include-item></section>")
            CurrData = Replace(CurrData, SectionMatch.Groups(0).Value, Tempstr)
        Next
    End Sub
#End Region

#Region "Shared Sub PostProcessGeneralBeforeReference(ByRef CurrData As String)"
    ''' <summary>
    ''' Post Process General after processing references.
    ''' </summary>
    ''' <param name="CurrData"></param>
    ''' <remarks></remarks>
    Shared Sub PostProcessGeneralBeforeReference(ByRef CurrData As String)
        CurrData = File.ReadAllText(ExtractedXMLfile, System.Text.Encoding.UTF8)

        'E.Raja added 27-nov-2014. Req.by Bhupathi 
        CurrData = TableAnchorReposition(CurrData)
        ''''''''''''''''''''''''''''
        'k.hemachandiran; mail from bhupathi for QR Code; 7.5.2015;
        CurrData = Regex.Replace(CurrData, "<SPiQRCode (.[^<>]*?)/>", "")
        CurrData = Regex.Replace(CurrData, "<SPiQRCode (.[^<>]*?)></SPiQRCode>", "")

        'k.hemachandiran; mail from bhupathi; 14.4.2015;
        CurrData = Replace(CurrData, "<!--<ce:alt-text", "<ce:alt-text")
        CurrData = Replace(CurrData, "</ce:alt-text>-->", "</ce:alt-text>")
        CurrData = Replace(CurrData, "<!--<ce:alt-title", "<ce:alt-title")
        CurrData = Replace(CurrData, "</ce:alt-title>-->", "</ce:alt-title>")
        CurrData = Replace(CurrData, "<!--<ce:alt-subtitle", "<ce:alt-subtitle")
        CurrData = Replace(CurrData, "</ce:alt-subtitle>-->", "</ce:alt-subtitle>")
        ''STAMS:8174;Balamurugan.K Added on 24-Sep-2020;
        CurrData = Regex.Replace(CurrData, "</ce:label>.<ce:alt-text(.[^<>]*?)?>", "</ce:label><ce:alt-text$1>", RegexOptions.IgnoreCase Or RegexOptions.Singleline Or RegexOptions.Multiline Or RegexOptions.Compiled)
        ''--

        'P.Parthiban Added; on 1st Feb 2014;
        CurrData = Regex.Replace(CurrData, "<spiseparator>([^<>]*?)</spiseparator>", "")
        'P.Parthiban Added for Bug:4140; on 5th Oct 2013;
        CurrData = Regex.Replace(CurrData, "<sb:isbn>ISBN: (\d+)", "<sb:isbn>$1")
        CurrData = Regex.Replace(CurrData, "<(/)?SPIHighlight(.[^<>]*?)?>", "")
        'P.Parthiban added for bug:3755;Handling FIXEDCASE  instructions on 10th June 2013;

        'K.Shanmuga Sundaram Updated for BugNo:STAMS-4790 on 12th Mar 2019;
        '-----
        ''---
        ''R.Sugavaneshwaran added on 10th july 2018:STAMS- 2874
        ''CurrData = Regex.Replace(CurrData, "<(/)?FIXEDCASE(.[^<>]*?)?>", "")
        'CurrData = Regex.Replace(CurrData, "<FIXEDCASE(.[^<>]*?)?>", "<?FIXEDCASE Start?>", RegexOptions.Singleline Or RegexOptions.Multiline)
        'CurrData = Regex.Replace(CurrData, "</FIXEDCASE>", "<?FIXEDCASE End?>", RegexOptions.Singleline Or RegexOptions.Multiline)
        ''---
        CurrData = Regex.Replace(CurrData, "<(/)?FIXEDCASE( [^<>]*?)?>", "", RegexOptions.Singleline Or RegexOptions.Multiline)
        '-----

        'K.Shanmuga Sundaram added for BugNo:STAMS-4152 on 11th May 2019;
        '-----
        Dim DTDVersion = Regex.Match(CurrData, "(<([^<>?]*?)?( version=""(.*?)"")( [^<>]*?)?>)", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline).Groups(4).Value.ToString()
        If Not String.IsNullOrEmpty(DTDVersion) AndAlso Regex.IsMatch(DTDVersion, "^(5\.6)$", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline) Then
            'K.Shanmuga Sundaram added for BugNo:STAMS-5662 on 08th July 2019;
            '-----
            'CurrData = Regex.Replace(CurrData, " <ce:hsp", "<ce:hsp", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
            CurrData = Regex.Replace(CurrData, "( |&#x00A0;)<ce:hsp", "<ce:hsp", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
            '-----
        End If
        '-----

        'P.Parthiban added for bug:3263; on 26th Nov 2013;commented for comment#6 on 28th Dec 2013;
        'CurrData = Regex.Replace(CurrData, "<!--(<ce:para(.[^<>]*?)?view=""extended""(.[^<>]*?)?>(.[^<>]*?)</ce:para>)-->", "$1" & vbCrLf)
        CurrData = Regex.Replace(CurrData, "<spi-hsp sp=""0.25""></spi-hsp>|<spi-hsp sp=""0.25""/>", "&thinsp;")
        'Updated for Bug:3016 cmt 8; on 9th July 2013;
        'CurrData = Regex.Replace(CurrData, "<ce:hsp sp=""0.12"">&hairsp;</ce:hsp>", "&hairsp;&sp0.12;")
        'CurrData = Regex.Replace(CurrData, "(&hairsp;)+<ce:hsp sp=""0.12""></ce:hsp>(&hairsp;)+", "&hairsp;&sp0.12;")
        'CurrData = Regex.Replace(CurrData, "(&hairsp;)+<ce:hsp sp=""0.12""></ce:hsp>", "&hairsp;&sp0.12;")
        'CurrData = Regex.Replace(CurrData, "<ce:hsp sp=""0.12""></ce:hsp>(&hairsp;)+", "&hairsp;&sp0.12;")
        CurrData = Regex.Replace(CurrData, "(\s)+<ce:hsp sp=""0.12""></ce:hsp>", "<ce:hsp sp=""0.12""></ce:hsp>")
        CurrData = Regex.Replace(CurrData, "<ce:hsp sp=""0.12"">(&hairsp;|&thinsp;)</ce:hsp>", "$1&sp0.12;")
        CurrData = Regex.Replace(CurrData, "(&hairsp;)+<ce:hsp sp=""0.12""></ce:hsp>(&hairsp;)+", "&hairsp;&sp0.12;")
        CurrData = Regex.Replace(CurrData, "(&thinsp;)+<ce:hsp sp=""0.12""></ce:hsp>(&thinsp;)+", "&thinsp;&sp0.12;")
        CurrData = Regex.Replace(CurrData, "(&hairsp;)+<ce:hsp sp=""0.12""></ce:hsp>", "&hairsp;&sp0.12;")
        CurrData = Regex.Replace(CurrData, "(&thinsp;)+<ce:hsp sp=""0.12""></ce:hsp>", "&thinsp;&sp0.12;")
        CurrData = Regex.Replace(CurrData, "<ce:hsp sp=""0.12""></ce:hsp>(&hairsp;)+", "&hairsp;&sp0.12;")
        CurrData = Regex.Replace(CurrData, "<ce:hsp sp=""0.12""></ce:hsp>(&thinsp;)+", "&thinsp;&sp0.12;")
        'E.Raja added on 31-Mar-2015 . Req.By Bhupathi.
        CurrData = Regex.Replace(CurrData, "(\s)+<ce:hsp sp=""0.10""></ce:hsp>", "<ce:hsp sp=""0.10""></ce:hsp>")
        CurrData = Regex.Replace(CurrData, "<ce:hsp sp=""0.10"">(&hairsp;|&thinsp;)</ce:hsp>", "$1&sp0.10;")
        CurrData = Regex.Replace(CurrData, "(&hairsp;)+<ce:hsp sp=""0.10""></ce:hsp>(&hairsp;)+", "&hairsp;&sp0.10;")
        CurrData = Regex.Replace(CurrData, "(&thinsp;)+<ce:hsp sp=""0.10""></ce:hsp>(&thinsp;)+", "&thinsp;&sp0.10;")
        CurrData = Regex.Replace(CurrData, "(&hairsp;)+<ce:hsp sp=""0.10""></ce:hsp>", "&hairsp;&sp0.10;")
        CurrData = Regex.Replace(CurrData, "(&thinsp;)+<ce:hsp sp=""0.10""></ce:hsp>", "&thinsp;&sp0.10;")
        CurrData = Regex.Replace(CurrData, "<ce:hsp sp=""0.10""></ce:hsp>(&hairsp;)+", "&hairsp;&sp0.10;")
        CurrData = Regex.Replace(CurrData, "<ce:hsp sp=""0.10""></ce:hsp>(&thinsp;)+", "&thinsp;&sp0.10;")
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        CurrData = Regex.Replace(CurrData, "<ce:hsp sp=""0.1(\d*)""/>|<ce:hsp sp=""0.1(\d*)""></ce:hsp>", "&sp0.1$1$2;")
        CurrData = Regex.Replace(CurrData, "<ce:sup aid:cstyle=""Stacked Sup""", "<ce:sup")
        CurrData = Regex.Replace(CurrData, "<ce:inf aid:cstyle=""Stacked Sub""", "<ce:inf")
        CurrData = Regex.Replace(CurrData, "<sb:date aid:cstyle=""JDate"">", "<sb:date>")
        CurrData = Regex.Replace(CurrData, "</sb:et-al>", "")


        'K.Shanmuga Sundaram Updated for BugNo:STAMS-5549 on 27th June 2019;
        '-----
        'CurrData = Regex.Replace(CurrData, "<sb:et-al(.[^<>]*?)?>", "")
        CurrData = Regex.Replace(CurrData, "<sb:et-al( [^<>]*?)?>", "", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
        '-----

        If Regex.IsMatch(CurrData, "<sb:comment id=""(.[^<>]*?)"">(.[^<>]*?)</sb:comment>") Then
            CurrData = ProcessCommentIDs(CurrData)
        End If

        'K.Shanmuga Sundaram updated for Bugs:8817 on 20th Dec 2016;
        '-----
        'CurrData = Regex.Replace(CurrData, "<!--<query id=""(.[^<>]*?)"">(.*?)</query>-->", "")

        ''STAMS:10584; R.Venkadesh commented on 01-02-2022;
        ''CurrData = Regex.Replace(CurrData, "<!--<query id=""(.[^<>]*?)""( [^<>]*?)?>(.*?)</query>-->", "", RegexOptions.IgnoreCase)
        '-----
        CurrData = Regex.Replace(CurrData, "<!--\[(AU|COMP|ED|TS|Q)\d+\]-->", "", RegexOptions.IgnoreCase)
        CurrData = Regex.Replace(CurrData, "<!--CS6-->", "")
        CurrData = Regex.Replace(CurrData, "<!--ELS-PC-->", "", RegexOptions.IgnoreCase)
        'Sasikala.K added for STAMS-7192 on 08-05-2020;
        '--
        CurrData = Regex.Replace(CurrData, "<!--<PCFIGURE>(<([A-Za-z0-9]+)>)+</PCFIGURE>-->", "", RegexOptions.IgnoreCase)
        '--
        ''STAMS:8564;Balamurugan.K Added on 07-Dec-2020;
        CurrData = Regex.Replace(CurrData, "<!--<PCTABLE>(<([A-Za-z0-9]+)>)+</PCTABLE>-->", "", RegexOptions.IgnoreCase)
        CurrData = Regex.Replace(CurrData, "<!--<PCFORMULA>(<([A-Za-z0-9]+)>)+</PCFORMULA>-->", "", RegexOptions.IgnoreCase)
        '--
        CurrData = Regex.Replace(CurrData, "<spidisplayfigure(.[^<>]*?)?>", "", RegexOptions.IgnoreCase)
        CurrData = Regex.Replace(CurrData, "</spidisplayfigure>", "", RegexOptions.IgnoreCase)
        CurrData = Regex.Replace(CurrData, "<spidisplaytextbox(.[^<>]*?)?>", "", RegexOptions.IgnoreCase)
        CurrData = Regex.Replace(CurrData, "</spidisplaytextbox>", "", RegexOptions.IgnoreCase)
        CurrData = Regex.Replace(CurrData, "<spidisplaytable(.[^<>]*?)?>", "", RegexOptions.IgnoreCase)
        CurrData = Regex.Replace(CurrData, "</spidisplaytable>", "", RegexOptions.IgnoreCase)
        CurrData = Regex.Replace(CurrData, "&forcedlb;", " ")
        CurrData = Regex.Replace(CurrData, "&nonbreaksp;", " ")
        CurrData = Regex.Replace(CurrData, "&shacir;", "&#x274D;")
        'Sasikala.K added for STAMS-9805 on 02-08-2021;
        If Regex.IsMatch(CurrData, "xml:lang=""de""") Then
            CurrData = Regex.Replace(CurrData, "<idxpuncpageno> </idxpuncpageno>", "")
        End If
        ''--
        CurrData = Regex.Replace(CurrData, "<(/)?idxpuncsee>", "")
        CurrData = Regex.Replace(CurrData, "<(/)?idxpuncpageno>", "")
        CurrData = Regex.Replace(CurrData, "<(/)?idxpuncreadersee>", "")
        'CurrData = Regex.Replace(CurrData, "\+", "&plus;")
        CurrData = Regex.Replace(CurrData, "(\s)?anchorid=""([^<>]*?)""(\s)?", "", RegexOptions.IgnoreCase)
        'M.Murugan updated for bug:9870 on June 6th 2017;
        'CurrData = Regex.Replace(CurrData, "(\s)?reverse=""([^<>]*?)""(\s)?", "", RegexOptions.IgnoreCase)
        CurrData = Regex.Replace(CurrData, "(\s)?reverse=""([^<>]*?)""", "", RegexOptions.IgnoreCase)
        '------
        CurrData = Regex.Replace(CurrData, " xmlns:aid=""http://ns.adobe.com/AdobeInDesign/4.0/""", "")
        CurrData = Regex.Replace(CurrData, " xmlns:sb=""http://www.elsevier.com/xml/common/struct-bib/dtd""", "")
        CurrData = Regex.Replace(CurrData, " xmlns:sa=""http://www.elsevier.com/xml/common/struct-aff/dtd""", "")
        CurrData = Regex.Replace(CurrData, " xmlns:mml=""""", "")

        'K.Shanmuga Sundaram added for BugNo:STAMS-4954|STAMS-4152 on 29th Apr 2019;
        '-----
        CurrData = Regex.Replace(CurrData, "PUBLIC ""-\/\/ES\/\/DTD book DTD version (\d\.\d\.\d)\/\/EN\/\/XML"" ""C:\\SPinDesignPreProcess\\FILES\\DTD\\book560.dtd""", "PUBLIC ""-//ES//DTD book DTD version 5.6.0//EN//XML"" ""book560.dtd""", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
        CurrData = Regex.Replace(CurrData, "PUBLIC ""-\/\/ES\/\/DTD book DTD version (\d\.\d\.\d)\/\/EN\/\/XML"" ""D:\\SPinDesignPreProcess\\FILES\\DTD\\book560.dtd""", "PUBLIC ""-//ES//DTD book DTD version 5.6.0//EN//XML"" ""book560.dtd""", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
        CurrData = Regex.Replace(CurrData, "PUBLIC ""-\/\/ES\/\/DTD book DTD version (\d\.\d\.\d)\/\/EN\/\/XML"" ""C:\\SPinDesignPreProcess\\FILES\\DTD\\book550.dtd""", "PUBLIC ""-//ES//DTD book DTD version 5.5.0//EN//XML"" ""book550.dtd""", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
        CurrData = Regex.Replace(CurrData, "PUBLIC ""-\/\/ES\/\/DTD book DTD version (\d\.\d\.\d)\/\/EN\/\/XML"" ""D:\\SPinDesignPreProcess\\FILES\\DTD\\book550.dtd""", "PUBLIC ""-//ES//DTD book DTD version 5.5.0//EN//XML"" ""book550.dtd""", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
        '----

        ''New DTD
        ''---
        ''R.Sugavaneshwaran added on 19th october 2017:STAMS-779
        'CurrData = Replace(CurrData, "<!DOCTYPE chapter PUBLIC ""-//ES//DTD book DTD version 5.2.1//EN//XML"" ""C:\SPinDesignPreProcess\FILES\DTD\book521.dtd""", "<!DOCTYPE chapter PUBLIC ""-//ES//DTD book DTD version 5.5.0//EN//XML"" ""C:\SPinDesignPreProcess\FILES\DTD\book550.dtd""", , 1)
        ''---
        ''K.Shanmuga Sundaram added for BugNo:STAMS-4954 on 29th Apr 2019;
        ''-----
        'CurrData = Regex.Replace(CurrData, "C:\\SPinDesignPreProcess\\FILES\\DTD\\book560.dtd", "book560.dtd", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
        'CurrData = Regex.Replace(CurrData, "D:\\SPinDesignPreProcess\\FILES\\DTD\\book560.dtd", "book560.dtd", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
        ''-----
        'CurrData = Regex.Replace(CurrData, "C:\\SPinDesignPreProcess\\FILES\\DTD\\book550.dtd", "book550.dtd", RegexOptions.IgnoreCase)
        'CurrData = Regex.Replace(CurrData, "D:\\SPinDesignPreProcess\\FILES\\DTD\\book550.dtd", "book550.dtd", RegexOptions.IgnoreCase)
        'CurrData = Regex.Replace(CurrData, "C:\\SPinDesignPreProcess\\FILES\\DTD\\book540.dtd", "book540.dtd", RegexOptions.IgnoreCase)
        'CurrData = Regex.Replace(CurrData, "D:\\SPinDesignPreProcess\\FILES\\DTD\\book540.dtd", "book540.dtd", RegexOptions.IgnoreCase)

        CurrData = Regex.Replace(CurrData, " standalone=""(yes|no)""", "")
        CurrData = Regex.Replace(CurrData, " overflow=""scroll""", "")
        'bug id 8992; E.Raja;
        'CurrData = Regex.Replace(CurrData, " view=""all""", "")
        CurrData = Regex.Replace(CurrData, "(\s*)view=""all""", "")
        ''''''
        CurrData = Regex.Replace(CurrData, "<ce:table xmlns=""http://www.elsevier.com/xml/common/cals/dtd"" xmlns:tb=""http://www.elsevier.com/xml/common/table/dtd""", "<ce:table")
        CurrData = Regex.Replace(CurrData, "<ce:table xmlns:tb=""http://www.elsevier.com/xml/common/table/dtd"" xmlns=""http://www.elsevier.com/xml/common/cals/dtd""", "<ce:table")
        CurrData = Regex.Replace(CurrData, "<entry xmlns=""http://www.elsevier.com/xml/common/dtd""", "<entry")
        CurrData = Regex.Replace(CurrData, " aid:crows=""(.[^<]*?)""", "")
        CurrData = Regex.Replace(CurrData, " aid:ccols=""(.[^<]*?)""", "")
        CurrData = Regex.Replace(CurrData, "( )?aid:table=""(.[^<]*?)""", "")
        CurrData = Regex.Replace(CurrData, " aid:ccolwidth=""(.[^<]*?)""", "")
        CurrData = Regex.Replace(CurrData, " aid:theader=""""", "")
        CurrData = Regex.Replace(CurrData, " aid:tfooter=""""", "")
        CurrData = CurrData.Replace("<table-body>", "")
        CurrData = CurrData.Replace("</table-body>", "")
        CurrData = CurrData.Replace("<table-footnote>", "")
        CurrData = CurrData.Replace("</table-footnote>", "")
        CurrData = CurrData.Replace("<Keywords>", "")
        CurrData = CurrData.Replace("</Keywords>", "")
        CurrData = Regex.Replace(CurrData, "<symbol([^<>]*?)?>", "")
        CurrData = CurrData.Replace("</symbol>", "")
        ''''''''''''''''
        'E.Raja added on 25-Apr-2017; bug id 9546
        CurrData = Regex.Replace(CurrData, "<!--block-->", "<SPIMATHBLOCK/>", RegexOptions.Singleline Or RegexOptions.IgnoreCase)
        ''''''''''''''''''''''''''''
        'M.Murugan updated for Bug:10057 on 14th July 2017;
        CurrData = Replace(CurrData, "<!--[?DND?]-->", "<SPiDND/>")

        'STAMS:10636; R.Venkadesh updated on 24-03-2022;
        CurrData = Regex.Replace(CurrData, Regex.Escape("<!--[IND LINESEP]-->"), "<LineSep/>", RegexOptions.IgnoreCase Or RegexOptions.Singleline)
        CurrData = Regex.Replace(CurrData, Regex.Escape("<!--[IND NBSPACE]-->"), "<NBSpace/>", RegexOptions.IgnoreCase Or RegexOptions.Singleline)
        CurrData = Regex.Replace(CurrData, Regex.Escape("<!--[IND DISCHYP]-->"), "<Dischyp/>", RegexOptions.IgnoreCase Or RegexOptions.Singleline)

        '-----
        CurrData = Regex.Replace(CurrData, "<!--\[.[^<>]*?\]-->", "")
        CurrData = Regex.Replace(CurrData, "<!--\[.[^<>]*?\](.*?)-->", "")
        'M.Murugan updated for Bug:10057 on 14th July 2017;
        CurrData = Replace(CurrData, "<SPiDND/>", "<!--[?DND?]-->")
        '-----
        CurrData = Regex.Replace(CurrData, "<ce:inter-ref(.[^<>]*?)><!--(.[^<>]*?)--></ce:inter-ref>", "<ce:inter-ref$1>$2</ce:inter-ref>")
        CurrData = Regex.Replace(CurrData, "<!--([A-z0-9\s]+)-->", "")
        CurrData = Regex.Replace(CurrData, vbCr, "")
        CurrData = Regex.Replace(CurrData, vbCrLf, "")
        CurrData = Regex.Replace(CurrData, vbTab, "")
        CurrData = Regex.Replace(CurrData, vbLf, "")
        CurrData = Regex.Replace(CurrData, "  ", " ")
        CurrData = Regex.Replace(CurrData, "&para;", "")

        'STAMS:10636; R.Venkadesh updated on 24-03-2022;
        CurrData = Regex.Replace(CurrData, "<LineSep/>", "<!--[IND LINESEP]-->", RegexOptions.IgnoreCase Or RegexOptions.Singleline)
        CurrData = Regex.Replace(CurrData, "<NBSpace/>", "<!--[IND NBSPACE]-->", RegexOptions.IgnoreCase Or RegexOptions.Singleline)
        CurrData = Regex.Replace(CurrData, "<Dischyp/>", "<!--[IND DISCHYP]-->", RegexOptions.IgnoreCase Or RegexOptions.Singleline)

        'R.Sugavaneshwaran added on 22nd november 2018:STAMS-3718
        CurrData = Regex.Replace(CurrData, "<ce:link( [^<]*?)?>(</ce:link>)<ce:legend([^<>]*?)?>(.*?)</ce:legend>(<ce:source([^<>]*?)?>(.*?)</ce:source>)", "$5<ce:link$1>$2<ce:legend$3>$4</ce:legend>")
        '4110
        CurrData = Regex.Replace(CurrData, "(<ce:link(.[^<>]*?)?></ce:link>)(<ce:source([^<>]*?)?>(.*?)</ce:source>)", "$3$1", RegexOptions.Singleline Or RegexOptions.IgnoreCase Or RegexOptions.Multiline)
        '---
        ''Balamurugan.k/Sasikala.K added for STAMS:7721 on 14-07-2020;
        ''---
        Dim textboxColl As MatchCollection = Regex.Matches(CurrData, "(<ce:textbox( [^<>]*?)?>(.*?)</ce:textbox>)", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
        For idtextbox As Integer = 0 To textboxColl.Count - 1
            Dim originalData As String = textboxColl.Item(idtextbox).Groups(1).Value.ToString()
            If Regex.IsMatch(originalData, "<ce:legend( [^<>]*?)?>(.*?)</ce:legend>(<ce:source([^<>]*?)?>(.*?)</ce:source>)", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline) Then
                Dim temporarylegend As String = Regex.Match(originalData, "(<ce:legend( [^<>]*?)?>(.*?)</ce:legend>(<ce:source([^<>]*?)?>(.*?)</ce:source>))", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline).Groups(1).Value.ToString()
                If Not String.IsNullOrEmpty(temporarylegend) Then
                    originalData = Regex.Replace(originalData, "<ce:legend( [^<>]*?)?>(.*?)</ce:legend>(<ce:source([^<>]*?)?>(.*?)</ce:source>)", "$3<ce:legend$1>$2</ce:legend>")
                    CurrData = Replace(CurrData, textboxColl.Item(idtextbox).Groups(1).Value.ToString(), originalData, , 1)
                End If
            End If
        Next
        ''---
        CurrData = Regex.Replace(CurrData, "<Spipara></Spipara>", "&para;", RegexOptions.IgnoreCase)
        CurrData = Regex.Replace(CurrData, "<Spipara>{ParaMarks}</Spipara>", "&para;", RegexOptions.IgnoreCase)
        CurrData = Regex.Replace(CurrData, "<(/)?Spipara>", "", RegexOptions.IgnoreCase)
        CurrData = Regex.Replace(CurrData, "<!--<ce:para(.*?)></ce:para>-->", "<ce:para$1></ce:para>")
        CurrData = Regex.Replace(CurrData, "<!--<info>(.*?)</info>-->", "<info>$1</info>")
        CurrData = Regex.Replace(CurrData, "</info><!--<ce:title>Copyright</ce:title>--><ce:para", "</info><ce:title>Copyright</ce:title><ce:para")
        CurrData = Regex.Replace(CurrData, "<!--<ce:label>(.*?)</ce:label>-->", "<ce:label>$1</ce:label>")
        CurrData = Regex.Replace(CurrData, "<!--<ce:section-title(.*?)>(.*?)</ce:section-title>-->", "<ce:section-title$1>$2</ce:section-title>")
        CurrData = Regex.Replace(CurrData, "<!--<tgroup", "<tgroup")
        CurrData = Regex.Replace(CurrData, "<!--</tgroup>-->", "</tgroup>")
        CurrData = Regex.Replace(CurrData, "<!--</thead>-->", "</thead>")
        CurrData = Regex.Replace(CurrData, "<colspec(.[^<]*?)>-->", "<colspec$1>")
        CurrData = Regex.Replace(CurrData, "<thead>-->", "<thead>")
        CurrData = Regex.Replace(CurrData, "<!--<thead>", "<thead>")
        CurrData = Regex.Replace(CurrData, "<!--<tbody>-->", "<tbody>")
        CurrData = Regex.Replace(CurrData, "<!--</tbody>-->", "</tbody>")
        CurrData = Regex.Replace(CurrData, "</table></table-body><!--</tbody>-->", "</table></table-body></tbody>")
        CurrData = Regex.Replace(CurrData, "<!--<no>(.*?)</no>-->", "<no>$1</no>")
        CurrData = Regex.Replace(CurrData, "<!--<ce:pii>(.*?)</ce:pii>-->", "<ce:pii>$1</ce:pii>")
        CurrData = Regex.Replace(CurrData, "</thead><tbody></entry>", "</entry></thead><tbody>")
        'Redmine Id:135121; S.Chithra added on 10/02/2023;
        CurrData = Regex.Replace(CurrData, "</info><spichapter><ce:label>(.*?)</ce:label></spichapter>", "</info><!--<ce:label>$1</ce:label>-->", RegexOptions.IgnoreCase Or RegexOptions.Compiled Or RegexOptions.Singleline Or RegexOptions.Multiline)
        'Added for bug 2987; By P.Parthiban on 11th Oct 2012;
        Dim itemmatchcoll As MatchCollection = Regex.Matches(CurrData, "<ce:bold>([^<>]*?)ITEM([^<>]*?)</ce:bold>")
        For Each itemmatch As Match In itemmatchcoll
            Dim s As String = itemmatch.Groups(0).Value
            Dim s1 As String = Regex.Replace(s, "&thinsp;|&ensp;|&emsp;|&hairsp;|\uE063|\uFEFF", "")
            CurrData = Regex.Replace(CurrData, s, s1)
        Next

        'E.Raja added on 03-Oct-0216; bug id 8444;Vtool error update;
        Dim Piival As String = Regex.Match(CurrData, "<ce:pii>(.*?)</ce:pii>", RegexOptions.Singleline Or RegexOptions.IgnoreCase).Groups(1).Value
        Piival = Replace(Piival, "-", "")
        Piival = Replace(Piival, ".", "")
        For Each MediaMatch As Match In Regex.Matches(CurrData, "<ce:link (.[^<]*?)>", RegexOptions.Singleline Or RegexOptions.IgnoreCase)
            Dim Linkattributes As String = ""
            Linkattributes = MediaMatch.Groups(1).ToString
            Dim locatorval As String = Regex.Match(Linkattributes, "locator=""(.[^<]*?)""", RegexOptions.Singleline Or RegexOptions.IgnoreCase).Groups(1).Value
            If Regex.IsMatch(Linkattributes, "xlink:href", RegexOptions.IgnoreCase) = False Then
                Linkattributes = Linkattributes & " xlink:type=""simple"" xlink:role=""http://data.elsevier.com/vocabulary/ElsevierContentTypes/23.4"" xlink:href=""pii:" & Piival & "/" & locatorval & """"
                CurrData = Replace(CurrData, MediaMatch.Groups(1).ToString, Linkattributes, , 1)
            End If
        Next
        '''''''''''''''''''''''''''

        CurrData = Regex.Replace(CurrData, "\<\!\-\-(<ce:intra-ref-end(.*?)</ce:intra-ref-end>)\-\-\>", "$1")
        CurrData = Regex.Replace(CurrData, "<ce:intra-refs-link(.[^<>]*?)?></ce:intra-refs-link>", "<ce:intra-refs-link/>")
        CurrData = Regex.Replace(CurrData, "<!--<ce:float-anchor refid=""(.*?)""/>-->", "<ce:float-anchor refid=""$1""/>")
        CurrData = Regex.Replace(CurrData, "</ce:intra-refs-text><!--<ce:intra-ref-end", "</ce:intra-refs-text><ce:intra-ref-end")
        CurrData = Regex.Replace(CurrData, "</ce:intra-ref-end>--><ce:intra-refs-link/>", "</ce:intra-ref-end><ce:intra-refs-link/>")
        CurrData = Regex.Replace(CurrData, "</ce:intra-ref-end>--><ce:intra-refs-link(.[^<]*?)>", "</ce:intra-ref-end><ce:intra-refs-link$1>")
        CurrData = Regex.Replace(CurrData, "<ce:float-anchor refid=""(.[^<>]*?)""></ce:float-anchor>", "<ce:float-anchor refid=""$1""/>")
        CurrData = Regex.Replace(CurrData, "<ce:anchor id=""(.[^<>]*?)""></ce:anchor>", "<ce:anchor id=""$1""/>")
        CurrData = Regex.Replace(CurrData, "<ce:link(.[^<>]*?)></ce:link>", "<ce:link$1/>")
        'E.Raja added on 28-Apr-2017; bug id 9306;
        '<SPiversionurl>http://www.marinespecies.org/polychaeta/</SPiversionurl>
        CurrData = Regex.Replace(CurrData, "<SPiversionurl>(.*?)</SPiversionurl>", "", RegexOptions.IgnoreCase)
        '''''''''''''''''
        ''''..........#119305  R.Jayasangari added on 24/11/2022 ..............

        'CurrData = Regex.Replace(CurrData, "<SpiDel(.[^<>]*?)?>(.[^<>]*?)(<SPiDel>(.[^<>]*?)</SPiDel>)?</SpiDel>", "", RegexOptions.IgnoreCase)
        CurrData = Regex.Replace(CurrData, "<SpiDel(.[^<>]*?)?>(.*?)(<SPiDel>(.[^<>]*?)</SPiDel>)?</SpiDel>", "", RegexOptions.IgnoreCase)
        '..........................

        CurrData = Regex.Replace(CurrData, "<ce:hsp sp=""(.[^<>]*?)"">(\s)?</ce:hsp>", "<ce:hsp sp=""$1""/>")
        CurrData = Regex.Replace(CurrData, "&thinsp;&sp0.12;", "<ce:hsp sp=""0.12""/>")
        'E.Raja added on 31-Mar-2015 . req.by Bhupathi
        CurrData = Regex.Replace(CurrData, "&thinsp;&sp0.10;", "<ce:hsp sp=""0.10""/>")
        'Modified by K.Hemachandiran; STAMS 260;11/8/2017;
        CurrData = Regex.Replace(CurrData, "&nbsp;&sp0.12;", "<ce:hsp sp=""0.12""/>")
        ''''''''''''''''''''''''''''''''''''
        'Sasikala.K added for STAMS-6442 on 05-11-19;
        '---
        If Regex.IsMatch(CurrData, "xml:lang=""en""") Then
            CurrData = Regex.Replace(CurrData, "<ce:hsp sp=""0.10""/>&#x2009;", "<ce:hsp sp=""0.10""/>")
        End If
        '---

        'Sasikala.K added for STAMS-6899 on 04-02-2020;
        '---
        If Regex.IsMatch(CurrData, "xml:lang=""de""") Then
            CurrData = Regex.Replace(CurrData, "<ce:hsp sp=""1""/>&#x2003;", "<ce:hsp sp=""1""/>")
            ''STAMS:8671;Balamurugan.K Added on 11-Dec-2020;
            CurrData = Regex.Replace(CurrData, "&#x2009;<ce:hsp sp=""0.25""/>", "<ce:hsp sp=""0.25""/>")
            ''---
        End If
        '---

        'P.Parthiban added for Bug:6034;on 21st SEP 2015;
        If Regex.IsMatch(CurrData, "xml:lang=""fr""") Then
            CurrData = Regex.Replace(CurrData, "&nbsp;(<!--)?<ce:hsp sp=""(0\.12|0\.25)""/>(-->)?", "<ce:hsp sp=""$2""/>")
        End If
        CurrData = Regex.Replace(CurrData, "(<!--<ce:hsp sp=""0.25""/>-->)?&thinsp;", "<ce:hsp sp=""0.25""/>")
        CurrData = Regex.Replace(CurrData, "(<!--<ce:hsp sp=""0.5""/>-->)?&ensp;", "<ce:hsp sp=""0.5""/>")
        'E.Raja
        CurrData = Regex.Replace(CurrData, "(<!--<ce:hsp sp=""0.75""/>-->)?&ensp;&thinsp;", "<ce:hsp sp=""0.75""/>")

        CurrData = Regex.Replace(CurrData, "(<!--<ce:hsp sp=""2(\.0)?""/>-->)?&emsp;&emsp;", "<ce:hsp sp=""2.0""/>")
        CurrData = Regex.Replace(CurrData, "(<!--<ce:hsp sp=""1(\.0)?""/>-->)?&emsp;", "<ce:hsp sp=""1.0""/>")
        CurrData = Regex.Replace(CurrData, "(\s*)?<ce:hsp sp=""(.[^<>]*?)""/>(\s*)?", "<ce:hsp sp=""$2""/>")
        CurrData = Regex.Replace(CurrData, "\&sp0.1(\d*)\;", "<ce:hsp sp=""0.1$1""/>")
        'Updated for Bug:3016 cmt 8; on 9th July 2013;
        CurrData = Regex.Replace(CurrData, "&hairsp;<ce:hsp sp=""0.12""/>", "<ce:hsp sp=""0.12""/>")
        CurrData = Regex.Replace(CurrData, "</ce:label>(<ce:hsp sp=""([^<>]*?)""/>)*([^<>]*?)?(<ce:hsp sp=""([^<>]*?)""/>)*<ce:caption([^<>]*?)?>", "</ce:label><ce:caption$6>")
        CurrData = Regex.Replace(CurrData, "</ce:label>(<ce:hsp sp=""([^<>]*?)""/>)*([^<>]*?)?(<ce:hsp sp=""([^<>]*?)""/>)*<ce:section-title(.[^<]*?)?>", "</ce:label><ce:section-title$6>")
        CurrData = Regex.Replace(CurrData, "</ce:label>(<ce:hsp sp=""([^<>]*?)""/>)*([^<>]*?)?(<ce:hsp sp=""([^<>]*?)""/>)*<<ce:para", "</ce:label><ce:para")
        CurrData = Regex.Replace(CurrData, "(<ce:figure([^<>]*?)>)(<ce:hsp sp=""([^<>]*?)""/>)+(<ce:label>)", "$1$5")

        CurrData = Regex.Replace(CurrData, "<ce:br></ce:br>", "<ce:br/>")
        CurrData = Regex.Replace(CurrData, "</ce:list-item>(.[^<>]*?)<ce:list-item(.[^<]*?)?>", "</ce:list-item><ce:list-item$2>")
        CurrData = Regex.Replace(CurrData, "<ce:list(.[^<]*?)?>(.[^<>]*?)<ce:list-item(.[^<]*?)?>", "<ce:list$1><ce:list-item$3>")
        CurrData = Regex.Replace(CurrData, "<mml:math xmlns:mml=""http://www.w3.org/1998/Math/MathML""", "<mml:math ")
        CurrData = Regex.Replace(CurrData, "<mml:([a-z]+) xmlns:mml=""http://www.w3.org/1998/Math/MathML""( |>)", "<mml:$1$2")
        CurrData = Regex.Replace(CurrData, "<mml:math altimg=""(.[^<>]*?)"" xmlns:mml=""http://www.w3.org/1998/Math/MathML""", "<mml:math altimg=""$1""")
        CurrData = Regex.Replace(CurrData, " xmlns:sb=""%ESSB.xmlns;""", "")
        CurrData = Regex.Replace(CurrData, "<sb:contribution langtype=""en"">", "<sb:contribution>")
        CurrData = Regex.Replace(CurrData, "<no>(.*?)</no><other-ref(.*?)?>", "<ce:label>$1</ce:label><other-ref$2>")
        CurrData = Regex.Replace(CurrData, "<ce:bold-italic>(.*?)</ce:bold-italic>", "<ce:bold><ce:italic>$1</ce:italic></ce:bold>")
        CurrData = Regex.Replace(CurrData, "<ce:italic-bold>(.*?)</ce:italic-bold>", "<ce:italic><ce:bold>$1</ce:bold></ce:italic>")
        CurrData = Regex.Replace(CurrData, "<ce:anchor id=""pp:([^<>]*?) np:([^<>]*?)"" role=""page-break""></ce:anchor>", "<ce:anchor id=""pp:$1 np:$2"" role=""page-break""/>")
        CurrData = Regex.Replace(CurrData, "<ce:anchor id=""me:([^<>]*?)"" role=""moved-element""></ce:anchor>", "<ce:anchor id=""me:$1"" role=""moved-element""/>")
        CurrData = Regex.Replace(CurrData, "<ce:anchor id=""pp:([^<>]*?) np:([^<>]*?)"" role=""page-break""/>", "<!--<ce:anchor id=""pp:$1 np:$2"" role=""page-break""/>-->")

        'E.Raja added in 03-Nov-2014 to comment ce:anchor tag without self closing. Req.by Bhupathi.
        'CurrData = Regex.Replace(CurrData, "<ce:anchor id=""pp:([^<>]*?) np:([^<>]*?)"" role=""page-break"">([^<>]*?)</ce:anchor>", "<!--<ce:anchor id=""pp:$1 np:$2"" role=""page-break"">$3</ce:anchor>-->")
        'E.Raja modified above line on 10-Mar-2017; bug id 9296;
        CurrData = Regex.Replace(CurrData, "<ce:anchor id=""pp:([^<>]*?) np:([^<>]*?)"" role=""page-break"">(.*?)</ce:anchor>", "<!--<ce:anchor id=""pp:$1 np:$2"" role=""page-break"">$3</ce:anchor>-->")

        CurrData = Regex.Replace(CurrData, "<ce:anchor role=""moved-element"" id=""me:([^<>]*?)""/>", "<!--<ce:anchor role=""moved-element"" id=""me:$1""/>-->")
        CurrData = Regex.Replace(CurrData, "<ce:anchor role=""moved-element"" id=""me:([^<>]*?)"">([^<>]*?)</ce:anchor>", "<!--<ce:anchor role=""moved-element"" id=""me:$1"">$2</ce:anchor>-->")
        ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
        CurrData = Regex.Replace(CurrData, "<ce:anchor id=""me:([^<>]*?)"" role=""moved-element""/>", "<!--<ce:anchor id=""me:$1"" role=""moved-element""/>-->")
        CurrData = Regex.Replace(CurrData, "<ce:para([^<>]*?)>\s", "<ce:para$1>")
        CurrData = Regex.Replace(CurrData, "\s</ce:para>", "</ce:para>")
        CurrData = Regex.Replace(CurrData, "<ce:subtitle></ce:subtitle>", "")
        CurrData = Regex.Replace(CurrData, ":(\s)(</ce:bold>|</ce:italic>|</ce:small-caps>|</ce:sup>|</ce:inf>|</ce:underline>)", ":$2$1")
        CurrData = CurrData.Replace("<SPiTag>", "")
        CurrData = CurrData.Replace("</SPiTag>", "")
        CurrData = CurrData.Replace("<!--t-->", "")
        CurrData = CurrData.Replace("<!--f-->", "")
        CurrData = CurrData.Replace("<!--b-->", "")
        CurrData = CurrData.Replace("<SPiIndexFlag><!--", "")
        CurrData = CurrData.Replace("--></SPiIndexFlag>", "")
        CurrData = Regex.Replace(CurrData, "<(/)?aq>", "")
        CurrData = Regex.Replace(CurrData, "</sb:([^<>]*?)>(\s)?(:|;|\-)(\s)?<sb:([^<>]*?)>", "</sb:$1><sb:$5>")
        CurrData = Regex.Replace(CurrData, "</sb:([^<>]*?)>(\s)?(:|;|\-)(\s)?</sb:([^<>]*?)>", "</sb:$1></sb:$5>")
        CurrData = Regex.Replace(CurrData, "</sb:([^<>]*?)>(\s)?&amp;thinsp;(;|:)(\s)?<sb:([^<>]*?)>", "</sb:$1><sb:$5>")
        CurrData = Regex.Replace(CurrData, "</sb:([^<>]*?)>(\s)?&thinsp;(;|:)(\s)?<sb:([^<>]*?)>", "</sb:$1><sb:$5>")
        CurrData = Regex.Replace(CurrData, "<sb:comment> ", "<sb:comment>")
        CurrData = Regex.Replace(CurrData, "</sb:maintitle></sb:title><sb:volume-nr> ", "</sb:maintitle></sb:title><sb:volume-nr>")
        CurrData = Regex.Replace(CurrData, "</sb:volume-nr></sb:series><sb:issue-nr> ", "</sb:volume-nr></sb:series><sb:issue-nr>")
        CurrData = Regex.Replace(CurrData, " </ce:surname><ce:given-name>", "</ce:surname><ce:given-name>")
        CurrData = Regex.Replace(CurrData, "</sb:([^<>]*?)>(\s)?<ce:hsp([^<>]*?)>(;|:)?(\s)?<sb:([^<>]*?)>", "</sb:$1><sb:$6>")
        CurrData = Regex.Replace(CurrData, "</ce:section-title>(\.)?(\s*|&ensp;|&emsp;)<ce:para([^<]*?)>", "</ce:section-title><ce:para$3>")

        If Not Regex.IsMatch(CurrData, "xml:lang=""fr""") Then
            'Sasikala.K added for STAMS-6404 on 09-11-19;
            CurrData = Replace(CurrData, "$", "S_P_I_D_O_L_L_A_R")
            CurrData = ProcessBoxFootnote(CurrData)

        End If
        'P.Parthiban added on 27th Feb 2014;
        CurrData = ProcessBoxSource(CurrData)
        'Sasikala.K added for STAMS-6404 on 09-11-19;
        CurrData = Replace(CurrData, "S_P_I_D_O_L_L_A_R", "$")

        CurrData = Regex.Replace(CurrData, "<(/)?SPie-component>", "")
        'E.Raja modified on 24-Aug-2017; STAMS ID 332;
        CurrData = Regex.Replace(CurrData, "<ce:doi>" & "http://dx.doi.org/", "<ce:doi>")
        CurrData = Regex.Replace(CurrData, "<ce:doi>" & "https://doi.org/", "<ce:doi>")
        '''''''''
        CurrData = Regex.Replace(CurrData, "</ce:keyword>, (<ce:keyword( [^<>]*?)?>)", "</ce:keyword>$1")
        CurrData = Regex.Replace(CurrData, "</ce:section-title>(.[^<>]*?)<ce:keyword>", "</ce:section-title><ce:keyword>")
        CurrData = Regex.Replace(CurrData, "</ce:section-title>(.[^<>]*?)<ce:abstract-sec", "</ce:section-title><ce:abstract-sec")

        CurrData = Regex.Replace(CurrData, "<(/)?SPie-component>", "")
        '---
        ''STAMS:7357;Balamurugan.K added on 11-May-2020;
        CurrData = Regex.Replace(CurrData, "<(/)?SPiMiniTOCRoot>", "")
        CurrData = Regex.Replace(CurrData, "<(/)?SPiMiniTOCContent>", "")
        CurrData = Regex.Replace(CurrData, "<(/)?SPiMiniTOCPage>", "")
        ''---
        'R.Sugavaneshwaran added on 5th june 2017:Bug id:9844
        'Dim Biographymatch As Match
        'Dim Biography As String
        'Biographymatch = Regex.Match(CurrData, "<ce:biography(.[^<>]*?)?>(.*?)</ce:biography>")
        'If Biographymatch.Success Then
        '    Biography = Biographymatch.Value
        '    CurrData = Regex.Replace(CurrData, "<ce:biography(.[^<>]*?)?>(.*?)</ce:biography><ce:bibliography(.[^<>]*?)?>(.*?)</ce:bibliography><SPIBIO></SPIBIO>", "<ce:bibliography$3>$4</ce:bibliography><ce:biography$1>$2</ce:biography>", RegexOptions.Singleline)
        'End If
        '----
        '----
        'R.Sugavaneshwaran added on 14th july 2017:bug:10056:
        'Dim biography As MatchCollection = Regex.Matches(CurrData, "<ce:biography(.[^<>]*?)?>(.*?)</ce:biography>", RegexOptions.IgnoreCase Or RegexOptions.Multiline)
        'If biography.Count > 0 Then
        '    CurrData = Regex.Replace(CurrData, "<ce:biography(.[^<>]*?)?>(.*?)</ce:biography>", "", RegexOptions.IgnoreCase Or RegexOptions.Multiline)
        '    For Each biograph As Match In biography
        '        Dim i As String = biograph.ToString
        '        i = Regex.Match(i, "id=""(.*?)""", RegexOptions.Singleline Or RegexOptions.IgnoreCase).Groups(1).Value
        '        CurrData = Regex.Replace(CurrData, "<SPIBIO id=""" & i & """></SPIBIO>", biograph.ToString, RegexOptions.IgnoreCase Or RegexOptions.Multiline)
        '    Next
        'End If
        '---
    End Sub

    Public Shared Function ProcessBoxSource(ByVal Data As String) As String
        Dim txtboxmtch As MatchCollection
        txtboxmtch = Regex.Matches(Data, "<ce:textbox(.[^<]*?)>(.*?)</ce:textbox>")
        If txtboxmtch.Count > 0 Then
            For Cont As Integer = 0 To txtboxmtch.Count - 1
                Dim rplBoxDta As String = "", src As String = "", BoxDta As String = ""
                BoxDta = txtboxmtch.Item(Cont).Groups(2).ToString
                rplBoxDta = txtboxmtch.Item(Cont).Groups(2).ToString
                If Regex.IsMatch(rplBoxDta, "<ce:source([^<>]*?)?>(.*?)</ce:source>") AndAlso Regex.IsMatch(rplBoxDta, "<BoxSource([^<>]*?)></BoxSource>") Then
                    'R.Sugavaneshwaran added on 05th march 2018:STAMS-1741
                    'src = Regex.Match(rplBoxDta, "<ce:source([^<>]*?)?>(.*?)</ce:source>").Groups(0).Value
                    'rplBoxDta = Regex.Replace(rplBoxDta, Regex.Escape(Regex.Match(rplBoxDta, "<ce:source([^<>]*?)?>(.*?)</ce:source>").Groups(0).Value), "")
                    'rplBoxDta = Regex.Replace(rplBoxDta, Regex.Match(rplBoxDta, "<BoxSource([^<>]*?)></BoxSource>").Groups(0).Value, src)
                    'Data = Regex.Replace(Data, Regex.Escape(BoxDta), rplBoxDta)
                    src = Regex.Match(rplBoxDta, "</ce:textbox-body>(<ce:source([^<>]*?)?>(.*?)</ce:source>)").Groups(1).Value
                    rplBoxDta = Regex.Replace(rplBoxDta, Regex.Escape(Regex.Match(rplBoxDta, "</ce:textbox-body>(<ce:source([^<>]*?)?>(.*?)</ce:source>)").Groups(1).Value), "")
                    rplBoxDta = Regex.Replace(rplBoxDta, Regex.Match(rplBoxDta, "<BoxSource([^<>]*?)></BoxSource>").Groups(0).Value, src)
                    Data = Regex.Replace(Data, Regex.Escape(BoxDta), rplBoxDta)
                    '---
                End If
            Next
        End If
        Return Data
    End Function

    Public Shared Function ProcessBoxFootnote(ByVal Data As String) As String
        'Data = Regex.Replace(Data, "$", "S_P_I_D_O_L_L_A_R")
        'CurrData = Replace(CurrData, "S_P_I_D_O_L_L_A_R", "$")
        Dim txtboxmtch As MatchCollection
        Dim Cont As Integer
        Dim BoxDta As String
        txtboxmtch = Regex.Matches(Data, "<ce:textbox(.[^<]*?)>(.*?)</ce:textbox>")
        Dim rplBoxDta As String = ""
        If txtboxmtch.Count > 0 Then
            For Cont = 0 To txtboxmtch.Count - 1
                BoxDta = txtboxmtch.Item(Cont).Groups(2).ToString
                rplBoxDta = txtboxmtch.Item(Cont).Groups(2).ToString
                Dim ftnte As MatchCollection = Regex.Matches(BoxDta, "<ce:footnote(.[^<>]*?)>(.*?)</ce:footnote>")
                If ftnte.Count > 0 Then
                    For footcnt As Integer = 0 To ftnte.Count - 1
                        If ftnte.Item(footcnt).ToString <> "" And Regex.IsMatch(rplBoxDta, "<BoxFootnote id=""" & Regex.Match(ftnte.Item(footcnt).Groups(1).Value, "id=""(.[^<>]*?)""").Groups(1).Value & """(/>|></BoxFootnote>)") Then
                            rplBoxDta = Regex.Replace(rplBoxDta, Regex.Escape(ftnte.Item(footcnt).ToString), "")
                            rplBoxDta = Regex.Replace(rplBoxDta, "<BoxFootnote id=""" & Regex.Match(ftnte.Item(footcnt).Groups(1).Value, "id=""(.[^<>]*?)""").Groups(1).Value & """(/>|></BoxFootnote>)", ftnte.Item(footcnt).ToString)
                        End If
                    Next
                    Data = Regex.Replace(Data, Regex.Escape(BoxDta), rplBoxDta)
                End If
            Next
        End If
        Return Data
    End Function

    Public Shared Function ProcessCommentIDs(ByVal Data As String) As String
        Dim cmmt As New ArrayList
        Dim mtches As MatchCollection = Regex.Matches(Data, "<sb:comment id=""(.[^<>]*?)"">(.[^<>]*?)</sb:comment>")
        For Each mth As Match In mtches
            cmmt.Add(mth.Value)
        Next
        Data = Regex.Replace(Data, "<sb:comment id=""(.[^<>]*?)"">(.[^<>]*?)</sb:comment>", "")
        Dim posmtches As MatchCollection = Regex.Matches(Data, "<!--InsertBibComment=""(.[^<>]*?)""?-->")
        For Each mt As Match In posmtches
            For i As Integer = 0 To cmmt.Count - 1
                Dim keyval As String = cmmt(i)
                If Regex.IsMatch(keyval, mt.Groups(1).Value) Then
                    Data = Regex.Replace(Data, mt.Value, keyval)
                    Exit For
                End If
            Next
        Next
        Data = Regex.Replace(Data, "<sb:comment id=""(.[^<>]*?)"">", "<sb:comment>")
        Data = Regex.Replace(Data, "<!--InsertBibComment=""(.[^<>]*?)""?-->", "")
        'Bug ID: 128620; Chithra.S added on 31/12/2022;
        '-----------------------------------------------
        'Dim ref As MatchCollection = Regex.Matches(Data, "<ce:bib-reference(.[^<>]*?)?id=""(.[^<>]*?)""(.[^<>]*?)?>(.*?)</ce:bib-reference>", RegexOptions.Compiled)
        'For Each refmatch As Match In ref
        '    Dim refvalue As String = refmatch.Value
        '    Dim tempvalue As String = Regex.Replace(refvalue, "<!--<sb:reference (.[^<>]*?)><ce:label>(.*?)</ce:label><!--InsertBibComment(.[^<>]*?)-->", "<!--<sb:reference $1><ce:label>$2</ce:label><InsertBibComment$3>")
        '    WholeData = Replace(WholeData, refvalue, tempvalue, , 1)
        'Next
        '-----------------------------------------------
        Return Data
    End Function
#End Region

#Region "Shared Sub PostProcessAuthorGroup(ByVal WholeData As String)"
    ''' <summary>
    ''' Post Process Author Group
    ''' </summary>
    ''' <param name="WholeData"></param>
    ''' <remarks></remarks>
    Shared Sub PostProcessAuthorGroup(ByRef WholeData As String)
        WholeData = Regex.Replace(WholeData, "<ce:author aid:pstyle=""([^<]*?)"" id=""([^<]*?)"">", "<ce:author id=""$2"">")
        WholeData = Regex.Replace(WholeData, "<ce:author aid:pstyle=""([^<>]*?)"">", "<ce:author>")
        Dim AuthContent As String
        For Each MatchAuthor As Match In Regex.Matches(WholeData, "<ce:author( [^<>]*?)?>(.*?)</ce:author>")
            AuthContent = MatchAuthor.Groups(2).Value
            AuthContent = Regex.Replace(AuthContent, "<ce:given-name>(.[^<]*?)</ce:given-name> <ce:surname>(.[^<]*?)</ce:surname>, (.*?)$", "<ce:given-name>$1</ce:given-name><ce:surname>$2</ce:surname>$3")
            AuthContent = Regex.Replace(AuthContent, "<ce:surname>(.[^<]*?)</ce:surname>, <ce:given-name>(.[^<]*?)</ce:given-name>, (.*?)$", "<ce:surname>$1</ce:surname><ce:given-name>$2</ce:given-name>$3")
            AuthContent = Regex.Replace(AuthContent, "<ce:given-name>(.[^<]*?)</ce:given-name> <ce:surname>(.[^<]*?)</ce:surname>$", "<ce:given-name>$1</ce:given-name><ce:surname>$2</ce:surname>")
            AuthContent = Regex.Replace(AuthContent, "<ce:surname>(.[^<]*?)</ce:surname>, <ce:given-name>(.[^<]*?)</ce:given-name>$", "<ce:surname>$1</ce:surname><ce:given-name>$2</ce:given-name>")
            AuthContent = Regex.Replace(AuthContent, "</ce:cross-ref>, <ce:e-address", "</ce:cross-ref><ce:e-address")
            AuthContent = Regex.Replace(AuthContent, "</ce:given-name> <ce:surname>", "</ce:given-name><ce:surname>")
            'P.Parthiban added for Bug:4213;on 8th Oct 2013;
            AuthContent = Regex.Replace(AuthContent, "</ce:cross-ref><ce:sup([^<>]*?)>,</ce:sup><ce:cross-ref ", "</ce:cross-ref><ce:cross-ref ")
            AuthContent = Regex.Replace(AuthContent, "(,|, | )<ce:cross-ref ", "<ce:cross-ref ")

            WholeData = Replace(WholeData, "<ce:author" & MatchAuthor.Groups(1).Value & ">" & MatchAuthor.Groups(2).Value & "</ce:author>", "<ce:author1" & MatchAuthor.Groups(1).Value & ">" & AuthContent & "</ce:author>")
        Next
        WholeData = Regex.Replace(WholeData, "<ce:author1", "<ce:author")
        'E.Raja modified on 04-Feb-2015. Req.By Bhupathi.
        'WholeData = Regex.Replace(WholeData, "</ce:author>(,|, | )<ce:affiliation", "</ce:author><ce:affiliation")
        'k.hemachandiran; bhupathi mail; 4.4.2015;
        WholeData = Regex.Replace(WholeData, "</ce:affiliation>, <ce:affiliation", "</ce:affiliation><ce:affiliation")
        WholeData = Regex.Replace(WholeData, "</ce:author>(,|, | |(\s)*)<ce:affiliation", "</ce:author><ce:affiliation")
        WholeData = Regex.Replace(WholeData, "</ce:author><ce:hsp sp=""(.[^<]*?)""/><ce:affiliation", "</ce:author><ce:affiliation")
        '''''''
        ''STAMS:9325;Balamurugan.K Added on 24-Apr-2021;
        WholeData = Regex.Replace(WholeData, "</ce:cross-ref><ce:sup([^<>]*?)>,</ce:sup><ce:cross-ref ", "</ce:cross-ref><ce:cross-ref ")
        WholeData = Regex.Replace(WholeData, "</ce:author>(,|, | |(\s)*)<ce:collaboration", "</ce:author><ce:collaboration")
        '''''''
    End Sub
#End Region

#Region "Shared Sub PostProcessTableConversion(ByVal WholeData As String)"
    ''' <summary>
    ''' Post Process Table Conversion.
    ''' </summary>
    ''' <param name="WholeData"></param>
    ''' <remarks></remarks>
    Shared Sub PostProcessTableConversion(ByRef WholeData As String)
        Dim TabContent As String
        Dim GData As String

        'K.Shanmuga Sundaram added for BugNo:STAMS-5477 on 18th June 2019;
        'Remove Empty Cell
        '-----
        WholeData = Regex.Replace(WholeData, "<Cell></Cell>", "", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline)
        '-----

        'P.Parthiban added for Bug:3519; on 15th Mar 2013; Handling nested table;
        For Each NestedTableMatch As Match In Regex.Matches(WholeData, "<ce:table((.[^<>]*?)?nested=""Yes""(.[^<>]*?)?>(.*?))</ce:table>", RegexOptions.Multiline Or RegexOptions.Singleline)
            TabContent = NestedTableMatch.Groups(1).Value
            For Each GroupMatch As Match In Regex.Matches(TabContent, "<table(.*?)</table>", RegexOptions.Multiline Or RegexOptions.Singleline)
                GData = GroupMatch.Groups(1).Value
                GData = MyReplFunc(GData, "</thead><tbody></entry>", "</entry></thead><tbody>")
                TabContent = Replace(TabContent, "<table" & GroupMatch.Groups(1).Value & "</table>", "<table1" & GData & "</table1>")
            Next
            TabContent = Regex.Replace(TabContent, "<tgroup(.*?)<ce:source(.[^<>]*?)?>(.*?)</ce:source>", "<ce:source$2>$3</ce:source><tgroup$1")
            TabContent = Regex.Replace(TabContent, " nested=""Yes""", "")
            WholeData = Replace(WholeData, "<ce:table" & NestedTableMatch.Groups(1).Value & "</ce:table>", "<ce:table1" & TabContent & "</ce:table1>")
        Next
        For Each TableMatch As Match In Regex.Matches(WholeData, "<ce:table(.*?)</ce:table>", RegexOptions.Multiline Or RegexOptions.Singleline)
            TabContent = TableMatch.Groups(1).Value
            For Each GroupMatch As Match In Regex.Matches(TabContent, "<table(.*?)</table>", RegexOptions.Multiline Or RegexOptions.Singleline)
                GData = GroupMatch.Groups(1).Value
                GData = MyReplFunc(GData, "</thead><tbody></entry>", "</entry></thead><tbody>")
                TabContent = Replace(TabContent, "<table" & GroupMatch.Groups(1).Value & "</table>", "<table1" & GData & "</table1>")
            Next
            TabContent = Regex.Replace(TabContent, "<tgroup(.*?)<ce:source(.[^<>]*?)?>(.*?)</ce:source>", "<ce:source$2>$3</ce:source><tgroup$1", RegexOptions.Multiline Or RegexOptions.Singleline)
            WholeData = Replace(WholeData, "<ce:table" & TableMatch.Groups(1).Value & "</ce:table>", "<ce:table1" & TabContent & "</ce:table1>")
        Next
        WholeData = Regex.Replace(WholeData, "<(/)?ce:table1", "<$1ce:table")
        WholeData = Regex.Replace(WholeData, "<table(.[^<]*?)>", "")
        WholeData = Regex.Replace(WholeData, "</table(1)?>", "")
        WholeData = Regex.Replace(WholeData, "<thead><entry", "<thead><row><entry")
        WholeData = Regex.Replace(WholeData, "<tbody><entry", "<tbody><row><entry")
        WholeData = Regex.Replace(WholeData, "</entry><entry(.[^<>]*?)?start=""row""", "</entry></row><row><entry$1")
        WholeData = Regex.Replace(WholeData, "<row(.[^<>]*?)?><entry(.[^<>]*?)?( row-valign=""(.[^<>]*?)"")", "<row$1 valign=""$4""><entry$2")
        ''...Bug #162918; Jayasangari.R added on 08-June-2023
        WholeData = Regex.Replace(WholeData, "</ce:caption><entry(.[^<>]*?)?( row-valign=""(.[^<>]*?)"")", "</ce:caption><row valign=""$3""><entry$1")

        WholeData = Regex.Replace(WholeData, "<row(.[^<>]*?)?><entry(.[^<>]*?)?( row-role=""(.[^<>]*?)"")", "<row$1 role=""$4""><entry$2")
        WholeData = Regex.Replace(WholeData, "<row(.[^<>]*?)?><entry(.[^<>]*?)?( row-rowsep=""(.[^<>]*?)"")", "<row$1 rowsep=""$4""><entry$2")
        WholeData = Regex.Replace(WholeData, "</entry></thead>", "</entry></row></thead>")
        WholeData = Regex.Replace(WholeData, "</entry></tbody>", "</entry></row></tbody>")
        WholeData = Regex.Replace(WholeData, "<tbody></thead><tbody>", "<tbody>")
        WholeData = Regex.Replace(WholeData, " start=""row""", "")
        WholeData = Regex.Replace(WholeData, "  ", " ")
        WholeData = Regex.Replace(WholeData, "<entry(.*?)>\s*", "<entry$1>")
        WholeData = Regex.Replace(WholeData, "\s*</entry>", "</entry>")
    End Sub
#End Region

#Region "Shared Sub PostProcessGeneralAfterReference(ByVal WholeData As String)"
    ''' <summary>
    ''' Post Process General after processing references.
    ''' </summary>
    ''' <param name="WholeData"></param>
    ''' <remarks></remarks>
    Shared Sub PostProcessGeneralAfterReference(ByRef WholeData As String)

        'k.hemachandiran; Added for parsing error; 11 aug 2014;
        WholeData = Regex.Replace(WholeData, "<sb:editors>(.[^<>]*?)<sb:editor>", "<sb:editors><sb:editor>")
        'WholeData = Regex.Replace(WholeData, " &amp; ", " & ")

        'P.Parthiban added for Script updation on 3rd JUN 2014

        WholeData = Regex.Replace(WholeData, "</ce:section-title>: <ce:para ", "</ce:section-title><ce:para ")
        'Hemachandiran; Bug:1272; To move all floating object (exclusing display and inline) within the float tags;
        WholeData = Regex.Replace(WholeData, "<ce:display><ce:figure", "<ce:display><1ce:figure")
        WholeData = Regex.Replace(WholeData, "<ce:display><ce:table", "<ce:display><1ce:table")
        WholeData = Regex.Replace(WholeData, "<ce:display><ce:textbox", "<ce:display><1ce:textbox")
        'P.Parthiban updated for Bug:3332;introduction with floats; on 16th Jan 2013;updated for alt attribute style in box on 10th July 2013;
        'WholeData = Regex.Replace(WholeData, "<ce:floats>(.*?)((<ce:figure(.[^<>]*?)aid:pstyle=""Fig leg"")|(<ce:table(.[^<>]*?)aid:pstyle=""T title"")|(<ce:textbox(.[^<>]*?)aid:pstyle=""B title""))(.*?)(</chapter>|</fb-non-chapter>|</introduction>)", "<ce:floats>$2$9$1$10", RegexOptions.Multiline Or RegexOptions.Singleline)
        ''STAMS:7192;Balamurugan.K added on 30-May-2020;
        Dim AnchorContents As String = ""
        If Regex.IsMatch(WholeData, "(<!--<ce:anchor (.[^<>]*?)>-->)+(</chapter>|</fb-non-chapter>|</introduction>)", RegexOptions.IgnoreCase) Then
            Dim PgBreakCol As MatchCollection = Regex.Matches(WholeData, "(<!--<ce:anchor (.[^<>]*?)>-->)+(</chapter>|</fb-non-chapter>|</introduction>)")
            If PgBreakCol.Count > 0 Then
                For j As Integer = 0 To PgBreakCol.Count - 1
                    Dim mtc As Match = PgBreakCol.Item(j)
                    AnchorContents &= Regex.Replace(mtc.Groups(0).Value, "(</chapter>|</fb-non-chapter>|</introduction>)", "")

                    WholeData = WholeData.Replace(Regex.Replace(mtc.Groups(0).Value, "(</chapter>|</fb-non-chapter>|</introduction>)", ""), "")
                Next
            End If
        End If
        ''---
        ''Bug# 169316; Jayasangari.R commented & added on 23-June-2023;Improvement #153674(for textbox)
        'WholeData = Regex.Replace(WholeData, "<ce:floats>(.*?)((<ce:figure(.[^<>]*?)aid:pstyle=""Fig leg"")|(<ce:table(.[^<>]*?)aid:pstyle=""T title"")|(<ce:textbox(.[^<>]*?)aid:pstyle=""B title(.[^<>]*?)?""))(.*?)(</chapter>|</fb-non-chapter>|</introduction>)", "<ce:floats>$2$10$1$11", RegexOptions.Multiline Or RegexOptions.Singleline)
        'redmine 251630
        'WholeData = Regex.Replace(WholeData, "<ce:floats>(.*?)((<ce:figure(.[^<>]*?)aid:pstyle=""Fig leg"")|(<ce:table(.[^<>]*?)aid:pstyle=""(.[^<>]*?)"")|(<ce:textbox(.[^<>]*?)aid:pstyle=""(.[^<>]*?)?""))(.*?)(</chapter>|</fb-non-chapter>|</introduction>)", "<ce:floats>$2$11$1$12", RegexOptions.Multiline Or RegexOptions.Singleline)
        WholeData = Regex.Replace(WholeData, "<ce:floats>(.*?)((<ce:figure(.[^<>]*?)aid:pstyle=""Fig leg"")|(<ce:table(.[^<>]*?)aid:pstyle=""(.[^<>]*?)"")|(<ce:textbox(.[^<>]*?)aid:pstyle=""(.[^<>]*?)?""))(.*?)(</chapter>|</fb-non-chapter>|</introduction>)", "<ce:floats>$2$11$1$12", RegexOptions.Multiline Or RegexOptions.Singleline)
        '-------------------------------------------------
        ''REDMINE:273326, 238152, 251630, EB-2918; Aradadi Prudhvi Raj updated on 07-11-2024;
        If Regex.IsMatch(WholeData, "(<chapter (.*?)>)(<ce:table-footnote (.*?)=(""(.*?)"")>(.*?)</ce:sections>)(.*)</chapter>", RegexOptions.IgnoreCase) Then
            WholeData = Regex.Replace(WholeData, "(<chapter (.*?)>)(<ce:table-footnote (.*?)=(""(.*?)"")>(.*?)</ce:sections>)(.*)</chapter>", "$1>$8$3</chapter>", RegexOptions.Multiline Or RegexOptions.Singleline)
            WholeData = Regex.Replace(WholeData, "<chapter (.*?)>(.*?)(<ce:bibliography id=""(.*?)"">(.*?)</ce:bibliography>)(.*?)(<ce:sections>(.*?)</ce:sections>)", "<chapter $1>$2$6$7$3", RegexOptions.Multiline Or RegexOptions.Singleline)
        End If

        '''REDMINE:251630; Aradadi Prudhvi Raj added on 17-07-2024
        'If Regex.IsMatch(WholeData, "<chapter (.*?)>(<ce:table-footnote (id|aid:pstyle=""(.*?)"")>(.*?)</ce:sections>)(.*?)</chapter>", RegexOptions.IgnoreCase) Then
        '    WholeData = Regex.Replace(WholeData, "<chapter (.*?)>(<ce:table-footnote (id|aid:pstyle=""(.*?)"")>(.*?)</ce:sections>)(.*?)</chapter>", "<chapter $1>$6$2</chapter>", RegexOptions.Multiline Or RegexOptions.Singleline)
        'End If
        '''---------------------------------------


        '---------------------


        ''STAMS:7192;Balamurugan.K added on 30-May-2020;
        If AnchorContents <> "" Then
            WholeData = Regex.Replace(WholeData, "(</chapter>|</fb-non-chapter>|</introduction>)", AnchorContents & "$1")
        End If
        ''--
        'Dim fmtch As Match = Regex.Match(WholeData, "<ce:floats>(.*?)((<ce:figure(.[^<>]*?)aid:pstyle=""Fig leg"")|(<ce:table(.[^<>]*?)aid:pstyle=""T title"")|(<ce:textbox(.[^<>]*?)aid:pstyle=""B title""))(.*?)(</chapter>|</fb-non-chapter>|</introduction>)", RegexOptions.Multiline Or RegexOptions.Singleline)
        'If fmtch.Success Then
        '    Dim replstr = fmtch.Groups(2).Value & fmtch.Groups(9).Value
        '    WholeData = Replace(WholeData, replstr, "")
        '    WholeData = Replace(WholeData, "<ce:floats></ce:floats>", "<ce:floats>" & replstr & "</ce:floats>")
        'End If

        'K.Shanmuga Sundaram/P.Parthiban commented for Bugs:8790 on 13th Dec 2016;
        '-----
        Dim arr As New ArrayList
        Dim contag As String = ""
        Dim cont As String = ""
        Dim comp As MatchCollection = Regex.Matches(WholeData, "<ce:e-component( [^<>]*?)? SPifloat=""Yes""( [^<>]*?)?>(.*?)</ce:e-component>")
        If comp.Count > 0 Then
            For j As Integer = 0 To comp.Count - 1
                Dim mtc As Match = comp.Item(j)
                cont &= mtc.Groups(0).Value
                WholeData = WholeData.Replace(mtc.Groups(0).Value, "")
            Next
            WholeData = WholeData.Replace("</ce:floats>", cont.Replace(" SPifloat=""Yes""", "") & "</ce:floats>")
        End If
        '-----

        WholeData = Regex.Replace(WholeData, "<ce:floats>(</ce:bibliography>|</ce:further-reading>)", "<ce:floats>")
        WholeData = Regex.Replace(WholeData, "<ce:display><1ce:figure", "<ce:display><ce:figure")
        WholeData = Regex.Replace(WholeData, "<ce:display><1ce:table", "<ce:display><ce:table")
        WholeData = Regex.Replace(WholeData, "<ce:display><1ce:textbox", "<ce:display><ce:textbox")

        WholeData = Regex.Replace(WholeData, "</ce:bibliography-sec></chapter>", "</ce:bibliography-sec></ce:bibliography></chapter>")
        WholeData = Regex.Replace(WholeData, "</ce:further-reading-sec></chapter>", "</ce:further-reading-sec></ce:further-reading></chapter>")

        'E.Raja modified on 23-Jan-2017; Bug id 8992;
        'WholeData = Regex.Replace(WholeData, " aid:pstyle=""(.[^<]*?)""", "")
        'WholeData = Regex.Replace(WholeData, " aid:cstyle=""(.[^<]*?)""", "")
        WholeData = Regex.Replace(WholeData, "(\s*)aid:pstyle=""(.[^<]*?)""", "")
        WholeData = Regex.Replace(WholeData, "(\s*)aid:cstyle=""(.[^<]*?)""", "")
        ''''''''''
        ''P.Parthiban updated on 30th JUNE 2015 & 4th FEB 2015; Bug:5564 & 6846; 
        ''  WholeData = Regex.Replace(WholeData, "<ce:doctopics>((<ce:doctopic><ce:text(.[^<>]*?)>(.*?)</ce:text></ce:doctopic>)*)</ce:doctopics></info>((<ce:doctopic><ce:text(.[^<>]*?)>(.*?)</ce:text></ce:doctopic>)+)", "<ce:doctopics>$1$5</ce:doctopics></info>")
        'WholeData = Regex.Replace(WholeData, "<ce:doctopics>((<ce:doctopic><ce:text( [^<>]*?)?>(.*?)</ce:text></ce:doctopic>)*)</ce:doctopics></info>((<ce:doctopic><ce:text( [^<>]*?)?>(.*?)</ce:text></ce:doctopic>)+)", "<ce:doctopics>$1$5</ce:doctopics></info>")
        WholeData = Regex.Replace(WholeData, "<ce:doctopics>((<ce:doctopic( [^<>]*?)?><ce:text( [^<>]*?)?>(.*?)</ce:text></ce:doctopic>)*)</ce:doctopics></info>((<ce:doctopic( [^<>]*?)?><ce:text( [^<>]*?)?>(.*?)</ce:text></ce:doctopic>)+)", "<ce:doctopics>$1$6</ce:doctopics></info>")
        WholeData = Regex.Replace(WholeData, "</ce:label>(.[^<]*?)<ce:note-para(.[^<]*?)?>", "</ce:label><ce:note-para$2>")
        WholeData = Regex.Replace(WholeData, "<ce:float-anchor refid=""(.[^<>]*?)""/></ce:section-title><ce:para(.[^<]*?)?></ce:para>", "</ce:section-title><ce:para$2><ce:float-anchor refid=""$1""/></ce:para>")
        WholeData = Regex.Replace(WholeData, "<ce:doctopic></ce:doctopic>", "")
        WholeData = Regex.Replace(WholeData, "<ce:displayed-quote(.[^<]*?)?></ce:displayed-quote>", "")
        WholeData = Regex.Replace(WholeData, "<ce:author-group></ce:author-group>", "")
        WholeData = Regex.Replace(WholeData, "<outline></outline>", "")
        WholeData = Regex.Replace(WholeData, "</tgroup>(\d+)<", "</tgroup><")
        WholeData = Regex.Replace(WholeData, "</ce:caption>(\d+)<", "</ce:caption><")
        WholeData = Regex.Replace(WholeData, "</ce:caption> <ce:source>", "</ce:caption><ce:source>")
        WholeData = Regex.Replace(WholeData, """ >", """>")
        WholeData = Regex.Replace(WholeData, "<SPiTag><ce:float-anchor refid=""(.[^<]*?)""/></SPiTag>", "")
        WholeData = Regex.Replace(WholeData, "</ce:label><ce:doctopic>(.[^<]*?)</ce:doctopic><ce:title>", "</ce:label><ce:title>")
        WholeData = Regex.Replace(WholeData, "<ce:sup loc=""post"">", "<ce:sup>")
        WholeData = Regex.Replace(WholeData, "<ce:inf loc=""post"">", "<ce:inf>")
        WholeData = Regex.Replace(WholeData, "<chapter><index", "<index")
        WholeData = Regex.Replace(WholeData, "</index></chapter>", "</index>")
        WholeData = Regex.Replace(WholeData, "</ce:index-heading>, <ce:intra-ref", "</ce:index-heading><ce:intra-ref")
        WholeData = Regex.Replace(WholeData, "</ce:index-heading>; ", "</ce:index-heading>")
        WholeData = Regex.Replace(WholeData, "</ce:index-heading>((\s)*\((\s)*)", "$1</ce:index-heading>")

        'b.Sujatha modified for bug:8702 on 24-Nov-2016
        '-----
        'Dim indexentry As MatchCollection = Regex.Matches(WholeData, "<ce:index-entry(.*?)</ce:index-entry>")
        Dim indexentry As MatchCollection = Regex.Matches(WholeData, "<ce:index-entry(.*?)</ce:index-entry>", RegexOptions.Singleline)
        '-----
        For i As Integer = 0 To indexentry.Count - 1
            If Regex.IsMatch(indexentry(i).Groups(0).Value, "</ce:intra-ref>, <ce:intra-ref") Then
                Dim repstr As String = Regex.Replace(indexentry(i).Groups(0).Value, "</ce:intra-ref>, <ce:intra-ref", "</ce:intra-ref><ce:intra-ref")
                WholeData = Regex.Replace(WholeData, Regex.Escape(indexentry(i).Groups(0).Value), repstr)
            End If
        Next
        'bug id 6383; E.Raja modified on 18-Nov-2015; To retain id in intra-refs.
        'WholeData = Regex.Replace(WholeData, "<ce:intra-refs (.[^<>]*?)>", "<ce:intra-refs>")
        WholeData = Regex.Replace(WholeData, "<ce:intra-refs id=""(.[^<>]*?)""(.[^<>]*?)?>", "<ce:intra-refs id=""$1"">", RegexOptions.Singleline Or RegexOptions.IgnoreCase)

        WholeData = Regex.Replace(WholeData, "<ce:intra-refs-text(.[^<>]*?)?id=""(.[^<>]*?)""(.[^<>]*?)?>", "<ce:intra-refs-text id=""$2"">")

        'Sasikala.K added for STAMS-4810 on 20th Aug 2019;
        '----
        If Regex.IsMatch(WholeData, "xml:lang=""fr""") Then
            WholeData = Regex.Replace(WholeData, "</ce:index-heading>. (<ce:see([^<>]*?)?>\()<ce:italic>Voir </ce:italic>", "</ce:index-heading>$1", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:index-heading>. (<ce:see-also([^<>]*?)?>\()<ce:italic>Voir aussi </ce:italic>", "</ce:index-heading>$1", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:intra-ref>. (<ce:see([^<>]*?)?>\()<ce:italic>Voir </ce:italic>", "</ce:intra-ref>$1", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:intra-ref>. (<ce:see-also([^<>]*?)?>\()<ce:italic>Voir aussi </ce:italic>", "</ce:intra-ref>$1", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:index-heading>. <ce:italic>Voir</ce:italic> <ce:see", "</ce:index-heading><ce:see", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:index-heading>. <ce:italic>Voir aussi</ce:italic> <ce:see-also", "</ce:index-heading><ce:see-also", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:index-entry>. <ce:italic>Voir aussi</ce:italic> <ce:see-also", "</ce:index-entry><ce:see-also", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:intra-ref>. <ce:italic>Voir</ce:italic> <ce:see", "</ce:intra-ref><ce:see", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:intra-ref>. <ce:italic>Voir aussi</ce:italic> <ce:see-also", "</ce:intra-ref><ce:see-also", RegexOptions.IgnoreCase)
            '----
            'Sasikala.K added for STAMS-9131 on 19-03-2021;
            '---
        ElseIf Regex.IsMatch(WholeData, "xml:lang=""de""") Then
            WholeData = Regex.Replace(WholeData, "</ce:index-heading>. (<ce:see([^<>]*?)?>\()<ce:italic>Siehe </ce:italic>", "</ce:index-heading>$1", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:index-heading>. (<ce:see-also([^<>]*?)?>\()<ce:italic>Siehe auch </ce:italic>", "</ce:index-heading>$1", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:intra-ref>. (<ce:see([^<>]*?)?>\()<ce:italic>Siehe </ce:italic>", "</ce:intra-ref>$1", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:intra-ref>. (<ce:see-also([^<>]*?)?>\()<ce:italic>Siehe auch </ce:italic>", "</ce:intra-ref>$1", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:index-heading>. <ce:italic>Siehe</ce:italic> <ce:see", "</ce:index-heading><ce:see", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:index-heading>. <ce:italic>Siehe auch</ce:italic> <ce:see-also", "</ce:index-heading><ce:see-also", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:index-entry>. <ce:italic>Siehe auch</ce:italic> <ce:see-also", "</ce:index-entry><ce:see-also", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:intra-ref>. <ce:italic>Siehe</ce:italic> <ce:see", "</ce:intra-ref><ce:see", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:intra-ref>. <ce:italic>Siehe auch</ce:italic> <ce:see-also", "</ce:intra-ref><ce:see-also", RegexOptions.IgnoreCase)
            '---
        Else

            'P.Parthiban added for Bug:3830; on 10th July 2013;
            WholeData = Regex.Replace(WholeData, "</ce:index-heading>. (<ce:see([^<>]*?)?>\()<ce:italic>See </ce:italic>", "</ce:index-heading>$1", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:index-heading>. (<ce:see-also([^<>]*?)?>\()<ce:italic>See also </ce:italic>", "</ce:index-heading>$1", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:intra-ref>. (<ce:see([^<>]*?)?>\()<ce:italic>See </ce:italic>", "</ce:intra-ref>$1", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:intra-ref>. (<ce:see-also([^<>]*?)?>\()<ce:italic>See also </ce:italic>", "</ce:intra-ref>$1", RegexOptions.IgnoreCase)

            WholeData = Regex.Replace(WholeData, "</ce:index-heading>. <ce:italic>See</ce:italic> <ce:see", "</ce:index-heading><ce:see", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:index-heading>. <ce:italic>See also</ce:italic> <ce:see-also", "</ce:index-heading><ce:see-also", RegexOptions.IgnoreCase)
            'M.Murugan added for Bug:8966 on Jan 17th 2017;
            WholeData = Regex.Replace(WholeData, "</ce:index-entry>. <ce:italic>See also</ce:italic> <ce:see-also", "</ce:index-entry><ce:see-also", RegexOptions.IgnoreCase)
            '--------------
            WholeData = Regex.Replace(WholeData, "</ce:intra-ref>. <ce:italic>See</ce:italic> <ce:see", "</ce:intra-ref><ce:see", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:intra-ref>. <ce:italic>See also</ce:italic> <ce:see-also", "</ce:intra-ref><ce:see-also", RegexOptions.IgnoreCase)
        End If

        WholeData = Regex.Replace(WholeData, "</ce:see-also>.<(/)?ce:index-entry", "</ce:see-also><$1ce:index-entry")
        WholeData = Regex.Replace(WholeData, "</ce:see>.<(/)?ce:index-entry", "</ce:see><$1ce:index-entry")


        'Sasikala.K added for STAMS-4810 on 20th Aug 2019;
        '----
        If Regex.IsMatch(WholeData, "xml:lang=""fr""") Then
            WholeData = Regex.Replace(WholeData, "</ce:index-heading>(,\s|\s)?Voir(\s)?<ce:see", "</ce:index-heading><ce:see", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:index-heading>(,\s|\s)?Voir aussi(\s)?<ce:see-also", "</ce:index-heading><ce:see-also", RegexOptions.IgnoreCase)
            '----
            'Sasikala.K added for STAMS-9131 on 19-03-2021;
            '---
        ElseIf Regex.IsMatch(WholeData, "xml:lang=""de""") Then
            WholeData = Regex.Replace(WholeData, "</ce:index-heading>(,\s|\s)?Siehe(\s)?<ce:see", "</ce:index-heading><ce:see", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:index-heading>(,\s|\s)?Siehe auch(\s)?<ce:see-also", "</ce:index-heading><ce:see-also", RegexOptions.IgnoreCase)
            '---
        Else
            WholeData = Regex.Replace(WholeData, "</ce:index-heading>(,\s|\s)?see(\s)?<ce:see", "</ce:index-heading><ce:see", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:index-heading>(,\s|\s)?see also(\s)?<ce:see-also", "</ce:index-heading><ce:see-also", RegexOptions.IgnoreCase)
        End If


        WholeData = Regex.Replace(WholeData, "</ce:index-heading><ce:hsp sp=""(.[^<]*?)""/><ce:index-entry", "</ce:index-heading><ce:index-entry")
        WholeData = Regex.Replace(WholeData, "</ce:intra-ref><ce:hsp sp=""(.[^<]*?)""/><ce:index-entry", "</ce:intra-ref><ce:index-entry")


        'Sasikala.K added for STAMS-4810 on 20th Aug 2019;
        '----
        If Regex.IsMatch(WholeData, "xml:lang=""fr""") Then
            WholeData = Regex.Replace(WholeData, "</ce:intra-ref><ce:hsp sp=""(.[^<]*?)""/><ce:italic>Voir aussi</ce:italic> <ce:see-also", "</ce:intra-ref><ce:see-also", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:intra-ref><ce:hsp sp=""(.[^<]*?)""/><ce:italic>Voir</ce:italic> <ce:see", "</ce:intra-ref><ce:see", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:index-heading><ce:hsp sp=""(.[^<]*?)""/><ce:italic>Voir aussi</ce:italic> <ce:see-also", "</ce:index-heading><ce:see-also", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:index-heading><ce:hsp sp=""(.[^<]*?)""/><ce:italic>Voir</ce:italic> <ce:see", "</ce:index-heading><ce:see", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:reader-see>. <ce:italic>Voir aussi</ce:italic> <ce:see-also refid=""(.*?)"">", "</ce:reader-see><ce:see-also refid=""$1"">")
            WholeData = Regex.Replace(WholeData, "</ce:reader-see>. <ce:italic>Voir</ce:italic> <ce:see refid=""(.*?)"">", "</ce:reader-see><ce:see refid=""$1"">")
            WholeData = Regex.Replace(WholeData, "<ce:italic>Voir</ce:italic> <ce:reader-see>", "<ce:reader-see>")
            '----
            'Sasikala.K added for STAMS-9131 on 19-03-2021;
            '---
        ElseIf Regex.IsMatch(WholeData, "xml:lang=""de""") Then
            WholeData = Regex.Replace(WholeData, "</ce:intra-ref><ce:hsp sp=""(.[^<]*?)""/><ce:italic>Siehe auch</ce:italic> <ce:see-also", "</ce:intra-ref><ce:see-also", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:intra-ref><ce:hsp sp=""(.[^<]*?)""/><ce:italic>Siehe</ce:italic> <ce:see", "</ce:intra-ref><ce:see", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:index-heading><ce:hsp sp=""(.[^<]*?)""/><ce:italic>Siehe auch</ce:italic> <ce:see-also", "</ce:index-heading><ce:see-also", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:index-heading><ce:hsp sp=""(.[^<]*?)""/><ce:italic>Siehe</ce:italic> <ce:see", "</ce:index-heading><ce:see", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:reader-see>. <ce:italic>Siehe auch</ce:italic> <ce:see-also refid=""(.*?)"">", "</ce:reader-see><ce:see-also refid=""$1"">")
            WholeData = Regex.Replace(WholeData, "</ce:reader-see>. <ce:italic>Siehe</ce:italic> <ce:see refid=""(.*?)"">", "</ce:reader-see><ce:see refid=""$1"">")
            WholeData = Regex.Replace(WholeData, "<ce:italic>Siehe</ce:italic> <ce:reader-see>", "<ce:reader-see>")
            '---
        Else
            WholeData = Regex.Replace(WholeData, "</ce:intra-ref><ce:hsp sp=""(.[^<]*?)""/><ce:italic>see also</ce:italic> <ce:see-also", "</ce:intra-ref><ce:see-also", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:intra-ref><ce:hsp sp=""(.[^<]*?)""/><ce:italic>see</ce:italic> <ce:see", "</ce:intra-ref><ce:see", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:index-heading><ce:hsp sp=""(.[^<]*?)""/><ce:italic>see also</ce:italic> <ce:see-also", "</ce:index-heading><ce:see-also", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:index-heading><ce:hsp sp=""(.[^<]*?)""/><ce:italic>see</ce:italic> <ce:see", "</ce:index-heading><ce:see", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</ce:reader-see>. <ce:italic>See also</ce:italic> <ce:see-also refid=""(.*?)"">", "</ce:reader-see><ce:see-also refid=""$1"">")
            WholeData = Regex.Replace(WholeData, "</ce:reader-see>. <ce:italic>See</ce:italic> <ce:see refid=""(.*?)"">", "</ce:reader-see><ce:see refid=""$1"">")
            WholeData = Regex.Replace(WholeData, "<ce:italic>See</ce:italic> <ce:reader-see>", "<ce:reader-see>")
        End If


        WholeData = Regex.Replace(WholeData, "&xxx25BC;", "&dtrif;")
        WholeData = Regex.Replace(WholeData, "&rsquor;", "&rsquo;")
        WholeData = Regex.Replace(WholeData, "&mldr;", "&hellip;")
        WholeData = Regex.Replace(WholeData, "&newacute;", "&times;")
        WholeData = Regex.Replace(WholeData, "&x002D;", "&hyphen;")
        WholeData = Regex.Replace(WholeData, "&pm;", "&plusmn;")
        WholeData = Regex.Replace(WholeData, "([A-z])&rsquo;([A-z])", "$1&apos;$2")
        WholeData = Regex.Replace(WholeData, "&amp;percnt;", "&percnt;")
        WholeData = Regex.Replace(WholeData, "<ce:label> ", "<ce:label>")
        WholeData = Regex.Replace(WholeData, " </ce:label> ", "</ce:label>")
        WholeData = Regex.Replace(WholeData, "<sb:et-al>et al</sb:et-al>", "<sb:et-al/>")
        WholeData = Regex.Replace(WholeData, "</ce:para><ce:hsp sp=""(.[^<]*?)""/><ce:para>", "<ce:hsp sp=""$1""/>")
        WholeData = Regex.Replace(WholeData, "<ce:hsp sp=""0.25""/>(\+|\=|\-|\/|\*)<ce:hsp sp=""0.25""/>", " $1 ")


        'Sasikala.K added for STAMS-4810 on 20th Aug 2019;
        '----
        If Regex.IsMatch(WholeData, "xml:lang=""fr""") Then
            WholeData = Regex.Replace(WholeData, "<ce:italic>Voir</ce:italic> <ce:see", " <ce:see", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "<ce:italic>Voir aussi</ce:italic> <ce:see-also", " <ce:see-also", RegexOptions.IgnoreCase)
            '----
            'Sasikala.K added for STAMS-9131 on 19-03-2021;
            '---
        ElseIf Regex.IsMatch(WholeData, "xml:lang=""de""") Then
            WholeData = Regex.Replace(WholeData, "<ce:italic>Siehe</ce:italic> <ce:see", " <ce:see", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "<ce:italic>Siehe auch</ce:italic> <ce:see-also", " <ce:see-also", RegexOptions.IgnoreCase)
            '---
        Else
            WholeData = Regex.Replace(WholeData, "<ce:italic>See</ce:italic> <ce:see", " <ce:see", RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "<ce:italic>See also</ce:italic> <ce:see-also", " <ce:see-also", RegexOptions.IgnoreCase)
        End If
        'Sasikala.K added for STAMS-9131 on 19-03-2021;
        '---
        If Regex.IsMatch(WholeData, "xml:lang=""de""", RegexOptions.Compiled) Then
            WholeData = Regex.Replace(WholeData, "</ce:index-heading> <ce:intra-ref", "</ce:index-heading><ce:intra-ref", RegexOptions.Compiled)
        End If
        '---

        WholeData = Regex.Replace(WholeData, " xlink:href=""simple""", "", RegexOptions.IgnoreCase)
        WholeData = Regex.Replace(WholeData, "<ce:intra-ref([^<>]*?)(\s?)xlink:type=""simple""([^<>]*?)>", "<ce:intra-ref$1$3>", RegexOptions.IgnoreCase)
        WholeData = Regex.Replace(WholeData, "<ce:inter-ref([^<>]*?)(\s?)xlink:type=""simple""([^<>]*?)>", "<ce:inter-ref$1$3>", RegexOptions.IgnoreCase)
        WholeData = Regex.Replace(WholeData, "</ce:index-entry>([^<]*?)\(Continued\)<ce:index-entry", "</ce:index-entry><ce:index-entry", RegexOptions.IgnoreCase)
        WholeData = Regex.Replace(WholeData, "</ce:def-term>([^<>]*?)<ce:def-term>", "</ce:def-term><ce:def-term>")
        WholeData = Regex.Replace(WholeData, "<SPiFootNote></SPiFootNote>", "", RegexOptions.IgnoreCase)
        WholeData = Regex.Replace(WholeData, "<ce:keywords></ce:keywords>", "", RegexOptions.IgnoreCase)
        WholeData = Regex.Replace(WholeData, "<ce:abstract></ce:abstract>", "", RegexOptions.IgnoreCase)
        WholeData = Regex.Replace(WholeData, "<SPiFootNote/>", "", RegexOptions.IgnoreCase)
        WholeData = Replace(WholeData, vbCr, "")
        WholeData = Replace(WholeData, vbLf, "")
        WholeData = Replace(WholeData, vbCrLf, "")
        WholeData = Regex.Replace(WholeData, "</ce:glossary-heading><ce:hsp sp=(.[^<>]*?)/><ce:glossary-def>", "</ce:glossary-heading><ce:glossary-def>")
        WholeData = Regex.Replace(WholeData, "</ce:glossary-heading>(\s)?&([^<>]*?);(\s)?<ce:glossary-def>", "</ce:glossary-heading><ce:glossary-def>")

        WholeData = Regex.Replace(WholeData, "</ce:suffix>(, |\s|. )?<ce:degrees>", "</ce:suffix><ce:degrees>")
        WholeData = Regex.Replace(WholeData, "</ce:surname>(, |\s)?<ce:suffix>", "</ce:surname><ce:suffix>")
        WholeData = Regex.Replace(WholeData, "</ce:given-name>(, |\s)?<ce:suffix>", "</ce:given-name><ce:suffix>")
        WholeData = Regex.Replace(WholeData, "</ce:surname>(, |\s|. )?<ce:degrees>", "</ce:surname><ce:degrees>")
        WholeData = Regex.Replace(WholeData, "</ce:given-name>(, |\s|. )?<ce:degrees>", "</ce:given-name><ce:degrees>")
        WholeData = Regex.Replace(WholeData, "</ce:degrees>(, |\s|. )?<ce:surname>", "</ce:degrees><ce:surname>")
        WholeData = Regex.Replace(WholeData, "</ce:degrees>(, |\s|. )?<ce:given-name>", "</ce:degrees><ce:given-name>")
        WholeData = Regex.Replace(WholeData, "</ce:affiliation>\s?<ce:affiliation id=([^<>]*?)>", "</ce:affiliation><ce:affiliation id=$1>")
        WholeData = Regex.Replace(WholeData, "</ce:author-group>(\s)?(&amp;)?(\s)?<ce:author-group>", "</ce:author-group><ce:author-group>")
        WholeData = Regex.Replace(WholeData, "<ce:author>\s?<ce:given-name>", "<ce:author><ce:given-name>")
        WholeData = Regex.Replace(WholeData, "<ce:affiliation id=([^<>]*?)>\s?<ce:textfn id=([^<>]*?)>", "<ce:affiliation id=$1><ce:textfn id=$2>")
        WholeData = Regex.Replace(WholeData, "</ce:author>(\s|, )?&bull;(\s|, )?<ce:author id=([^<>]*?)>", "</ce:author><ce:author id=$3>")
        WholeData = Regex.Replace(WholeData, "</ce:surname>(, | )?<ce:given-name>", "</ce:surname><ce:given-name>")
        WholeData = Regex.Replace(WholeData, "</ce:author>(, |; |, and |; and | | and |,and|; and|, and)<ce:author", "</ce:author><ce:author")
        WholeData = Replace(WholeData, "&#xd;&#xa;", "")
        WholeData = Regex.Replace(WholeData, "</ce:def-term>&(.*?);<ce:def-description>", "</ce:def-term><ce:def-description>")
        WholeData = Regex.Replace(WholeData, "</ce:def-term><ce:hsp(\s)sp=""([^<]*?)""/><ce:def-description>", "</ce:def-term><ce:def-description>")
        WholeData = Regex.Replace(WholeData, "</ce:para><ce:hsp sp=""([^<]*?)""/><ce:para", "</ce:para><ce:para")
        WholeData = Regex.Replace(WholeData, "</info><!--<ce:title>(.*?)</ce:title>-->", "</info><ce:title>$1</ce:title>")
        WholeData = Regex.Replace(WholeData, "</info><!--<ce:title></ce:title>-->", "</info><ce:title></ce:title>")
        'Bug 1353,1355; R.Thinagaran; 2009.12.03; vtool errors.
        WholeData = Regex.Replace(WholeData, ":(\s)?<ce:subtitle>([^<]*?)</ce:subtitle></ce:title>", "</ce:title><ce:subtitle>$2</ce:subtitle>")
        WholeData = Regex.Replace(WholeData, "<ce:subtitle>([^<]*?)</ce:subtitle></ce:title>", "</ce:title><ce:subtitle>$1</ce:subtitle>")
        WholeData = Regex.Replace(WholeData, "</ce:section-title>(\s|\.|:)?<ce:hsp sp=""([^<]*?)""/>(\s)?<ce:para", "</ce:section-title><ce:para")
        WholeData = Regex.Replace(WholeData, "<ce:bib-reference id=""([^<>]*?)""><ce:hsp sp=""([^<>]*?)""/><ce:label>", "<ce:bib-reference id=""$1""><ce:label>")
        WholeData = Regex.Replace(WholeData, "</sb:([^<>]*?)>(\s)?<ce:hsp sp=""([^<>]*?)""/>(;|:)?(\s)?</sb:([^<>]*?)>", "</sb:$1></sb:$6>")
        WholeData = Regex.Replace(WholeData, "</ce:see>;(\s)?<ce:see-also", "</ce:see><ce:see-also")
        WholeData = Regex.Replace(WholeData, "(</ce:see-also>|</ce:see>)(;|\.)\s*<ce:reader-see>", "$1<ce:reader-see>")
        WholeData = Regex.Replace(WholeData, "</ce:intra-ref>. <ce:reader-see>", "</ce:intra-ref><ce:reader-see>")
        WholeData = Regex.Replace(WholeData, "</ce:author><ce:hsp sp=""([^<>]*?)""/>&bull;<ce:hsp sp=""([^<>]*?)""/><ce:author", "</ce:author><ce:author")
        WholeData = Regex.Replace(WholeData, "</ce:author>, AND <ce:author", "</ce:author><ce:author")
        WholeData = Regex.Replace(WholeData, "</ce:caption><ce:hsp sp=""([^<>]*?)""/><ce:textbox-body>", "</ce:caption><ce:textbox-body>")

        WholeData = Regex.Replace(WholeData, "</ce:label><ce:hsp sp=""([^<>]*?)""/><ce:caption", "</ce:label><ce:caption")
        WholeData = Regex.Replace(WholeData, "</ce:author><ce:hsp sp=""([^<>]*?)""/><ce:collaboration", "</ce:author><ce:collaboration")
        WholeData = Regex.Replace(WholeData, "</ce:collaboration><ce:hsp sp=""([^<>]*?)""/><ce:author", "</ce:collaboration><ce:author")
        WholeData = Regex.Replace(WholeData, "</ce:see>\.(\s*)?<ce:see-also", "</ce:see><ce:see-also")
        WholeData = Regex.Replace(WholeData, "</ce:see> <ce:reader-see>", "</ce:see><ce:reader-see>")
        WholeData = Regex.Replace(WholeData, "</ce:reader-see>; (<ce:see-also|<ce:reader-see)", "</ce:reader-see>$1")
        WholeData = Regex.Replace(WholeData, "</ce:intra-ref>. <ce:see-also", "</ce:intra-ref><ce:see-also")
        WholeData = Regex.Replace(WholeData, "</ce:index-heading> <ce:intra-ref", "</ce:index-heading><ce:intra-ref")
        WholeData = Regex.Replace(WholeData, "</ce:index-heading>\. <ce:reader-see>", "</ce:index-heading><ce:reader-see>")
        'WholeData = Regex.Replace(WholeData, "</ce:reader-see>; <ce:see-also", "</ce:reader-see><ce:see-also")
        WholeData = Regex.Replace(WholeData, "</ce:intra-ref> <ce:reader-see>", "</ce:intra-ref><ce:reader-see>")
        WholeData = Regex.Replace(WholeData, "</ce:index-heading>.See also <ce:see-also", "</ce:index-heading><ce:see-also")
        WholeData = Regex.Replace(WholeData, "</ce:title>: <ce:subtitle>", "</ce:title><ce:subtitle>")
        WholeData = Regex.Replace(WholeData, "</ce:see>; <ce:italic>", "</ce:see><ce:italic>")
        WholeData = Regex.Replace(WholeData, "</ce:italic> <ce:reader-see>", "</ce:italic><ce:reader-see>")
        WholeData = Regex.Replace(WholeData, "</ce:inline-figure>(\s*)", "</ce:inline-figure>")
        'P.Parthiban added on 30th JULY 2014;
        WholeData = Regex.Replace(WholeData, "<ce:inline-figure([^<>]*?)? baseline=""([^<>]*?)""([^<>]*?)?>", "<ce:inline-figure$1$3>")
        'WholeData = Regex.Replace(WholeData, "<ce:label>n</ce:label>", "<ce:label>&squf;</ce:label>")
        WholeData = Regex.Replace(WholeData, "c&newcaron;", "&ccaron;")
        WholeData = Regex.Replace(WholeData, "C&newcaron;", "&Ccaron;")
        WholeData = Regex.Replace(WholeData, "(\s)</ce:section-title>", "</ce:section-title>")
        'P.Parthiban commented for Bug:4314; on 2nd Dec 2013;
        'WholeData = Regex.Replace(WholeData, "\s</", "</")
        WholeData = Regex.Replace(WholeData, "</sb:([^<>]*?)>(.[^<>]*?)</sb:([^<>]*?)>", "</sb:$1></sb:$3>")
        WholeData = Regex.Replace(WholeData, "<entry >", "<entry>")
        WholeData = Regex.Replace(WholeData, "<ce:index-flag-see>(\s)", "<ce:index-flag-see>")
        WholeData = Regex.Replace(WholeData, "</ce:label>(<ce:hsp sp=""([^<>]*?)""/>)*(\&bull\;)*(<ce:hsp sp=""([^<>]*?)""/>)*<(ce:textbox-head|ce:source)>", "</ce:label><$6>")
        'P.Parthiban added on 3rd Dec 2013;
        WholeData = Regex.Replace(WholeData, "</(ce:source)>(<ce:hsp sp=""([^<>]*?)""/>)+<ce:textbox-head>", "</$1><ce:textbox-head>")
        'P.Parthiban added on 11th APR 2014;
        WholeData = Regex.Replace(WholeData, "</(ce:title)>(<ce:hsp sp=""([^<>]*?)""/>)+</ce:textbox-head>", "</$1></ce:textbox-head>")
        WholeData = Regex.Replace(WholeData, "(</ce:see-also>|</ce:see>);\s+<ce:see-also", "$1<ce:see-also")
        'WholeData = Regex.Replace(WholeData, "(in)(\&nbsp\;)(site|vivo|vitro)", "$1 $3", RegexOptions.IgnoreCase)
        'WholeData = Regex.Replace(WholeData, "ex(\&nbsp\;)vivo", "ex vivo", RegexOptions.IgnoreCase)
        'WholeData = Regex.Replace(WholeData, "(\&nbsp\;)(day|days|month|months|week|weeks|year|years)", " $2", RegexOptions.IgnoreCase)
        'WholeData = Regex.Replace(WholeData, "(\&nbsp\;)(jour|jours|mois|semaine|semaines|ann\&eacute\;e|ann\&eacute\;es)", " $2", RegexOptions.IgnoreCase)

        ''..Redmine ID# 177211; Jayasangari.R added on Aug-28-2023;
        WholeData = Regex.Replace(WholeData, "<ce:display></ce:display>", "", RegexOptions.IgnoreCase)
    End Sub
#End Region

#Region "Function PostProcessByUncommenting(ByRef XmlFileData As String) As String"
    ''' <summary>
    ''' Post process references by uncommenting.
    ''' </summary>
    ''' <param name="XmlFileData">Whole xml content</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ''' <History>
    ''' 2009.04.11; Created for performing post process by uncommenting; V.Sundaravelu
    ''' </History>
    Function PostProcessByUncommenting(ByRef XmlFileData As String) As String
        If Regex.IsMatch(XmlFileData, "<!--(<ce:bibliography([^<]*?)>(.*?)</ce:bibliography>)-->", RegexOptions.IgnoreCase) Then
            Dim Bibliography As String = Regex.Match(XmlFileData, "<!--(<ce:bibliography([^<]*?)>(.*?)</ce:bibliography>)-->").Groups(1).Value
            XmlFileData = Regex.Replace(XmlFileData, "<!--<ce:bibliography(.*?)</ce:bibliography>-->", "")
            Bibliography = Regex.Replace(Bibliography, "<spi_comment>(.*?)</spi_comment>", "<!--$1-->")
            XmlFileData = Regex.Replace(XmlFileData, "<ce:bibliography(.*?)</ce:bibliography>", Bibliography, RegexOptions.Singleline)
        End If

        If Regex.IsMatch(XmlFileData, "<!--(<ce:further-reading(.*?)</ce:further-reading>)-->", RegexOptions.IgnoreCase) Then
            Dim FurtherBibliography As String = Regex.Match(XmlFileData, "<!--(<ce:further-reading(.*?)</ce:further-reading>)-->", RegexOptions.Singleline).Groups(1).Value
            XmlFileData = Regex.Replace(XmlFileData, "<!--<ce:further-reading(.*?)</ce:further-reading>-->", "")
            FurtherBibliography = Regex.Replace(FurtherBibliography, "<spi_comment>(.*?)</spi_comment>", "<!--$1-->")
            XmlFileData = Regex.Replace(XmlFileData, "<ce:further-reading(.*?)</ce:further-reading>", FurtherBibliography)
        End If
        Return XmlFileData

    End Function
#End Region

#Region "Shared Sub PostProcessReferences(ByRef WholeData As String)"
    ''' <summary>
    ''' performs post process references.
    ''' </summary>
    ''' <param name="WholeData"></param>
    ''' <remarks></remarks>
    ''' <History>
    ''' 2008-12-19;Function added 
    ''' </History>
    ''' 
    Shared Sub PostProcessReferences(ByRef WholeData As String)
        Dim BibContent As String
        For Each BibMatch As Match In Regex.Matches(WholeData, "<ce:bib-reference(.*?)</ce:bib-reference>")
            BibContent = BibMatch.Groups(1).Value
            PostProcessCommon(BibContent)
            Select Case (ReferenceStyle)
                Case "Numbered"
                    PostProcessNumbered(BibContent)
                Case "Harvard"
                    PostProcessHarvard(BibContent)
                Case "Vancouver"
                    PostProcessVancouver(BibContent)
                Case "VancouverNameDate"
                    PostProcessVancouverNameDate(BibContent)
                Case "Emb Vancouver"
                    PostProcessEvancouver(BibContent)
                Case "APA"
                    PostProcessAPA(BibContent)
                Case "AMA"
                    PostProcessAMA(BibContent)
                Case "ACSNumbered"
                    PostProcessACSNumbered(BibContent)
                Case "Saunders"
                    PostProcessSaunders(BibContent)
                Case "SaundersNumbered"
                    PostProcessSaundersNumbered(BibContent)
                Case "Mosby"
                    PostProcessMosby(BibContent)
                Case "NIH"
                    PostProcessVancouver(BibContent)
            End Select
            WholeData = Replace(WholeData, "<ce:bib-reference" & BibMatch.Groups(1).Value & "</ce:bib-reference>", "<ce:bib-reference1" & BibContent & "</ce:bib-reference1>")
        Next
        WholeData = Regex.Replace(WholeData, "<(/)?ce:bib-reference1", "<$1ce:bib-reference")
    End Sub
#End Region

#Region "Shared Sub PostProcessCommon(ByRef BibContent As String)"
    ''' <summary>
    ''' Post Process Common for all styles.
    ''' </summary>
    ''' <param name="BibContent"></param>
    ''' <remarks></remarks>
    Shared Sub PostProcessCommon(ByRef BibContent As String)
        Dim Author As String
        Dim Editor As String
        Dim ACount As Integer = 0
        Dim ECount As Integer = 0
        Dim AuthMatch, EditMatch As MatchCollection
        'P.Parthiban updated for Bug: 6504;on 3rd DEC 2015;
        ''changed the regex expression so that it matches punctuations which are inserted between both ce: and sb: tags.
        'BibContent = Regex.Replace(BibContent, ">(\,|\;|\.|\:|\s|\(|\))\s?<(/)?(sb:|ce:)", "><$2$3")
        While Regex.IsMatch(BibContent, "(<(/)?sb:([^<>/]*?)>)(\,|\;|\.|\:|\s|\(|\))\s?(<(/)?(sb:|ce:))")
            BibContent = Regex.Replace(BibContent, "(<(/)?sb:([^<>/]*?)>)(\,|\;|\.|\:|\s|\(|\))\s?(<(/)?(sb:|ce:))", "$1$5")
        End While
        While Regex.IsMatch(BibContent, "(<(/)?ce:([^<>/]*?)>)(\,|\;|\.|\:|\s|\(|\))\s?(<(/)?(sb:))")
            BibContent = Regex.Replace(BibContent, "(<(/)?ce:([^<>/]*?)>)(\,|\;|\.|\:|\s|\(|\))\s?(<(/)?(sb:))", "$1$5")
        End While
        While Regex.IsMatch(BibContent, "(</ce:([^<>]*?)>)(\,|\;|\.|\:|\s|\(|\))\s?(<ce:)")
            BibContent = Regex.Replace(BibContent, "(</ce:([^<>]*?)>)(\,|\;|\.|\:|\s|\(|\))\s?(<ce:)", "$1$4")
        End While
        'reorder elements within sb:authors and remove punctuation within sb:author
        AuthMatch = Regex.Matches(BibContent, "<sb:authors>(.*?)</sb:authors>")
        If AuthMatch.Count > 0 Then
            For ACount = 0 To AuthMatch.Count - 1
                Author = AuthMatch.Item(ACount).Groups(1).ToString
                Author = Regex.Replace(Author, "<ce:suffix>(.[^<>]*?)</ce:suffix>(.[^<>]*?)?<ce:given-name>(.[^<>]*?)</ce:given-name></sb:author>", "<ce:given-name>$3</ce:given-name><ce:suffix>$1</ce:suffix></sb:author>")
                Author = Regex.Replace(Author, "<ce:suffix>(.[^<>]*?)</ce:suffix>(.[^<>]*?)?<ce:surname>(.[^<>]*?)</ce:surname></sb:author>", "<ce:surname>$3</ce:surname><ce:suffix>$1</ce:suffix></sb:author>")
                Author = Regex.Replace(Author, "<ce:surname>(.[^<>]*?)</ce:surname>(.[^<>]*?)?<ce:given-name>(.[^<>]*?)</ce:given-name>", "<ce:given-name>$3</ce:given-name><ce:surname>$1</ce:surname>")
                Author = Regex.Replace(Author, "<ce:given-name>(.[^<>]*?)</ce:given-name>(.[^<>]*?)?<ce:surname>(.[^<>]*?)</ce:surname>", "<ce:given-name>$1</ce:given-name><ce:surname>$3</ce:surname>")
                If Regex.IsMatch(Author, "et al") Then
                    Author = Regex.Replace(Author, "</sb:author>(.[^<>]*?)?et al(.[^<>]*?)?$", "</sb:author><sb:et-al/>")
                End If
                If Regex.IsMatch(Author, "et(\&(.[^<>]*?)\;)al") Then
                    Author = Regex.Replace(Author, "</sb:author>(.[^<>]*?)?et((\&(.[^<>]*?)\;)| )al(.[^<>]*?)?$", "</sb:author><sb:et-al/>")
                End If
                If Regex.IsMatch(ReferenceStyle, "harvard|vancouver|APA|AMA|NIH", RegexOptions.IgnoreCase) Then
                    Author = Regex.Replace(Author, "<ce:given-name>(.[^<>]*?)</ce:given-name>(.[^<>]*?)?<ce:surname>(.[^<>]*?)</ce:surname>", "<ce:surname>$3</ce:surname><ce:given-name>$1</ce:given-name>")
                End If
                Author = Regex.Replace(Author, "</sb:author>(.*?)<", "</sb:author><")
                BibContent = Replace(BibContent, "<sb:authors>" & AuthMatch.Item(ACount).Groups(1).ToString & "</sb:authors>", "<sb:authors>" & Author & "</sb:authors>")
            Next
        End If

        'reorder elements within sb:editors and remove punctuation within sb:author
        EditMatch = Regex.Matches(BibContent, "<sb:editors>(.*?)</sb:editors>")
        If EditMatch.Count > 0 Then
            For ECount = 0 To EditMatch.Count - 1
                Editor = EditMatch.Item(ECount).Groups(1).ToString
                Editor = Regex.Replace(Editor, "<ce:suffix>(.[^<>]*?)</ce:suffix>(.[^<>]*?)?<ce:given-name>(.[^<>]*?)</ce:given-name></sb:author>", "<ce:given-name>$3</ce:given-name><ce:suffix>$1</ce:suffix></sb:author>")
                Editor = Regex.Replace(Editor, "<ce:suffix>(.[^<>]*?)</ce:suffix>(.[^<>]*?)?<ce:surname>(.[^<>]*?)</ce:surname></sb:author>", "<ce:surname>$3</ce:surname><ce:suffix>$1</ce:suffix></sb:author>")
                Editor = Regex.Replace(Editor, "<ce:surname>(.[^<>]*?)</ce:surname>(.[^<>]*?)?<ce:given-name>(.[^<>]*?)</ce:given-name>", "<ce:given-name>$3</ce:given-name><ce:surname>$1</ce:surname>")
                Editor = Regex.Replace(Editor, "<ce:given-name>(.[^<>]*?)</ce:given-name>(.[^<>]*?)?<ce:surname>(.[^<>]*?)</ce:surname>", "<ce:given-name>$1</ce:given-name><ce:surname>$3</ce:surname>")
                If Regex.IsMatch(Editor, "et al") Then
                    Editor = Regex.Replace(Editor, "</sb:editor>(.[^<>]*?)?et al(.[^<>]*?)?$", "</sb:editor><sb:et-al/>")
                End If
                If Regex.IsMatch(Editor, "et(\&(.[^<>]*?)\;)al") Then
                    Editor = Regex.Replace(Editor, "</sb:editor>(.[^<>]*?)?et((\&(.[^<>]*?)\;)| )al(.[^<>]*?)?$", "</sb:editor><sb:et-al/>")
                End If
                If Regex.IsMatch(ReferenceStyle, "harvard|vancouver|APA|AMA|NIH", RegexOptions.IgnoreCase) Then
                    Editor = Regex.Replace(Editor, "<ce:given-name>(.[^<>]*?)</ce:given-name>(.[^<>]*?)?<ce:surname>(.[^<>]*?)</ce:surname>", "<ce:surname>$3</ce:surname><ce:given-name>$1</ce:given-name>")
                End If
                Editor = Regex.Replace(Editor, "</sb:editor>(.*?)<", "</sb:editor><")
                BibContent = Replace(BibContent, "<sb:editors>" & EditMatch.Item(ECount).Groups(1).ToString & "</sb:editors>", "<sb:editors>" & Editor & "</sb:editors>")
            Next
        End If

        'removing punctuation that might have been inserted within the contents of ce:given-name
        BibContent = Regex.Replace(BibContent, "<ce:given-name>([A-Z]) ([A-Z]) ([A-Z])</ce:given-name>", "<ce:given-name>$1$2$3</ce:given-name>")
        BibContent = Regex.Replace(BibContent, "<ce:given-name>([A-Z]) ([A-Z])</ce:given-name>", "<ce:given-name>$1$2</ce:given-name>")
        BibContent = Regex.Replace(BibContent, "<ce:given-name>([A-Z])\. ([A-Z])\. ([A-Z])\.</ce:given-name>", "<ce:given-name>$1.$2.$3.</ce:given-name>")
        BibContent = Regex.Replace(BibContent, "<ce:given-name>([A-Z])\. ([A-Z])\.</ce:given-name>", "<ce:given-name>$1.$2.</ce:given-name>")
        'remove punctuation at end of editors
        BibContent = Regex.Replace(BibContent, "</sb:editor>(.[^<>]*?)</sb:editors>", "</sb:editor></sb:editors>")
        'remove brackets for issue-nr (added for numbered style) - note brackets should have been added inside the contents of sb:issue-nr
        'BibContent = Regex.Replace(BibContent, "<sb:issue-nr>\((.[^<>]*?)\)</sb:issue-nr>", "<sb:issue-nr>$1</sb:issue-nr>")

        BibContent = Regex.Replace(BibContent, "<sb:issue-nr>\((.[^<>]*?)?(<ce:hsp sp=""([^<>]*?)""/>)?(.[^<>]*?)?\)</sb:issue-nr>", "<sb:issue-nr>$1$4</sb:issue-nr>")

        'reorder: publisher name should come before location (vancouver, embellished vancouver, APA, AMA)
        BibContent = Regex.Replace(BibContent, "<sb:publisher><sb:location>(.*?)</sb:location><sb:name>(.*?)</sb:name></sb:publisher>", "<sb:publisher><sb:name>$2</sb:name><sb:location>$1</sb:location></sb:publisher>")
        'remove "&ndash;" between first-page and last-page
        BibContent = Regex.Replace(BibContent, "</sb:first-page>(&ndash;|\–|\-)<sb:last-page>", "</sb:first-page><sb:last-page>")
        'oder change: volume-nr after /sb:series should brought back inside /sb:series - risky?
        'commented the line for Bug:1262;
        'BibContent = Regex.Replace(BibContent, "</sb:series>(.*?)<sb:volume-nr(.*?)</sb:volume-nr>", "<sb:volume-nr$2</sb:volume-nr></sb:series>$1")
        '2009.05.28; Added; Removes enclosure between volume number; V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "<sb:series>(.*?)<sb:volume-nr(.*?)>\((.*?)\)</sb:volume-nr>(.*?)</sb:series>", "<sb:series>$1<sb:volume-nr$2>$3</sb:volume-nr>$4</sb:series>")
        'comment added below for bug:7038; 21.03.2016;
        BibContent = Regex.Replace(BibContent, "<sb:isbn>(.[^<>]*?)</sb:isbn><sb:date>(.[^<>]*?)</sb:date>", "<sb:date>$2</sb:date><sb:isbn>$1</sb:isbn>")

        'same as below with 2 sb:dates after publisher - note order of execution is important - first match with 2 dates
        BibContent = Regex.Replace(BibContent, "<sb:publisher>(.*?)</sb:publisher><sb:date>(.*?)</sb:date>(.[^<>]*)<sb:date>(.*?)</sb:date>", "<sb:date>$2</sb:date><sb:date>$4</sb:date><sb:publisher>$1</sb:publisher>")
        BibContent = Regex.Replace(BibContent, "<sb:publisher>(.*?)</sb:publisher><sb:date>(.*?)</sb:date>", "<sb:date>$2</sb:date><sb:publisher>$1</sb:publisher>")
        'removes In keyword
        'BibContent = Regex.Replace(BibContent, "<sb:edited-book>in[:\s,.]? ", "<sb:edited-book>", RegexOptions.IgnoreCase)
        'Pattern changed for bug:2397; By P.Parthiban on 19th April 2012;
        'BibContent = Regex.Replace(BibContent, "<sb:edited-book>in(\s*)?(,|\.|:|;)(\s*)? ", "<sb:edited-book>", RegexOptions.IgnoreCase)
        BibContent = Regex.Replace(BibContent, "<sb:edited-book>in(\s*)?(,|\.|:|;)?(\s*)? ", "<sb:edited-book>", RegexOptions.IgnoreCase)
        BibContent = Regex.Replace(BibContent, "<sb:editors>in(\s)?([:,.])?(\s)?", "<sb:editors>", RegexOptions.IgnoreCase)
        'P.Parthiban added on 20th MAY 2014;
        BibContent = Regex.Replace(BibContent, "</sb:editors>\sin\s<", "</sb:editors><", RegexOptions.IgnoreCase)
        'removes punchuation after end of pages
        BibContent = Regex.Replace(BibContent, "doi:<ce:doi>", "<ce:doi>")
        BibContent = Regex.Replace(BibContent, "</sb:pages>([^<]*?)<ce:doi>", "</sb:pages><ce:doi>", RegexOptions.IgnoreCase)
        BibContent = Regex.Replace(BibContent, "<sb:pages>pp.[\s]?", "<sb:pages>", RegexOptions.IgnoreCase)
        BibContent = Regex.Replace(BibContent, "<sb:pages>[^<]*?<sb:first-page>", "<sb:pages><sb:first-page>")
        'removes enclosures in date.
        'BibContent = Regex.Replace(BibContent, "<sb:date>\((.[^<>]*?)\)</sb:date>", "<sb:date>$1</sb:date>")
        'removes enclosures in date.
        BibContent = Regex.Replace(BibContent, "<sb:date>\((.[^<>]*?)\)</sb:date>", "<sb:date>$1</sb:date>")
        'harvard style: remove suffix in date
        'P.Parthiban updated for Bug:2883;on 5th Sep 2012;
        'BibContent = Regex.Replace(BibContent, "<sb:date>(.[^<>]*?)[A-z]</sb:date>", "<sb:date>$1</sb:date>")
        BibContent = Regex.Replace(BibContent, "<sb:date>((.[^<>]*?)(\d))[A-z]</sb:date>", "<sb:date>$1</sb:date>")
        '2009.05.28; Added; Removes hifen between dates, V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "</sb:date>(.[^<>]*)<sb:date>", "</sb:date><sb:date>")
        '2009.04.07; Removes square brackets enclosed for <sb:translated-title>(Vancouver Style); V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "([\[\(]?<sb:translated-title>(.*?)</sb:translated-title>[\]\)]?)", "<sb:translated-title>$2</sb:translated-title>")
        '2009.04.07; Added to remove square brackets enclosed for sb:maintitle(Vancouver Style); V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "\[<sb:maintitle>(.*?)</sb:maintitle>\]", "<sb:maintitle>$1</sb:maintitle>")
        BibContent = Regex.Replace(BibContent, "<sb:date>\((.[^<>]*?)\)</sb:date>", "<sb:date>$1</sb:date>")
        '2009.05.30; Added to remove round brackets enclosed for sb:date(APA Style); V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "<sb:date>\((.[^<>]*?)</sb:date>", "<sb:date>$1</sb:date>")
        BibContent = Regex.Replace(BibContent, "<sb:date>(.[^<>]*?)\)</sb:date>", "<sb:date>$1</sb:date>")
        '2009.05.30; Added to remove round brackets enclosed for sb:edition(APA Style); V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "<sb:edition>\((.*?)\)</sb:edition>", "<sb:edition>$1</sb:edition>")
        BibContent = Regex.Replace(BibContent, "<sb:edition>(\s*)?(.*?)(\s*)?</sb:edition>", "<sb:edition>$2</sb:edition>")
    End Sub
#End Region

#Region "Shared Sub PostProcessNumbered(ByRef BibContent As String)"
    ''' <summary>
    ''' Post Process Numbered Style.
    ''' </summary>
    ''' <param name="BibContent"></param>
    ''' <remarks></remarks>
    Shared Sub PostProcessNumbered(ByRef BibContent As String)
        'numbered style: order change, preprocess moves date after publisher for book & edited-book - this is safe because journals and e-host do not have publisher.
        BibContent = Regex.Replace(BibContent, "<sb:publisher>(.*?)</sb:publisher><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date>", "<sb:date>$2</sb:date><sb:date>$3</sb:date><sb:publisher>$1</sb:publisher>")
        BibContent = Regex.Replace(BibContent, "<sb:publisher>(.*?)</sb:publisher><sb:date>(.*?)</sb:date>", "<sb:date>$2</sb:date><sb:publisher>$1</sb:publisher>")
    End Sub
#End Region

#Region "Shared Sub PostProcessHarvard(ByRef BibContent As String)"
    ''' <summary>
    ''' Post Process Harvard
    ''' </summary>
    ''' <param name="BibContent"></param>
    ''' <remarks></remarks>
    Shared Sub PostProcessHarvard(ByRef BibContent As String)
        'P.Parthiban updated on 19th APR 2014; handling multiple sb:ref in bibref
        ''2009.04.06; Modified to revert the reorder of date for harvard style; K.Hemachandiran
        'BibContent = Regex.Replace(BibContent, "<sb:contribution><sb:authors>(.*?)</sb:authors><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date>(.*?)</sb:contribution>(.*?)?<sb:host>(.*?)(((<sb:publisher>.*?</sb:publisher>)?(<sb:isbn>.*?</sb:isbn>)?(</sb:book>|</sb:edited-book>))|</sb:issue>|</sb:e-host>)(.*?)</sb:host>", "<sb:contribution><sb:authors>$1</sb:authors>$4</sb:contribution>$5<sb:host>$6<sb:date>$2</sb:date><sb:date>$3</sb:date>$7$12</sb:host>")
        ''2009.04.06; Modified to revert the reorder of date for harvard style; K.Hemachandiran
        'BibContent = Regex.Replace(BibContent, "<sb:contribution><sb:authors>(.*?)</sb:authors><sb:date>(.*?)</sb:date>(.*?)</sb:contribution>(.*?)?<sb:host>(.*?)(((<sb:publisher>.*?</sb:publisher>)?(<sb:isbn>.*?</sb:isbn>)?(</sb:book>|</sb:edited-book>))|</sb:issue>|</sb:e-host>)(.*?)</sb:host>", "<sb:contribution><sb:authors>$1</sb:authors>$3</sb:contribution>$4<sb:host>$5<sb:date>$2</sb:date>$6$11</sb:host>")
        'BibContent = Regex.Replace(BibContent, "<sb:reference([^<]*?)><sb:host>(.*?)<sb:editors>(.*?)</sb:editors><sb:date>(.*?)</sb:date>(.*?)<sb:date>(.*?)</sb:date>(.*?)(((<sb:publisher>.*?</sb:publisher>)?(<sb:isbn>.*?</sb:isbn>)?(</sb:book>|</sb:edited-book>))|</sb:issue>|</sb:e-host>)(.*?)</sb:host>", "<sb:reference$1><sb:host>$2<sb:editors>$3</sb:editors>$7<sb:date>$4</sb:date><sb:date>$6</sb:date>$8$13</sb:host>")
        'BibContent = Regex.Replace(BibContent, "<sb:reference([^<]*?)><sb:host>(.*?)<sb:editors>(.*?)</sb:editors><sb:date>(.*?)</sb:date>(.*?)(((<sb:publisher>.*?</sb:publisher>)?(<sb:isbn>.*?</sb:isbn>)?(</sb:book>|</sb:edited-book>))|</sb:issue>|</sb:e-host>)(.*?)</sb:host>", "<sb:reference$1><sb:host>$2<sb:editors>$3</sb:editors>$5<sb:date>$4</sb:date>$6$11</sb:host>")
        'BibContent = Regex.Replace(BibContent, "<sb:host>(.*?)</sb:host>(.*?)<sb:host>(.*?)(((<sb:publisher>.*?</sb:publisher>)?(<sb:isbn>.*?</sb:isbn>)?(</sb:book>|</sb:edited-book>))|</sb:issue>|</sb:e-host>)<sb:pages>(.*?)</sb:pages>([^<]*?)<sb:date>([^<]*?)</sb:date></sb:host>", "<sb:host>$1</sb:host>$2<sb:host>$3<sb:date>$11</sb:date>$4<sb:pages>$9</sb:pages></sb:host>")

        '---
        'R.Sugavaneshwaran added on 24th january 2018:STAMS-1345
        'BibContent = Regex.Replace(BibContent, "<sb:contribution><sb:authors>(.*?)</sb:authors><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date>(.*?)</sb:contribution>(.*?)?<sb:host>(.*?)(((<sb:publisher>.*?</sb:publisher>)?(<sb:isbn>.*?</sb:isbn>)?(</sb:book>|</sb:edited-book>))|</sb:issue>|</sb:e-host>)(.*?)</sb:host>", "<sb:contribution><sb:authors>$1</sb:authors>$4</sb:contribution>$5<sb:host>$6<sb:date>$2</sb:date><sb:date>$3</sb:date>$7$12</sb:host>")
        'BibContent = Regex.Replace(BibContent, "<sb:contribution><sb:authors>(.*?)</sb:authors><sb:date>(.*?)</sb:date>(.*?)</sb:contribution>(.*?)?<sb:host>(.*?)(((<sb:publisher>.*?</sb:publisher>)?(<sb:isbn>.*?</sb:isbn>)?(</sb:book>|</sb:edited-book>))|</sb:issue>|</sb:e-host>)(.*?)</sb:host>", "<sb:contribution><sb:authors>$1</sb:authors>$3</sb:contribution>$4<sb:host>$5<sb:date>$2</sb:date>$6$11</sb:host>")
        BibContent = Regex.Replace(BibContent, "<sb:contribution([^<>]*?)?><sb:authors>(.*?)</sb:authors><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date>(.*?)</sb:contribution>(.*?)?<sb:host>(.*?)(((<sb:publisher>.*?</sb:publisher>)?(<sb:isbn>.*?</sb:isbn>)?(</sb:book>|</sb:edited-book>))|</sb:issue>|</sb:e-host>)(.*?)</sb:host>", "<sb:contribution$1><sb:authors>$2</sb:authors>$5</sb:contribution>$6<sb:host>$7<sb:date>$3</sb:date><sb:date>$4</sb:date>$8$13</sb:host>")
        BibContent = Regex.Replace(BibContent, "<sb:contribution([^<>]*?)?><sb:authors>(.*?)</sb:authors><sb:date>(.*?)</sb:date>(.*?)</sb:contribution>(.*?)?<sb:host>(.*?)(((<sb:publisher>.*?</sb:publisher>)?(<sb:isbn>.*?</sb:isbn>)?(</sb:book>|</sb:edited-book>))|</sb:issue>|</sb:e-host>)(.*?)</sb:host>", "<sb:contribution$1><sb:authors>$2</sb:authors>$4</sb:contribution>$5<sb:host>$6<sb:date>$3</sb:date>$7$12</sb:host>")
        '---


        '---
        'R.Sugavaneshwaran added on 10th may 2018:STAMS-2175
        BibContent = Regex.Replace(BibContent, "</ce:inter-ref>. <sb:date-accessed([^<>]*?)?>", "</ce:inter-ref><sb:date-accessed$1>", RegexOptions.Singleline)
        '---

        Dim tempdata As String = Regex.Replace(BibContent, vbCrLf, "")
        tempdata = Regex.Replace(tempdata, "</sb:reference><sb:reference", "</sb:reference>" & vbCrLf & "<sb:reference")
        Dim strs = tempdata.Split(vbCrLf)
        For Each ref As String In strs
            Dim repref As String = ref
            repref = Regex.Replace(repref, "<sb:reference([^<]*?)><sb:host>(.*?)<sb:editors>(.*?)</sb:editors><sb:date>(.*?)</sb:date>(.*?)<sb:date>(.*?)</sb:date>(.*?)(((<sb:publisher>.*?</sb:publisher>)?(<sb:isbn>.*?</sb:isbn>)?(</sb:book>|</sb:edited-book>))|</sb:issue>|</sb:e-host>)(.*?)</sb:host>", "<sb:reference$1><sb:host>$2<sb:editors>$3</sb:editors>$7<sb:date>$4</sb:date><sb:date>$6</sb:date>$8$13</sb:host>")
            repref = Regex.Replace(repref, "<sb:reference([^<]*?)><sb:host>(.*?)<sb:editors>(.*?)</sb:editors><sb:date>(.*?)</sb:date>(.*?)(((<sb:publisher>.*?</sb:publisher>)?(<sb:isbn>.*?</sb:isbn>)?(</sb:book>|</sb:edited-book>))|</sb:issue>|</sb:e-host>)(.*?)</sb:host>", "<sb:reference$1><sb:host>$2<sb:editors>$3</sb:editors>$5<sb:date>$4</sb:date>$6$11</sb:host>")
            BibContent = Replace(BibContent, ref, repref)
        Next
        BibContent = Regex.Replace(BibContent, "<sb:host>(.*?)</sb:host>(.*?)<sb:host>(.*?)(((<sb:publisher>.*?</sb:publisher>)?(<sb:isbn>.*?</sb:isbn>)?(</sb:book>|</sb:edited-book>))|</sb:issue>|</sb:e-host>)<sb:pages>(.*?)</sb:pages>([^<]*?)<sb:date>([^<]*?)</sb:date></sb:host>", "<sb:host>$1</sb:host>$2<sb:host>$3<sb:date>$11</sb:date>$4<sb:pages>$9</sb:pages></sb:host>")
    End Sub
#End Region

#Region "Shared Sub PostProcessVancouver(ByRef BibContent As String)"
    ''' <summary>
    ''' Post Process Vancouver Style
    ''' </summary>
    ''' <param name="BibContent"></param>
    ''' <remarks></remarks>
    Shared Sub PostProcessVancouver(ByRef BibContent As String)

        '2009.01.04; p.gupta; added;
        'p.gupta; move host/book/date after host/book/publisher - same for edited-book
        'Ref = Regex.Replace(Ref, "<sb:host>(.*?)<sb:date>(.*?)</sb:date><sb:publisher>(.*?)</sb:publisher>(.*?)</sb:host>", "<sb:host>$1<sb:publisher>$3</sb:publisher><sb:date>$2</sb:date>$4</sb:host>")
        BibContent = Regex.Replace(BibContent, "<sb:host>(.*?)<sb:publisher>(.*?)</sb:publisher><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date>(.*?)</sb:host>", "<sb:host>$1<sb:date>$3</sb:date><sb:date>$4</sb:date><sb:publisher>$2</sb:publisher>$5</sb:host>")
        BibContent = Regex.Replace(BibContent, "<sb:host>(.*?)<sb:publisher>(.*?)</sb:publisher><sb:date>(.*?)</sb:date>(.*?)</sb:host>", "<sb:host>$1<sb:date>$3</sb:date><sb:publisher>$2</sb:publisher>$4</sb:host>")

        'p.gupta; insert &ndash; between juxtaposed dates
        'Ref = Regex.Replace(Ref, "<sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date>", "<sb:date>$1</sb:date>&ndash;<sb:date>$2</sb:date>")

        'p.gupta; move issue/date into issue/series/ after issue/series/title 
        'Ref = Regex.Replace(Ref, "<sb:host><sb:issue>(.*?)<sb:series><sb:title>(.*?)</sb:title>(.*?)</sb:series>(.*?)<sb:date>(.*?)</sb:date></sb:issue>(.*?)</sb:host>", "<sb:host><sb:issue>$1<sb:series><sb:title>$2</sb:title><sb:date>$5</sb:date>$3</sb:series>$4</sb:issue>$6</sb:host>")
        '2009.04.07; ce:title has attribute, modified regex to match the attributes; V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "<sb:host><sb:issue>(.*?)<sb:series><sb:title([^<]*?)>(.*?)</sb:title><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date>(.*?)</sb:series>(.*?)</sb:issue>(.*?)</sb:host>", "<sb:host><sb:issue>$1<sb:series><sb:title$2>$3</sb:title>$6</sb:series>$6<sb:date>$4</sb:date><sb:date>$5</sb:date></sb:issue>$8</sb:host>")

        BibContent = Regex.Replace(BibContent, "<sb:host><sb:issue>(.*?)<sb:series><sb:title([^<]*?)>(.*?)</sb:title><sb:date>(.*?)</sb:date>(.*?)</sb:series>(.*?)</sb:issue>(.*?)</sb:host>", "<sb:host><sb:issue>$1<sb:series><sb:title$2>$3</sb:title>$5</sb:series>$6<sb:date>$4</sb:date></sb:issue>$7</sb:host>")

        'exception case where the references is not under the above said patterns
        'P.Parthiban & Hemachandiran added for Bug:2732; 7th Aug 2012;
        BibContent = Regex.Replace(BibContent, "<sb:host><sb:issue>(.*?)<sb:series><sb:title([^<]*?)>(.*?)</sb:title>(.*?)</sb:series>(.*?)</sb:issue>(.*?)<sb:date>(.*?)</sb:date></sb:host>", "<sb:host><sb:issue>$1<sb:series><sb:title$2>$3</sb:title>$4</sb:series>$5<sb:date>$7</sb:date></sb:issue>$6</sb:host>")

        ExpandLastPage(BibContent)
        ExpandDate(BibContent)

        'END VANCOUVER STYLE
    End Sub
#End Region

#Region "Shared Sub PostProcessVancouverNameDate(ByRef BibContent As String)"
    ''' <summary>
    ''' Post Process Vancouver Style
    ''' </summary>
    ''' <param name="BibContent"></param>
    ''' <remarks></remarks>
    Shared Sub PostProcessVancouverNameDate(ByRef BibContent As String)
        'VANCOUVER STYLE: p.gupta;
        '2009.01.04; p.gupta; added;
        'p.gupta; move host/book/date after host/book/publisher - same for edited-book
        'Ref = Regex.Replace(Ref, "<sb:host>(.*?)<sb:date>(.*?)</sb:date><sb:publisher>(.*?)</sb:publisher>(.*?)</sb:host>", "<sb:host>$1<sb:publisher>$3</sb:publisher><sb:date>$2</sb:date>$4</sb:host>")
        BibContent = Regex.Replace(BibContent, "<sb:host>(.*?)<sb:publisher>(.*?)</sb:publisher><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date>(.*?)</sb:host>", "<sb:host>$1<sb:date>$3</sb:date><sb:date>$4</sb:date><sb:publisher>$2</sb:publisher>$5</sb:host>")
        BibContent = Regex.Replace(BibContent, "<sb:host>(.*?)<sb:publisher>(.*?)</sb:publisher><sb:date>(.*?)</sb:date>(.*?)</sb:host>", "<sb:host>$1<sb:date>$3</sb:date><sb:publisher>$2</sb:publisher>$4</sb:host>")

        'p.gupta; insert &ndash; between juxtaposed dates
        'Ref = Regex.Replace(Ref, "<sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date>", "<sb:date>$1</sb:date>&ndash;<sb:date>$2</sb:date>")

        'p.gupta; move issue/date into issue/series/ after issue/series/title 
        'Ref = Regex.Replace(Ref, "<sb:host><sb:issue>(.*?)<sb:series><sb:title>(.*?)</sb:title>(.*?)</sb:series>(.*?)<sb:date>(.*?)</sb:date></sb:issue>(.*?)</sb:host>", "<sb:host><sb:issue>$1<sb:series><sb:title>$2</sb:title><sb:date>$5</sb:date>$3</sb:series>$4</sb:issue>$6</sb:host>")
        '2009.04.07; ce:title has attribute, modified regex to match the attributes; V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "<sb:host><sb:issue>(.*?)<sb:series><sb:title([^<]*?)>(.*?)</sb:title><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date>(.*?)</sb:series>(.*?)</sb:issue>(.*?)</sb:host>", "<sb:host><sb:issue>$1<sb:series><sb:title$2>$3</sb:title>$6</sb:series>$6<sb:date>$4</sb:date><sb:date>$5</sb:date></sb:issue>$8</sb:host>")
        BibContent = Regex.Replace(BibContent, "<sb:host><sb:issue>(.*?)<sb:series><sb:title([^<]*?)>(.*?)</sb:title><sb:date>(.*?)</sb:date>(.*?)</sb:series>(.*?)</sb:issue>(.*?)</sb:host>", "<sb:host><sb:issue>$1<sb:series><sb:title$2>$3</sb:title>$5</sb:series>$6<sb:date>$4</sb:date></sb:issue>$7</sb:host>")

        ExpandLastPage(BibContent)
        ExpandDate(BibContent)

        'END VANCOUVER STYLE
    End Sub
#End Region

#Region "Shared Sub PostProcessEvancouver(ByRef BibContent As String)"
    ''' <summary>
    ''' Post Process Evancouver Style.
    ''' </summary>
    ''' <param name="BibContent"></param>
    ''' <remarks></remarks>
    Shared Sub PostProcessEvancouver(ByRef BibContent As String)
        'EMBELLISHED VANCOUVER STYLE: k.hemachandiran;
        '2009.01.22; hemachandiran; added; 

        BibContent = Regex.Replace(BibContent, "<sb:host><sb:issue>(.*?)<sb:series><sb:title(.*?)>(.*?)</sb:title><sb:date>(.*?)</sb:date>(.*?)</sb:series>(.*?)</sb:issue>(.*?)</sb:host>", "<sb:host><sb:issue>$1<sb:series><sb:title$2>$3</sb:title>$5</sb:series>$6<sb:date>$4</sb:date></sb:issue>$7</sb:host>")

        ExpandLastPage(BibContent)
        ExpandDate(BibContent)
        'END EMBELLISHED VANCOUVER STYLE
    End Sub
#End Region

#Region "Shared Sub PostProcessAMA(ByRef BibContent As String)"
    ''' <summary>
    ''' Post Process AMA Style.
    ''' </summary>
    ''' <param name="BibContent"></param>
    ''' <remarks></remarks>
    Shared Sub PostProcessAMA(ByRef BibContent As String)
        'AMA STYLE: k.hemachandiran;
        '2009.01.27; hemachandiran; added;
        BibContent = Regex.Replace(BibContent, "<sb:contribution>(.*?)</sb:contribution><sb:host><sb:edited-book><sb:editors>(.*?)</sb:editors><sb:title(.*?)>(.*?)</sb:title>(.*?)<sb:pages>(.*?)</sb:pages><sb:book-series>(.*?)</sb:maintitle></sb:title>(.*?)</sb:book-series></sb:edited-book></sb:host>", "<sb:contribution>$1</sb:contribution><sb:host><sb:edited-book><sb:editors>$2</sb:editors><sb:title$3>$4</sb:title><sb:book-series>$7</sb:maintitle></sb:title>$8</sb:book-series>$5</sb:edited-book><sb:pages>$6</sb:pages></sb:host>")
        BibContent = Regex.Replace(BibContent, "<sb:host><sb:issue>(.*?)<sb:series><sb:title([^<]*?)>(.*?)</sb:title><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date>(.*?)</sb:series>(.*?)</sb:issue>(.*?)</sb:host>", "<sb:host><sb:issue>$1<sb:series><sb:title$2>$3</sb:title>$6</sb:series>$7<sb:date>$4</sb:date><sb:date>$5</sb:date></sb:issue>$8</sb:host>")
        BibContent = Regex.Replace(BibContent, "<sb:host><sb:issue>(.*?)<sb:series><sb:title([^<]*?)>(.*?)</sb:title><sb:date>(.*?)</sb:date>(.*?)</sb:series>(.*?)</sb:issue>(.*?)</sb:host>", "<sb:host><sb:issue>$1<sb:series><sb:title$2>$3</sb:title>$5</sb:series>$6<sb:date>$4</sb:date></sb:issue>$7</sb:host>")
    End Sub
#End Region

#Region "Shared Sub PostProcessACSNumbered(ByRef BibContent As String)"
    ''' <summary>
    ''' Post Process ACS Style.
    ''' </summary>
    ''' <param name="BibContent"></param>
    ''' <remarks></remarks>
    Shared Sub PostProcessACSNumbered(ByRef BibContent As String)
        'ACS STYLE: k.hemachandiran;
        '2012.11.15; hemachandiran; added;

        BibContent = Regex.Replace(BibContent, "<sb:host><sb:issue>(.*?)<sb:series><sb:title([^<]*?)>(.*?)</sb:title><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date>(.*?)</sb:series>(.*?)</sb:issue>(.*?)</sb:host>", "<sb:host><sb:issue>$1<sb:series><sb:title$2>$3</sb:title>$6</sb:series>$7<sb:date>$4</sb:date><sb:date>$5</sb:date></sb:issue>$8</sb:host>")

        BibContent = Regex.Replace(BibContent, "<sb:host><sb:issue>(.*?)<sb:series><sb:title([^<]*?)>(.*?)</sb:title><sb:date>(.*?)</sb:date>(.*?)</sb:series>(.*?)</sb:issue>(.*?)</sb:host>", "<sb:host><sb:issue>$1<sb:series><sb:title$2>$3</sb:title>$5</sb:series>$6<sb:date>$4</sb:date></sb:issue>$7</sb:host>")

        BibContent = Regex.Replace(BibContent, "<sb:contribution>(.*?)</sb:contribution><sb:host><sb:edited-book><sb:title([^<]*?)>(.*?)</sb:title><sb:editors>(.*?)</sb:editors>(.*?)<sb:book-series>(.*?)?<sb:series>(.*?)</sb:maintitle></sb:title><sb:volume-nr([^<]*?)>(.*?)</sb:volume-nr></sb:series><sb:date>(.*?)</sb:date><sb:publisher>(.*?)</sb:publisher></sb:book-series><sb:pages>(.*?)</sb:pages></sb:edited-book></sb:host>", "<sb:contribution>$1</sb:contribution><sb:host><sb:edited-book><sb:editors>$4</sb:editors><sb:title$2>$3</sb:title>$5<sb:book-series>$6<sb:series>$7</sb:maintitle></sb:title><sb:volume-nr$8>$9</sb:volume-nr></sb:series></sb:book-series><sb:date>$10</sb:date><sb:publisher>$11</sb:publisher></sb:edited-book><sb:pages>$12</sb:pages></sb:host>")

        BibContent = Regex.Replace(BibContent, "<sb:contribution>(.*?)</sb:contribution>(.*?)<sb:host><sb:edited-book><sb:title([^<]*?)>(.*?)</sb:title><sb:editors>(.*?)</sb:editors>(<sb:conference>(.*?)</sb:conference>)?<sb:date>(.*?)</sb:date><sb:publisher>(.*?)</sb:publisher></sb:edited-book><sb:pages>(.*?)</sb:pages></sb:host>", "<sb:contribution>$1</sb:contribution>$2<sb:host><sb:edited-book><sb:editors>$5</sb:editors><sb:title$3>$4</sb:title>$6<sb:date>$8</sb:date><sb:publisher>$9</sb:publisher></sb:edited-book><sb:pages>$10</sb:pages></sb:host>")
        'R.Sugavaneshwaran added on 27th january 2018:STAMS-1320
        BibContent = Regex.Replace(BibContent, "<sb:contribution([^<]*?)?>(.*?)</sb:contribution><sb:host><sb:edited-book>(.*?)?<sb:title([^<]*?)?>(.*?)</sb:title><sb:editors>(.*?)</sb:editors><sb:book-series>(.*?)?(<sb:date>(.*?)</sb:date>)?(<sb:publisher>(.*?)</sb:publisher>)?</sb:book-series>(<sb:pages>(.*?)</sb:pages>)?</sb:edited-book></sb:host>", "<sb:contribution$1>$2</sb:contribution><sb:host><sb:edited-book>$3<sb:editors>$6</sb:editors><sb:title$4>$5</sb:title><sb:book-series>$7</sb:book-series>$8$10</sb:edited-book>$12</sb:host>", RegexOptions.Singleline Or RegexOptions.IgnoreCase)
        '---

    End Sub
#End Region

#Region "Shared Sub PostProcessAPA(ByRef BibContent As String)"
    ''' <summary>
    ''' Post Process APA Style.
    ''' </summary>
    ''' <param name="BibContent"></param>
    ''' <remarks></remarks>
    Shared Sub PostProcessAPA(ByRef BibContent As String)
        '2009.04.06; Modified to revert the reorder of date for harvard style; K.Hemachandiran
        BibContent = Regex.Replace(BibContent, "<sb:contribution><sb:authors>(.*?)</sb:authors><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date>(.*?)</sb:contribution>(.*?)?<sb:host>(.*?)(((<sb:publisher>.*?</sb:publisher>)?(<sb:isbn>.*?</sb:isbn>)?(</sb:book>|</sb:edited-book>))|</sb:issue>|</sb:e-host>)(.*?)</sb:host>", "<sb:contribution><sb:authors>$1</sb:authors>$4</sb:contribution>$5<sb:host>$6<sb:date>$2</sb:date><sb:date>$3</sb:date>$7$12</sb:host>")
        '2009.04.06; Modified to revert the reorder of date for harvard style; K.Hemachandiran
        BibContent = Regex.Replace(BibContent, "<sb:contribution><sb:authors>(.*?)</sb:authors><sb:date>(.*?)</sb:date>(.*?)</sb:contribution>(.*?)?<sb:host>(.*?)(((<sb:publisher>.*?</sb:publisher>)?(<sb:isbn>.*?</sb:isbn>)?(</sb:book>|</sb:edited-book>))|</sb:issue>|</sb:e-host>)(.*?)</sb:host>", "<sb:contribution><sb:authors>$1</sb:authors>$3</sb:contribution>$4<sb:host>$5<sb:date>$2</sb:date>$6$11</sb:host>")
        'moves date before end of issue, since date is move after editors in preprocess; V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "<sb:reference([^<]*?)><sb:host>(.*?)<sb:editors>(.*?)</sb:editors><sb:date>(.*?)</sb:date>(.*?)<sb:date>(.*?)</sb:date>(.*?)(((<sb:publisher>.*?</sb:publisher>)?(<sb:isbn>.*?</sb:isbn>)?(</sb:book>|</sb:edited-book>))|</sb:issue>|</sb:e-host>)(.*?)</sb:host>", "<sb:reference$1><sb:host>$2<sb:editors>$3</sb:editors>$7<sb:date>$4</sb:date><sb:date>$6</sb:date>$8$13</sb:host>")
        BibContent = Regex.Replace(BibContent, "<sb:reference([^<]*?)><sb:host>(.*?)<sb:editors>(.*?)</sb:editors><sb:date>(.*?)</sb:date>(.*?)(((<sb:publisher>.*?</sb:publisher>)?(<sb:isbn>.*?</sb:isbn>)?(</sb:book>|</sb:edited-book>))|</sb:issue>|</sb:e-host>)(.*?)</sb:host>", "<sb:reference$1><sb:host>$2<sb:editors>$3</sb:editors>$5<sb:date>$4</sb:date>$6$11</sb:host>")

        'changes the surname, givenname to givenname, surnames of editors that comes inside the host which follows contribution; V.Sundaravelu
        If Regex.IsMatch(BibContent, "<sb:contribution>(.*?)</sb:contribution>(.*?)<sb:host>(.*?)<sb:editors>(.*?)</sb:editors>(.*?)</sb:host>", RegexOptions.IgnoreCase) Then
            Dim HostEditors As String = Regex.Match(BibContent, "<sb:host>(.*?)</sb:host>").Groups(1).Value
            Dim TempStr As String = HostEditors
            For Each MatchEditor As Match In Regex.Matches(HostEditors, "<sb:editor>(.*?)</sb:editor>", RegexOptions.IgnoreCase)
                HostEditors = Regex.Replace(HostEditors, "<ce:surname>(.[^<]*?)</ce:surname><ce:given-name>(.[^<]*?)</ce:given-name>", "<ce:given-name>$2</ce:given-name><ce:surname>$1</ce:surname>")
            Next
            '2009.08.14; p.gupta; escape match expression - because it's supposed to be a string literal
            BibContent = Regex.Replace(BibContent, Regex.Escape(TempStr), HostEditors)
            'BibContent = Regex.Replace(BibContent, "<sb:contribution>(.*?)</sb:contribution>(.*?)<sb:host><sb:edited-book><sb:editors>(.*?)</sb:editors>(.*?)<sb:editors>(.*?)</sb:editors>(.*?)<sb:book-series>(.*?)</sb:book-series><sb:title>(.*?)</sb:title>(.*?)</sb:edited-book>(.*?)</sb:host>", "<sb:contribution>$1</sb:contribution>$2<sb:host><sb:edited-book><sb:editors>$5</sb:editors>$6<sb:title>$8</sb:title><sb:book-series><sb:editors>$3</sb:editors>$7</sb:book-series>$9</sb:edited-book>$10</sb:host>")
            'added by k.hemachandiran; bug id:5079; 9.6.2015;
            BibContent = Regex.Replace(BibContent, "<sb:contribution>(.*?)</sb:contribution>(.*?)<sb:host><sb:edited-book><sb:editors>(.*?)</sb:editors>(.*?)(<sb:editors>(.*?)</sb:editors>)?(.*?)<sb:book-series>(.*?)</sb:book-series><sb:title>(.*?)</sb:title>(.*?)</sb:edited-book>(.*?)</sb:host>", "<sb:contribution>$1</sb:contribution>$2<sb:host><sb:edited-book><sb:editors>$3</sb:editors>$7<sb:title>$9</sb:title><sb:book-series>$5$8</sb:book-series>$10</sb:edited-book>$11</sb:host>")
        End If
        'BibContent = Regex.Replace(BibContent, "<sb:contribution>(.*?)</sb:contribution>(.*?)<sb:host>(.*?)<sb:pages>(.*?)</sb:pages>(.*?)</sb:edited-book></sb:host>", "<sb:contribution>$1</sb:contribution>$2<sb:host>$3$5</sb:edited-book><sb:pages>$4</sb:pages></sb:host>")
        'added by k.hemachandiran & k.shanmuga sundaram; bug id:7873; 15-07-2016;
        '-----
        BibContent = Regex.Replace(BibContent, "(<sb:contribution>(.*?)</sb:contribution>)?(.*?)<sb:host>(.*?)<sb:pages>(.*?)</sb:pages>(.*?)</sb:edited-book></sb:host>", "$1$3<sb:host>$4$6</sb:edited-book><sb:pages>$5</sb:pages></sb:host>")
        BibContent = Regex.Replace(BibContent, "(<sb:edition>(.[^<>]*?)</sb:edition>)(<sb:title><sb:maintitle>(.[^<>]*?)</sb:maintitle></sb:title>)", "$3$1")
        '-----
        BibContent = Regex.Replace(BibContent, "</sb:issue>(.*?)</sb:pages><sb:date>(.*?)</sb:date>", "<sb:date>$2</sb:date></sb:issue>$1</sb:pages>")
        '--1052
        BibContent = Regex.Replace(BibContent, "<sb:edited-book>(.*?)<sb:book-series>(.*?)</sb:book-series><sb:title([^<]*?)>(.*?)</sb:title>(.*?)</sb:edited-book>", "<sb:edited-book>$1<sb:title$3>$4</sb:title><sb:book-series>$2</sb:book-series>$5</sb:edited-book>")
        '---
        'Sasikala.K added for STAMS-7096 on 17-03-2020;
        '----
        BibContent = Regex.Replace(BibContent, "(<sb:contribution>(.*?)</sb:contribution>(.*?)<sb:host><sb:edited-book><sb:editors>(.*?)</sb:editors><sb:title([^<]*?)>(.*?)</sb:title>)(<sb:pages>(.*?)</sb:pages>)(<sb:date>(.*?)</sb:date><sb:publisher>(.*?)</sb:publisher>)</sb:edited-book>", "$1$9</sb:edited-book>$7")
        '----
        'added by k.hemachandiran; bug id:5079; 9.6.2015;
        BibContent = Regex.Replace(BibContent, "</sb:series></sb:book-series><sb:volume-nr(.*?)>(.*?)</sb:volume-nr>", "<sb:volume-nr$1>$2</sb:volume-nr></sb:series></sb:book-series>")
    End Sub
#End Region

#Region "Shared Sub PostProcessSaunders(ByRef BibContent As String)"
    ''' <summary>
    ''' Post Process Saunders Style
    ''' </summary>
    ''' <param name="BibContent"></param>
    ''' <remarks></remarks>
    Shared Sub PostProcessSaunders(ByRef BibContent As String)

        '(edited-book)moves date before publisher, since date is moved after publisher location in preprocess; V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "<sb:edited-book>(.*?)<sb:publisher><sb:location>([^<]*?)</sb:location><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date><sb:name>([^<]*?)</sb:name>([^<]*?)</sb:publisher>(.*?)</sb:edited-book>", "<sb:edited-book>$1<sb:date>$3</sb:date><sb:date>$4</sb:date><sb:publisher><sb:name>$5</sb:name><sb:location>$2</sb:location>$6</sb:publisher>$7</sb:edited-book>")
        BibContent = Regex.Replace(BibContent, "<sb:edited-book>(.*?)<sb:publisher><sb:location>([^<]*?)</sb:location><sb:date>(.*?)</sb:date><sb:name>([^<]*?)</sb:name>([^<]*?)</sb:publisher>(.*?)</sb:edited-book>", "<sb:edited-book>$1<sb:date>$3</sb:date><sb:publisher><sb:name>$4</sb:name><sb:location>$2</sb:location>$5</sb:publisher>$6</sb:edited-book>")

        '(book)moves date before publisher, since date is moved after publisher location in preprocess; V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "<sb:book([^<]*?)?>(.*?)<sb:publisher><sb:location>([^<]*?)</sb:location><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date><sb:name>([^<]*?)</sb:name>([^<]*?)</sb:publisher>(.*?)</sb:book>", "<sb:book$1>$2<sb:date>$4</sb:date><sb:date>$5</sb:date><sb:publisher><sb:name>$6</sb:name><sb:location>$3</sb:location>$7</sb:publisher>$8</sb:book>")

        BibContent = Regex.Replace(BibContent, "<sb:book([^<]*?)?>(.*?)<sb:publisher>(<sb:location>([^<]*?)</sb:location>)?<sb:date>(.*?)</sb:date><sb:name>([^<]*?)</sb:name>([^<]*?)</sb:publisher>(.*?)</sb:book>", "<sb:book$1>$2<sb:date>$5</sb:date><sb:publisher><sb:name>$6</sb:name>$3$7</sb:publisher>$8</sb:book>")

        '(book)moves date before publisher and swaps name and location of the publisher,
        ' since date is moved after publisher location and publisher name and location is swaped in preprocess; V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "<sb:book([^<]*?)?>(.*?)<sb:publisher><sb:location>([^<]*?)</sb:location><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date><sb:name>([^<]*?)</sb:name>([^<]*?)</sb:publisher>(.*?)</sb:book>", "<sb:book$1>$2<sb:date>$4</sb:date><sb:date>$5</sb:date><sb:publisher><sb:name>$6</sb:name><sb:location>$3</sb:location>$7</sb:publisher>$8</sb:book>")
        BibContent = Regex.Replace(BibContent, "<sb:book([^<]*?)?>(.*?)<sb:publisher><sb:location>([^<]*?)</sb:location><sb:date>(.*?)</sb:date><sb:name>([^<]*?)</sb:name>([^<]*?)</sb:publisher>(.*?)</sb:book>", "<sb:book$1>$2<sb:date>$4</sb:date><sb:publisher><sb:name>$5</sb:name><sb:location>$3</sb:location>$6</sb:publisher>$7</sb:book>")

        'moves date before end of issue, since date is moved at end of pages in preprocess; V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "<sb:host>(.*?)</sb:issue>(.*?)</sb:pages><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date>(.*?)</sb:host>", "<sb:host>$1<sb:date>$3</sb:date><sb:date>$4</sb:date></sb:issue>$2</sb:pages>$5</sb:host>")
        'BibContent = Regex.Replace(BibContent, "<sb:host>(.*?)</sb:issue>(.*?)</sb:pages><sb:date>(.*?)</sb:date>(.*?)</sb:host>", "<sb:host>$1<sb:date>$3</sb:date></sb:issue>$2</sb:pages>$4</sb:host>")
        BibContent = Regex.Replace(BibContent, "<sb:host>(.*?)</sb:issue>(.*?)(</sb:pages>)?<sb:date>(.*?)</sb:date>(.*?)</sb:host>", "<sb:host>$1<sb:date>$4</sb:date></sb:issue>$2$3$5</sb:host>")

    End Sub
#End Region

#Region "Shared Sub PostProcessSaundersNumbered(ByRef BibContent As String)"
    ''' <summary>
    ''' Post Process Saunders Numbered Style
    ''' </summary>
    ''' <param name="BibContent"></param>
    ''' <remarks></remarks>
    Shared Sub PostProcessSaundersNumbered(ByRef BibContent As String)

        '(edited-book)moves date before publisher, since date is moved after publisher location in preprocess; V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "<sb:edited-book>(.*?)<sb:publisher><sb:location>([^<]*?)</sb:location><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date><sb:name>([^<]*?)</sb:name>([^<]*?)</sb:publisher>(.*?)</sb:edited-book>", "<sb:edited-book>$1<sb:date>$3</sb:date><sb:date>$4</sb:date><sb:publisher><sb:name>$5</sb:name><sb:location>$2</sb:location>$6</sb:publisher>$7</sb:edited-book>")
        BibContent = Regex.Replace(BibContent, "<sb:edited-book>(.*?)<sb:publisher><sb:location>([^<]*?)</sb:location><sb:date>(.*?)</sb:date><sb:name>([^<]*?)</sb:name>([^<]*?)</sb:publisher>(.*?)</sb:edited-book>", "<sb:edited-book>$1<sb:date>$3</sb:date><sb:publisher><sb:name>$4</sb:name><sb:location>$2</sb:location>$5</sb:publisher>$6</sb:edited-book>")

        '(book)moves date before publisher, since date is moved after publisher location in preprocess; V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "<sb:book([^<]*?)?>(.*?)<sb:publisher><sb:location>([^<]*?)</sb:location><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date><sb:name>([^<]*?)</sb:name>([^<]*?)</sb:publisher>(.*?)</sb:book>", "<sb:book$1>$2<sb:date>$4</sb:date><sb:date>$5</sb:date><sb:publisher><sb:name>$6</sb:name><sb:location>$3</sb:location>$7</sb:publisher>$8</sb:book>")

        BibContent = Regex.Replace(BibContent, "<sb:book([^<]*?)?>(.*?)<sb:publisher>(<sb:location>([^<]*?)</sb:location>)?<sb:date>(.*?)</sb:date><sb:name>([^<]*?)</sb:name>([^<]*?)</sb:publisher>(.*?)</sb:book>", "<sb:book$1>$2<sb:date>$5</sb:date><sb:publisher><sb:name>$6</sb:name>$3$7</sb:publisher>$8</sb:book>")

        '(book)moves date before publisher and swaps name and location of the publisher,
        ' since date is moved after publisher location and publisher name and location is swaped in preprocess; V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "<sb:book([^<]*?)?>(.*?)<sb:publisher><sb:location>([^<]*?)</sb:location><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date><sb:name>([^<]*?)</sb:name>([^<]*?)</sb:publisher>(.*?)</sb:book>", "<sb:book$1>$2<sb:date>$4</sb:date><sb:date>$5</sb:date><sb:publisher><sb:name>$6</sb:name><sb:location>$3</sb:location>$7</sb:publisher>$8</sb:book>")
        BibContent = Regex.Replace(BibContent, "<sb:book([^<]*?)?>(.*?)<sb:publisher><sb:location>([^<]*?)</sb:location><sb:date>(.*?)</sb:date><sb:name>([^<]*?)</sb:name>([^<]*?)</sb:publisher>(.*?)</sb:book>", "<sb:book$1>$2<sb:date>$4</sb:date><sb:publisher><sb:name>$5</sb:name><sb:location>$3</sb:location>$6</sb:publisher>$7</sb:book>")

        'moves date before end of issue, since date is moved at end of pages in preprocess; V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "<sb:host>(.*?)</sb:issue>(.*?)</sb:pages><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date>(.*?)</sb:host>", "<sb:host>$1<sb:date>$3</sb:date><sb:date>$4</sb:date></sb:issue>$2</sb:pages>$5</sb:host>")
        'BibContent = Regex.Replace(BibContent, "<sb:host>(.*?)</sb:issue>(.*?)</sb:pages><sb:date>(.*?)</sb:date>(.*?)</sb:host>", "<sb:host>$1<sb:date>$3</sb:date></sb:issue>$2</sb:pages>$4</sb:host>")
        BibContent = Regex.Replace(BibContent, "<sb:host>(.*?)</sb:issue>(.*?)(</sb:pages>)?<sb:date>(.*?)</sb:date>(.*?)</sb:host>", "<sb:host>$1<sb:date>$4</sb:date></sb:issue>$2$3$5</sb:host>")

    End Sub
#End Region

#Region "Shared Sub PostProcessMosby(ByRef BibContent As String)"
    ''' <summary>
    ''' Post Process Mosby Style
    ''' </summary>
    ''' <param name="BibContent"></param>
    ''' <remarks></remarks>
    Shared Sub PostProcessMosby(ByRef BibContent As String)

        '(edited-book)moves date before publisher, since date is moved after publisher location in preprocess; V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "<sb:edited-book>(.*?)<sb:publisher><sb:location>([^<]*?)</sb:location><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date><sb:name>([^<]*?)</sb:name>([^<]*?)</sb:publisher>(.*?)</sb:edited-book>", "<sb:edited-book>$1<sb:date>$3</sb:date><sb:date>$4</sb:date><sb:publisher><sb:name>$5</sb:name><sb:location>$2</sb:location>$6</sb:publisher>$7</sb:edited-book>")
        BibContent = Regex.Replace(BibContent, "<sb:edited-book>(.*?)<sb:publisher><sb:location>([^<]*?)</sb:location><sb:date>(.*?)</sb:date><sb:name>([^<]*?)</sb:name>([^<]*?)</sb:publisher>(.*?)</sb:edited-book>", "<sb:edited-book>$1<sb:date>$3</sb:date><sb:publisher><sb:name>$4</sb:name><sb:location>$2</sb:location>$5</sb:publisher>$6</sb:edited-book>")

        '(book)moves date before publisher, since date is moved after publisher location in preprocess; V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "<sb:book([^<]*?)?>(.*?)<sb:publisher><sb:location>([^<]*?)</sb:location><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date><sb:name>([^<]*?)</sb:name>([^<]*?)</sb:publisher>(.*?)</sb:book>", "<sb:book$1>$2<sb:date>$4</sb:date><sb:date>$5</sb:date><sb:publisher><sb:name>$6</sb:name><sb:location>$3</sb:location>$7</sb:publisher>$8</sb:book>")
        BibContent = Regex.Replace(BibContent, "<sb:book([^<]*?)?>(.*?)<sb:publisher><sb:location>([^<]*?)</sb:location><sb:date>(.*?)</sb:date><sb:name>([^<]*?)</sb:name>([^<]*?)</sb:publisher>(.*?)</sb:book>", "<sb:book$1>$2<sb:date>$4</sb:date><sb:publisher><sb:name>$5</sb:name><sb:location>$3</sb:location>$6</sb:publisher>$7</sb:book>")

        '(book)moves date before publisher and swaps name and location of the publisher,
        ' since date is moved after publisher location and publisher name and location is swaped in preprocess; V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "<sb:book([^<]*?)?>(.*?)<sb:publisher><sb:location>([^<]*?)</sb:location><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date><sb:name>([^<]*?)</sb:name>([^<]*?)</sb:publisher>(.*?)</sb:book>", "<sb:book$1>$2<sb:date>$4</sb:date><sb:date>$5</sb:date><sb:publisher><sb:name>$6</sb:name><sb:location>$3</sb:location>$7</sb:publisher>$8</sb:book>")
        BibContent = Regex.Replace(BibContent, "<sb:book([^<]*?)?>(.*?)<sb:publisher><sb:location>([^<]*?)</sb:location><sb:date>(.*?)</sb:date><sb:name>([^<]*?)</sb:name>([^<]*?)</sb:publisher>(.*?)</sb:book>", "<sb:book$1>$2<sb:date>$4</sb:date><sb:publisher><sb:name>$5</sb:name><sb:location>$3</sb:location>$6</sb:publisher>$7</sb:book>")

        'moves date before end of issue, since date is moved at end of pages in preprocess; V.Sundaravelu
        BibContent = Regex.Replace(BibContent, "<sb:host>(.*?)</sb:issue>(.*?)</sb:pages><sb:date>(.*?)</sb:date><sb:date>(.*?)</sb:date>(.*?)</sb:host>", "<sb:host>$1<sb:date>$3</sb:date><sb:date>$4</sb:date></sb:issue>$2</sb:pages>$5</sb:host>")
        'BibContent = Regex.Replace(BibContent, "<sb:host>(.*?)</sb:issue>(.*?)</sb:pages><sb:date>(.*?)</sb:date>(.*?)</sb:host>", "<sb:host>$1<sb:date>$3</sb:date></sb:issue>$2</sb:pages>$4</sb:host>")
        BibContent = Regex.Replace(BibContent, "<sb:host>(.*?)</sb:issue>(.*?)(</sb:pages>)?<sb:date>(.*?)</sb:date>(.*?)</sb:host>", "<sb:host>$1<sb:date>$4</sb:date></sb:issue>$2$3$5</sb:host>")

    End Sub
#End Region

#Region "Shared Sub PostProcessFootNote(ByRef WholeData As String)"
    ''' <summary>
    ''' Processes the FootNote that is changed during preprocess
    ''' </summary>
    ''' <param name="WholeData"></param>
    ''' <remarks></remarks>
    ''' <Histroy>
    ''' 20090610; [bug 5]; Created to process the FootNote that is changed during preprocess; V.Sundaravelu
    ''' 20091112; [bug 1289]; Dummy tag created during preprocess (SPiFootNoteRef) is reverted back. Footnotes at the end of chapter is moved back to the respective places during post process; R.Thinagaran
    ''' </Histroy>
    Shared Sub PostProcessFootNote(ByRef WholeData As String)
        ''STAMS:6987;Balamurugan.K Added on 23-Apr-2020;FootnoteAutomation;
        ''STAMS:9112;Balamurugan.K Commented on 12-Mar-2021;
        'Dim footNoteMatches As MatchCollection = Regex.Matches(WholeData, "<ce:cross-ref refid=""([^<>]*?)""( [^<>]*?)?></ce:cross-ref>(.*?)<SPiFootNoteRef", RegexOptions.Singleline Or RegexOptions.Multiline)
        'If footNoteMatches.Count > 0 Then
        '    For i As Integer = 0 To footNoteMatches.Count - 1
        '        Dim tempData As String = footNoteMatches.Item(i).Value
        '        Dim replaceData As String = footNoteMatches.Item(i).Value
        '        If Regex.IsMatch(tempData, "<ce:cross-ref refid=""([^<>]*?)""></ce:cross-ref>(.*?)<SPiFootNoteRef") AndAlso Regex.IsMatch(tempData, "<\?(\s*)?SPicesup-", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline) Then
        '            Dim CrossRefMatch As String = Regex.Match(tempData, "<ce:cross-ref refid=""([^<>]*?)""( [^<>]*?)?></ce:cross-ref>(.*?)<SPiFootNoteRef", RegexOptions.Singleline).Groups(3).Value
        '            CrossRefMatch = Regex.Replace(CrossRefMatch, "<\?(\s*)?SPicesup-", "<ce:sup>")
        '            CrossRefMatch = Regex.Replace(CrossRefMatch, "-SPicesup(\s*)?\?>", "</ce:sup>")
        '            replaceData = Regex.Replace(replaceData, "<ce:cross-ref refid=""([^<>]*?)""( [^<>]*?)?></ce:cross-ref>(.*?)<SPiFootNoteRef", "<ce:cross-ref refid=""$1""$2>" & CrossRefMatch & "</ce:cross-ref><SPiFootNoteRef", RegexOptions.IgnoreCase Or RegexOptions.Singleline Or RegexOptions.Multiline)
        '        End If
        '        WholeData = Regex.Replace(WholeData, Regex.Escape(tempData), replaceData)
        '    Next
        'End If
        ''STAMS:9112;Balamurugan.K Updated on 12-Mar-2021;
        Dim footNoteMatches As MatchCollection = Regex.Matches(WholeData, "<ce:cross-ref( [^<>]*?)?refid=""([^<>]*?)""( [^<>]*?)?></ce:cross-ref>(.*?)<SPiFootNoteRef", RegexOptions.Singleline Or RegexOptions.Multiline)
        If footNoteMatches.Count > 0 Then
            For i As Integer = 0 To footNoteMatches.Count - 1
                Dim tempData As String = footNoteMatches.Item(i).Value
                Dim replaceData As String = footNoteMatches.Item(i).Value
                If Regex.IsMatch(tempData, "<ce:cross-ref( [^<>]*?)?refid=""([^<>]*?)""></ce:cross-ref>(.*?)<SPiFootNoteRef") AndAlso Regex.IsMatch(tempData, "<\?(\s*)?SPicesup-", RegexOptions.IgnoreCase Or RegexOptions.Multiline Or RegexOptions.Singleline) Then
                    Dim CrossRefMatch As String = Regex.Match(tempData, "<ce:cross-ref( [^<>]*?)?refid=""([^<>]*?)""( [^<>]*?)?></ce:cross-ref>(.*?)<SPiFootNoteRef", RegexOptions.Singleline).Groups(4).Value
                    CrossRefMatch = Regex.Replace(CrossRefMatch, "<\?(\s*)?SPicesup-", "<ce:sup>")
                    CrossRefMatch = Regex.Replace(CrossRefMatch, "-SPicesup(\s*)?\?>", "</ce:sup>")
                    replaceData = Regex.Replace(replaceData, "<ce:cross-ref( [^<>]*?)?refid=""([^<>]*?)""( [^<>]*?)?></ce:cross-ref>(.*?)<SPiFootNoteRef", "<ce:cross-ref$1refid=""$2""$3>" & CrossRefMatch & "</ce:cross-ref><SPiFootNoteRef", RegexOptions.IgnoreCase Or RegexOptions.Singleline Or RegexOptions.Multiline)
                End If
                WholeData = Regex.Replace(WholeData, Regex.Escape(tempData), replaceData)
            Next
        End If
        ''----
        If Regex.IsMatch(WholeData, "<SPiFootNoteRef id=""([^<>]*?)"">", RegexOptions.IgnoreCase) Then
            WholeData = Regex.Replace(WholeData, "<SPiFootNoteRef id=""([^<>]*?)""></SPiFootNoteRef>", "<SPiFootNoteRef id=""$1""/>")
            'Bug id 6061 E.Raja modified on 26-Sep-2015; 
            ' Dim FootNoteData As String = Regex.Match(WholeData, "<SPiFootNote>(.*?)</SPiFootNote>", RegexOptions.IgnoreCase).Value
            Dim FootNoteData As String = Regex.Match(WholeData, "<SPiFootNote>(.*?)</SPiFootNote>", RegexOptions.IgnoreCase Or RegexOptions.Singleline).Value
            If FootNoteData <> "" Then
                Dim FootNoteList As Hashtable = New Hashtable()
                'Bug id 6061 E.Raja modified on 26-Sep-2015;
                ' For Each FootNote As Match In Regex.Matches(FootNoteData, "<ce:footnote id=""([^<>]*?)"">(.*?)</ce:footnote>", RegexOptions.IgnoreCase)
                For Each FootNote As Match In Regex.Matches(FootNoteData, "<ce:footnote id=""([^<>]*?)"">(.*?)</ce:footnote>", RegexOptions.IgnoreCase Or RegexOptions.Singleline)
                    FootNoteList.Add(FootNote.Groups(1).Value, FootNote.Value)
                Next
                WholeData = Regex.Replace(WholeData, "<SPiFootNote>(.*?)</SPiFootNote>", "", RegexOptions.IgnoreCase Or RegexOptions.Singleline)
                Dim CrossRefList As Hashtable = New Hashtable()

                For Each CrossRef As Match In Regex.Matches(WholeData, "<SPiFootNoteRef id=""([^<>]*?)""/>", RegexOptions.IgnoreCase Or RegexOptions.Singleline)
                    If Not CrossRefList.ContainsKey(CrossRef.Groups(1).Value) Then
                        CrossRefList.Add(CrossRef.Groups(1).Value, CrossRef.Value)
                    End If
                Next
                For Each FootNoteID As String In FootNoteList.Keys
                    If CrossRefList.ContainsKey(FootNoteID) Then
                        'Bug id 6061 E.Raja modified on 26-Sep-2015;
                        'WholeData = Regex.Replace(WholeData, Regex.Escape(CrossRefList.Item(FootNoteID)), FootNoteList.Item(FootNoteID))
                        '---
                        'R.Sugavaneshwaran added on  21st march 2018:STAMS-1877
                        ' WholeData = Regex.Replace(WholeData, Regex.Escape(CrossRefList.Item(FootNoteID)), FootNoteList.Item(FootNoteID), RegexOptions.Singleline Or RegexOptions.IgnoreCase)
                        WholeData = Replace(WholeData, CrossRefList.Item(FootNoteID), FootNoteList.Item(FootNoteID), , 1)
                        '---
                    End If
                Next
            End If
        Else
            'Bug id 6061 E.Raja modified on 26-Sep-2015;
            WholeData = Regex.Replace(WholeData, "<SPiFootNote>", "", RegexOptions.Singleline Or RegexOptions.IgnoreCase)
            WholeData = Regex.Replace(WholeData, "</SPiFootNote>", "", RegexOptions.Singleline Or RegexOptions.IgnoreCase)
        End If

        'P.Parthiban added for handling TextBox footnotes Bug:2485;on 26th May 2012;
        If Regex.IsMatch(WholeData, "<SPiBoxFootNoteRef id=""([^<>]*?)"">", RegexOptions.IgnoreCase) Then
            WholeData = Regex.Replace(WholeData, "<SPiBoxFootNoteRef id=""([^<>]*?)""></SPiBoxFootNoteRef>", "<SPiBoxFootNoteRef id=""$1""/>")
            Dim FootNoteData As String = Regex.Match(WholeData, "<SPiBoxFootNote>(.*?)</SPiBoxFootNote>", RegexOptions.IgnoreCase).Value
            If FootNoteData <> "" Then
                Dim FootNoteList As Hashtable = New Hashtable()
                For Each FootNote As Match In Regex.Matches(FootNoteData, "<ce:footnote id=""([^<>]*?)"">(.*?)</ce:footnote>", RegexOptions.IgnoreCase)
                    FootNoteList.Add(FootNote.Groups(1).Value, FootNote.Value)
                Next
                WholeData = Regex.Replace(WholeData, "<SPiBoxFootNote>(.*?)</SPiBoxFootNote>", "")
                Dim CrossRefList As Hashtable = New Hashtable()

                For Each CrossRef As Match In Regex.Matches(WholeData, "<SPiBoxFootNoteRef id=""([^<>]*?)""/>", RegexOptions.IgnoreCase)
                    If Not CrossRefList.ContainsKey(CrossRef.Groups(1).Value) Then
                        CrossRefList.Add(CrossRef.Groups(1).Value, CrossRef.Value)
                    End If
                Next
                For Each FootNoteID As String In FootNoteList.Keys
                    If CrossRefList.ContainsKey(FootNoteID) Then
                        WholeData = Regex.Replace(WholeData, Regex.Escape(CrossRefList.Item(FootNoteID)), FootNoteList.Item(FootNoteID))
                    End If
                Next
            End If
        Else
            WholeData = Regex.Replace(WholeData, "<SPiBoxFootNote>", "")
            WholeData = Regex.Replace(WholeData, "</SPiBoxFootNote>", "")
        End If
    End Sub
#End Region

    Public Shared Function PostProcessDisplayRemovePageBreaks(ByRef WholeData As String) As String
        Dim grpceDisplay As MatchCollection = Regex.Matches(WholeData, "<ce:display>(.*?)</ce:display>", RegexOptions.IgnoreCase)
        Dim cnt As Integer = 0
        For cnt = 0 To grpceDisplay.Count - 1
            Dim elem As String = grpceDisplay.Item(cnt).ToString
            'Dim PageBrkMatches As MatchCollection = Regex.Matches(grpceDisplay.Item(cnt).ToString, "<!--<page-break>(.[^<>]*?)</page-break>-->")
            Dim PageBrkMatches As MatchCollection = Regex.Matches(grpceDisplay.Item(cnt).ToString, "<!--<ce:anchor (.[^<>]*?)>-->", RegexOptions.Singleline)
            Dim PgBrkString As String = String.Empty
            If PageBrkMatches.Count > 0 Then
                ''STAMS:7192;Balamurugan.K commented & updated on 30-May-2020;
                ''Dim PgBrkCollection As MatchCollection = Regex.Matches(grpceDisplay.Item(cnt).ToString, "<!--<page-break>(.[^<>]*?)</page-break>-->", RegexOptions.IgnoreCase)
                'Dim PgBrkCollection As MatchCollection = Regex.Matches(grpceDisplay.Item(cnt).ToString, "<!--<ce:anchor (.[^<>]*?)>-->", RegexOptions.IgnoreCase)
                'If PgBrkCollection.Count > 0 Then
                '    For PgBrkCnt As Integer = 0 To PgBrkCollection.Count - 1
                '        PgBrkString = PgBrkString & PgBrkCollection.Item(PgBrkCnt).ToString
                '    Next
                'End If
                'Dim ReplacePattern As String = Regex.Replace(grpceDisplay.Item(cnt).ToString, "<!--<ce:anchor (.[^<>]*?)>-->", "")
                'ReplacePattern = Regex.Replace(ReplacePattern, "</ce:display>", "</ce:display>" & PgBrkString)
                'Try
                '    WholeData = Regex.Replace(WholeData, Regex.Escape(elem), ReplacePattern)
                'Catch ex As Exception
                '    'Dim errStr As String = ex.Message
                'End Try
                If Not Regex.IsMatch(grpceDisplay.Item(cnt).ToString, "(<ce:caption([^<>]*?)?>|<ce:list-item(.[^<]*?)?>|<ce:para(.[^<]*?)?>|<ce:section-title(.[^<]*?)?>|<ce:simple-para(.[^<]*?)?>|<ce:label(.[^<]*?)?>|<ce:source(.[^<]*?)?>|<ce:section(.[^<]*?)?>|<ce:quote(.[^<]*?)?>)<!--<ce:anchor (.[^<>]*?)>-->", RegexOptions.IgnoreCase) Then
                    'Dim PgBrkCollection As MatchCollection = Regex.Matches(grpceDisplay.Item(cnt).ToString, "<!--<page-break>(.[^<>]*?)</page-break>-->", RegexOptions.IgnoreCase)
                    Dim PgBrkCollection As MatchCollection = Regex.Matches(grpceDisplay.Item(cnt).ToString, "<!--<ce:anchor (.[^<>]*?)>-->", RegexOptions.IgnoreCase)
                    If PgBrkCollection.Count > 0 Then
                        For PgBrkCnt As Integer = 0 To PgBrkCollection.Count - 1
                            PgBrkString = PgBrkString & PgBrkCollection.Item(PgBrkCnt).ToString
                        Next
                    End If
                    ''STAMS:7192;Balamurugan.K added on 30-May-2020;
                    If Regex.IsMatch(grpceDisplay.Item(cnt).ToString, "<!--<ce:anchor (.[^<>]*?)>-->(<ce:caption([^<>]*?)?>|<ce:list-item(.[^<]*?)?>|<ce:para(.[^<]*?)?>|<ce:section-title(.[^<]*?)?>|<ce:simple-para(.[^<]*?)?>|<ce:label(.[^<]*?)?>|<ce:source(.[^<]*?)?>|<ce:section(.[^<]*?)?>|<ce:quote(.[^<]*?)?>)", RegexOptions.IgnoreCase) Then
                        Dim ReplacePattern As String = Regex.Replace(grpceDisplay.Item(cnt).ToString, "<!--<ce:anchor (.[^<>]*?)>-->(<ce:caption([^<>]*?)?>|<ce:list-item(.[^<]*?)?>|<ce:para(.[^<]*?)?>|<ce:section-title(.[^<]*?)?>|<ce:simple-para(.[^<]*?)?>|<ce:label(.[^<]*?)?>|<ce:source(.[^<]*?)?>|<ce:section(.[^<]*?)?>|<ce:quote(.[^<]*?)?>)", "$2<!--<ce:anchor $1>-->")
                        Try
                            WholeData = Regex.Replace(WholeData, Regex.Escape(elem), ReplacePattern)
                        Catch ex As Exception
                            'Dim errStr As String = ex.Message
                        End Try
                    Else
                        Dim ReplacePattern As String = Regex.Replace(grpceDisplay.Item(cnt).ToString, "<!--<ce:anchor (.[^<>]*?)>-->", "")
                        ReplacePattern = Regex.Replace(ReplacePattern, "</ce:display>", "</ce:display>" & PgBrkString)
                        Try
                            WholeData = Regex.Replace(WholeData, Regex.Escape(elem), ReplacePattern)
                        Catch ex As Exception
                            'Dim errStr As String = ex.Message
                        End Try
                    End If
                End If

            End If
        Next
        Return WholeData
    End Function
    Shared Sub PostprocessLOFConversion(ByRef wholedata As String)
        If Regex.IsMatch(wholedata, "(<LOFTITLE(.[^<>]*?)?>(.*?)</LOFTITLE>)|(<LOTTITLE(.[^<>]*?)?>(.*?)</LOTTITLE>)", RegexOptions.Singleline) Then
            wholedata = Regex.Replace(wholedata, "&para;", "")
            wholedata = Regex.Replace(wholedata, "</LOFTITLE><FIGURE(.[^<>]*?)?>", "</LOFTITLE><ce:para id=""p0010""><ce:list id=""l0010""><FIGURE$1>", RegexOptions.Singleline Or RegexOptions.Multiline)
            wholedata = Regex.Replace(wholedata, "</LOTTITLE><TABLE(.[^<>]*?)?>", "</LOTTITLE><ce:para id=""p0010""><ce:list id=""l0010""><TABLE$1>", RegexOptions.Singleline Or RegexOptions.Multiline)
            wholedata = Regex.Replace(wholedata, "<LOFTITLE(.[^<>]*?)?>(.*?)</LOFTITLE>", "<ce:title id=""ti0010"">$2</ce:title>", RegexOptions.Singleline Or RegexOptions.Multiline)
            wholedata = Regex.Replace(wholedata, "<LOTTITLE(.[^<>]*?)?>(.*?)</LOTTITLE>", "<ce:title id=""ti0010"">$2</ce:title>", RegexOptions.Singleline Or RegexOptions.Multiline)
            wholedata = Regex.Replace(wholedata, "</fb-non-chapter>", "</ce:list></ce:para></fb-non-chapter>", RegexOptions.Singleline Or RegexOptions.Multiline)
            wholedata = Regex.Replace(wholedata, "<PGNO>(.*?)</PGNO>", "00", RegexOptions.Singleline Or RegexOptions.Multiline)
            wholedata = Regex.Replace(wholedata, vbTab, "<ce:hsp sp=""1""/>")
            wholedata = Regex.Replace(wholedata, "<ce:hsp(.[^<>]*?)?>(\d+)</FIGURE>", "$2</FIGURE>", RegexOptions.Singleline Or RegexOptions.Multiline)
            wholedata = Regex.Replace(wholedata, "<ce:hsp(.[^<>]*?)?>(\d+)</TABLE>", " $2</TABLE>", RegexOptions.Singleline Or RegexOptions.Multiline)
        End If
        Dim figureclxn As MatchCollection = Regex.Matches(wholedata, "(<FIGURE(.[^<>]*?)?>(.*?)</FIGURE>)|(<TABLE(.[^<>]*?)?>(.*?)</TABLE>)", RegexOptions.Singleline)
        Dim i As String = "10"
        Dim j As String = "15"
        For Each fig As Match In figureclxn
            Dim data As String = fig.ToString
            data = Regex.Replace(data, "(<FIGURE(.[^<>]*?)?>(.*?)</FIGURE>)|(<TABLE(.[^<>]*?)?>(.*?)</TABLE>)", "<ce:list-item id=" & """u" & ids(i) & """><ce:para id=" & """p" & ids(j) & """>$3$6</ce:para></ce:list-item>", RegexOptions.Singleline Or RegexOptions.Multiline)
            wholedata = Replace(wholedata, fig.ToString, data, , 1)
            i = i + 5
            j = j + 5
        Next
        File.WriteAllText(ExtractedXMLfile, wholedata, System.Text.Encoding.UTF8)
    End Sub
    ''STAMS:7645;Balamurugan.K added on 29-June-2020;
    Shared Function RefStylePageBreakAnchorReposition(ByRef CurrData As String) As String
        Dim Refcoll As MatchCollection = Regex.Matches(CurrData, "<Ref_Style(.[^<>]*?)?>(.*?)</Ref_Style>", RegexOptions.Multiline Or RegexOptions.Singleline)
        For Each mtch As Match In Refcoll
            Dim RefStyledata As String = mtch.Groups(0).ToString
            If Regex.IsMatch(RefStyledata, "<ce:anchor(.[^<>]*?)?>") = True Then
                Dim Anchormatch As MatchCollection = Regex.Matches(RefStyledata, "<!--<ce:anchor(.[^<>]*?)>-->", RegexOptions.Singleline Or RegexOptions.IgnoreCase)
                If Anchormatch.Count > 0 Then
                    For Each anchor As Match In Anchormatch
                        Dim anchordata As String = anchor.Value
                        RefStyledata = Replace(RefStyledata, anchordata, "", , 1)
                        RefStyledata = RefStyledata & anchordata
                        CurrData = Replace(CurrData, mtch.Groups(0).Value, RefStyledata, , 1)
                    Next
                End If
            End If
        Next
        Return CurrData
    End Function

End Class
